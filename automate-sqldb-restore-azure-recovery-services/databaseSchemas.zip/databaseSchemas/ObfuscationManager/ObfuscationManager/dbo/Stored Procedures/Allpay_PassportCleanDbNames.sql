﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure Allpay_PassportCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Allpay_Passport].[dbo].[appass_Users] SET [Firstname] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Firstname]);
	UPDATE [Allpay_Passport].[dbo].[appass_Users] SET [Surname] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Surname]);
	UPDATE [Allpay_Passport].[dbo].[appass_Users] SET [PasswordQuestion] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PasswordQuestion]);
return 0