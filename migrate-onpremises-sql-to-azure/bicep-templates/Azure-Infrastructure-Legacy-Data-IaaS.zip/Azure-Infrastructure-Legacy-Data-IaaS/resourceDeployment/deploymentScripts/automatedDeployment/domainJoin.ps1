param (
    [Parameter(Mandatory)][string]$activeDirectoryDomain,
    [Parameter(Mandatory)][string]$windowsInstallPassword,
    [Parameter(Mandatory)][string]$windowsInstallUsername
)
$errorActionPreference = 'Stop'
$windowsInstallPasswordForCredential = ConvertTo-SecureString $windowsInstallPassword -AsPlainText -Force
$windowsInstallCredential = New-Object System.Management.Automation.PSCredential($windowsInstallUsername, $windowsInstallPasswordForCredential)

Add-Computer -DomainName $activeDirectoryDomain -Credential $windowsInstallCredential -Restart