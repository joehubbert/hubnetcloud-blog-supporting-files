param 
(
    [Parameter(Mandatory)][string]$erosIPAddress,
    [Parameter(Mandatory)][string]$erosR4IPAddress
)

$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$scriptLogFileName = 'configureEROS-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Create EROS IIS Site
try
{
    $site = 'EROS'
    $siteFolder = "C:\inetpub\wwwroot\$site"
    New-Item -Path $siteFolder -ItemType Directory

    New-Website -Name $site -PhysicalPath $siteFolder -ApplicationPool $webAppPoolName -Force
    New-WebBinding -Name $site -Port 443 -Protocol https -IPAddress $erosIPAddress
    Remove-WebBinding -Name $site -Port 80 -Protocol http -IPAddress *
    Start-Website -Name $site

    $currentTimestamp = Get-Date
    $outputText = "The IIS site $site has been installed and is listening $erosIPAddress on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"    
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "There was an error installing the IIS site $site on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"    
}

#Create EROSR4 IIS Site
try
{
    $site = 'EROSR4'
    $siteFolder = "C:\inetpub\wwwroot\$site"
    New-Item -Path $siteFolder -ItemType Directory

    New-Website -Name $site -PhysicalPath $siteFolder -ApplicationPool $webAppPoolName -Force
    New-WebBinding -Name $site -Port 443 -Protocol https -IPAddress $erosR4IPAddress
    Remove-WebBinding -Name $site -Port 80 -Protocol http -IPAddress *
    Start-Website -Name $site

    $currentTimestamp = Get-Date
    $outputText = "The IIS site $site has been installed and is listening $erosR4IPAddress on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"    
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "There was an error installing the IIS site $site on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"    
}

$currentTimestamp = Get-Date
$outputText = "configureEROS.ps1 has completed execution on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer