﻿/*
Clean the postal addresses by replacing originals with fictional postal address
*/
create procedure BACSFileValidationCleanDbPostalAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [BACSFileValidation].[dbo].[Archive_DDCollectionDetail] SET [AccountNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber]);
	UPDATE [BACSFileValidation].[dbo].[Archive_DDCollectionDetail] SET [AccountSortCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountSortCode]);
	UPDATE [BACSFileValidation].[dbo].[DDCollectionDetail] SET [AccountNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber]);
	UPDATE [BACSFileValidation].[dbo].[DDCollectionDetail] SET [AccountSortCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountSortCode]);
	UPDATE [BACSFileValidation].[dbo].[DDCollectionDetailAudit] SET [AccountNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber]);
	UPDATE [BACSFileValidation].[dbo].[DDCollectionDetailAudit] SET [AccountSortCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountSortCode]);
return 0