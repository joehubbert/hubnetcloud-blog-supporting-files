﻿/*
Clean the postal addresses by replacing originals with fictional postal address
*/
create procedure PrepaidCleanDbPostalAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Prepaid].[dbo].[CardHolders] SET [AddressLine1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine1]);
	UPDATE [Prepaid].[dbo].[CardHolders] SET [AddressLine2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine2]);
	UPDATE [Prepaid].[dbo].[CardHolders] SET [AddressLine3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine3]);
	UPDATE [Prepaid].[dbo].[CardHolders] SET [AddressTown] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressTown]);
	UPDATE [Prepaid].[dbo].[CardHolders] SET [Country] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Country]);
	--TODO: discuss date obfuscation - not easily done if age is calculated
	UPDATE [Prepaid].[dbo].[CardHolders] SET [DateOfBirth] = [ObfuscationManager].[dbo].[ObfuscateDateTime] ([DateOfBirth]);
	UPDATE [Prepaid].[dbo].[CardHolders] SET [Postcode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Postcode]);
	UPDATE [Prepaid].[dbo].[CardHolders] SET [PrimaryTelephone] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PrimaryTelephone]);
	UPDATE [Prepaid].[dbo].[CardHolders] SET [SecondaryTelephone] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SecondaryTelephone]);
	UPDATE [Prepaid].[dbo].[CardHolders] SET [Title] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Title]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [AddressLine1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine1]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [AddressLine2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine2]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [AddressLine3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine3]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [Country] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Country]);
	--TODO: discuss date obfuscation - not easily done if age is calculated
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [DateOfBirth] = [ObfuscationManager].[dbo].[ObfuscateDateTime] ([DateOfBirth]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [DispatchAddressCountry] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressCountry]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [DispatchAddressLine1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressLine1]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [DispatchAddressLine2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressLine2]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [DispatchAddressLine3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressLine3]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [DispatchAddressPostCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressPostCode]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [DispatchAddressTown] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressTown]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [DispatchTitle] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchTitle]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [PostCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PostCode]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [PrimaryTelNo] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PrimaryTelNo]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [SecondaryTelNo] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SecondaryTelNo]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [Title] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Title]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [Town] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Town]);
	UPDATE [Prepaid].[dbo].[IssueAdditionalCardRequests] SET [DispatchAddressCountry] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressCountry]);
	UPDATE [Prepaid].[dbo].[IssueAdditionalCardRequests] SET [DispatchAddressLine1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressLine1]);
	UPDATE [Prepaid].[dbo].[IssueAdditionalCardRequests] SET [DispatchAddressLine2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressLine2]);
	UPDATE [Prepaid].[dbo].[IssueAdditionalCardRequests] SET [DispatchAddressLine3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressLine3]);
	UPDATE [Prepaid].[dbo].[IssueAdditionalCardRequests] SET [DispatchAddressPostcode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressPostcode]);
	UPDATE [Prepaid].[dbo].[IssueAdditionalCardRequests] SET [DispatchAddressTown] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressTown]);
	UPDATE [Prepaid].[dbo].[IssueAdditionalCardRequests] SET [DispatchTitle] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchTitle]);
	UPDATE [Prepaid].[dbo].[IssueCardRequests] SET [DispatchAddressCountry] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressCountry]);
	UPDATE [Prepaid].[dbo].[IssueCardRequests] SET [DispatchAddressLine1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressLine1]);
	UPDATE [Prepaid].[dbo].[IssueCardRequests] SET [DispatchAddressLine2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressLine2]);
	UPDATE [Prepaid].[dbo].[IssueCardRequests] SET [DispatchAddressLine3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressLine3]);
	UPDATE [Prepaid].[dbo].[IssueCardRequests] SET [DispatchAddressPostcode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressPostcode]);
	UPDATE [Prepaid].[dbo].[IssueCardRequests] SET [DispatchAddressTown] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchAddressTown]);
	UPDATE [Prepaid].[dbo].[IssueCardRequests] SET [DispatchTitle] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchTitle]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [AddressLine1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine1]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [AddressLine2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine2]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [AddressLine3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine3]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [AddressTown] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressTown]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [Country] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Country]);
	--TODO: discuss date obfuscation - not easily done if age is calculated
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [DateOfBirth] = [ObfuscationManager].[dbo].[ObfuscateDateTime] ([DateOfBirth]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [Postcode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Postcode]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [PrimaryTelephone] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PrimaryTelephone]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [SecondaryTelephone] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SecondaryTelephone]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [Title] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Title]);
	UPDATE [Prepaid].[dbo].[UpdateCardHolderDetailsRequests] SET [AddressLine1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine1]);
	UPDATE [Prepaid].[dbo].[UpdateCardHolderDetailsRequests] SET [AddressLine2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine2]);
	UPDATE [Prepaid].[dbo].[UpdateCardHolderDetailsRequests] SET [AddressLine3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine3]);
	UPDATE [Prepaid].[dbo].[UpdateCardHolderDetailsRequests] SET [AddressTown] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressTown]);
	UPDATE [Prepaid].[dbo].[UpdateCardHolderDetailsRequests] SET [Country] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Country]);
	UPDATE [Prepaid].[dbo].[UpdateCardHolderDetailsRequests] SET [Postcode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Postcode]);
	UPDATE [Prepaid].[dbo].[UpdateCardHolderDetailsRequests] SET [PrimaryTelephone] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PrimaryTelephone]);
	UPDATE [Prepaid].[dbo].[UpdateCardHolderDetailsRequests] SET [SecondaryTelephone] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SecondaryTelephone]);
return 0