﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure DirectDebitsCleanAllpayAccountKeys @seedA int, @seedB int
as
	set nocount on;
	--[AllpayAccountKeys];
	-- the work table
	select 
	 [AllpayAccountKeyId]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LastName]) [LastName]
	into [DirectDebits].[dbo].[AllpayAccountKeys_WORK] 
	from [DirectDebits].[dbo].[AllpayAccountKeys];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [DirectDebits]; create clustered index [CIX_AllpayAccountKeys_WORK(AllpayAccountKeyId)] on AllpayAccountKeys_WORK(AllpayAccountKeyId);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @AllpayAccountKey table(AllpayAccountKeyId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		UPDATE [DirectDebits].[dbo].[AllpayAccountKeys] 
		SET 
		 [LastName] = [DirectDebits].[dbo].[AllpayAccountKeys_WORK].[LastName]
		output INSERTED.AllpayAccountKeyId into @AllpayAccountKey
		from [DirectDebits].[dbo].[AllpayAccountKeys_WORK]
		where [DirectDebits].[dbo].[AllpayAccountKeys_WORK].[AllpayAccountKeyId] = [DirectDebits].[dbo].[AllpayAccountKeys].[AllpayAccountKeyId];
		--remove the records already updated
		delete from [DirectDebits].[dbo].[AllpayAccountKeys_WORK] where AllpayAccountKeyId in (select AllpayAccountKeyId from @AllpayAccountKey);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @AllpayAccountKey;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [DirectDebits].[dbo].[AllpayAccountKeys_WORK];
return 0