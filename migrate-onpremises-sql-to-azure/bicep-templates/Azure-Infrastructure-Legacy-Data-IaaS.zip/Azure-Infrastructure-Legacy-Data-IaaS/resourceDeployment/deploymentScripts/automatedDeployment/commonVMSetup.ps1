param
(
    [Parameter(Mandatory)][string]$environmentCode,
    [Parameter(Mandatory)][string]$storageAccountName
)

#Set Common Variables
$computerConfigurationInstallerDirectory = 'C:\ComputerConfiguration\Installer'
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$diskFormat = 'NTFS'
$diskPartitionStyle = 'GPT'
$errorActionPreference = 'Stop'
$firewallRuleDisplayGroup = 'Allpay Custom Windows Firewall Rules'
$globallyManagedServiceAccountsToInstall = @('svcMSSQLA','svcMSSQLDB')
$progressPreference = 'SilentlyContinue'
$scriptFileName = 'commonVMSetup-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptFileName"
$sqlBackupDiskName = 'SQLBackup'
$sqlDataDiskName = 'SQLData'
$sqlLogDiskName = 'SQLLog'
$sqlTempDBDiskName = 'SQLTempDB'
$windowsFeaturesToInstall = @('File-Services', 'FS-FileServer', 'RSAT-AD-PowerShell')

#Create Script Log File
$currentTimestamp = Get-Date
New-Item -Path $computerConfigurationLogDirectory -Name $scriptFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force

#Install Windows Features
Import-Module ServerManager

foreach($feature in $windowsFeaturesToInstall)
{
    Install-WindowsFeature $feature
    $currentTimestamp = Get-Date
    $outputText = "The Windows Feature $feature has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Setup Data Disks
Initialize-Disk -Number 2 -PartitionStyle $diskPartitionStyle -PassThru | `
New-Volume -FileSystem $diskFormat -DriveLetter F -FriendlyName $sqlDataDiskName
$currentTimestamp = Get-Date
$outputText = "The data disk $sqlDataDiskName has been successfully initialised on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Initialize-Disk -Number 3 -PartitionStyle $diskPartitionStyle -PassThru | `
New-Volume -FileSystem $diskFormat -DriveLetter G -FriendlyName $sqlLogDiskName
$currentTimestamp = Get-Date
$outputText = "The data disk $sqlLogDiskName has been successfully initialised on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Initialize-Disk -Number 4 -PartitionStyle $diskPartitionStyle -PassThru | `
New-Volume -FileSystem $diskFormat -DriveLetter H -FriendlyName $sqlBackupDiskName
$currentTimestamp = Get-Date
$outputText = "The data disk $sqlBackupDiskName has been successfully initialised on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Initialize-Disk -Number 5 -PartitionStyle $diskPartitionStyle -PassThru | `
New-Volume -FileSystem $diskFormat -DriveLetter I -FriendlyName $sqlTempDBDiskName
$currentTimestamp = Get-Date
$outputText = "The data disk $sqlTempDBDiskName has been successfully initialised on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Install Active Directory Globally Managed Service Accounts
Import-Module ActiveDirectory

foreach($gMSA in $globallyManagedServiceAccountsToInstall)
{
    Install-ADServiceAccount -Identity $gMSA
    $gMSATest = Test-AdServiceAccount $gMSA
    if ($gMSATest -eq $true)
    {
        $currentTimestamp = Get-Date
        $outputText = "The Active Directory Globally Managed Service Account $gMSA was successfully installed on $env:computername at $currentTimestamp."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
    elseif ($gMSATest -eq $false)
    {
        $currentTimestamp = Get-Date
        $outputText = "The Active Directory Globally Managed Service Account $gMSA was not installed on $env:computername. Please investigate. Error logged at $currentTimestamp."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
}

#Configure Windows Firewall
Enable-NetFirewallRule -DisplayName 'Core Networking Diagnostics - ICMP Echo Request (ICMPv4-In)'
$currentTimestamp = Get-Date
$outputText = "The IpV4 Ping Reply Windows Firewall Rule has been successfully enabled on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

New-NetFirewallRule `
-Action Allow `
-Description 'Allows inbound connectivity for clients to connect to SQL Server Database Engine for the MSSQLSERVER instance.' `
-Direction Inbound `
-DisplayName 'SQL Server - Allow Inbound MSSQLDB Engine' `
-Group $firewallRuleDisplayGroup `
-LocalPort 1433 `
-Name 'SQL Server - Allow Inbound MSSQLDB Engine' `
-Profile "Domain, Private" `
-Protocol TCP
$currentTimestamp = Get-Date
$outputText = "The MSSQL Database Engine Windows Firewall Rule has been successfully installed on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

netsh int ipv4 add excludedportrange tcp startport=1433 numberofports=1 store=persistent
$currentTimestamp = Get-Date
$outputText = "The port 1433 has been successfully excluded from the Windows Dynamic Port Range on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Download Software Packages

Invoke-WebRequest `
-Uri "https://$storageAccountName.blob.core.windows.net/$environmentCode-sql-iaas-resources/software-packages/PowerShell-7.3.1-win-x64.msi" `
-OutFile "C:\ComputerConfiguration\Installer\PowerShell-7.3.1-win-x64.msi"
$currentTimestamp = Get-Date
$outputText = "The PowerShell installer has been successfully downloaded to $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path 'C:\ComputerConfiguration\Logs\commonVMSetup-Log.txt' "`n$outputText"

Invoke-WebRequest `
-Uri "https://$storageAccountName.blob.core.windows.net/$environmentCode-sql-iaas-resources/software-packages/en_sql_server_2019_x64_dvd.iso" `
-OutFile "C:\ComputerConfiguration\Installer\en_sql_server_2019_x64_dvd.iso"
$currentTimestamp = Get-Date
$outputText = "The SQL Server Setup ISO file has been successfully downloaded to $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path 'C:\ComputerConfiguration\Logs\commonVMSetup-Log.txt' "`n$outputText"

Invoke-WebRequest `
-Uri "https://$storageAccountName.blob.core.windows.net/$environmentCode-sql-iaas-resources/software-packages/SSMS-Setup-ENU-18-12-1.exe" `
-OutFile "C:\ComputerConfiguration\Installer\SSMS-Setup-ENU-18-12-1.exe"
$currentTimestamp = Get-Date
$outputText = "The SQL Server Management Studio Installer has been successfully downloaded to $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path 'C:\ComputerConfiguration\Logs\commonVMSetup-Log.txt' "`n$outputText"

Invoke-WebRequest -Uri `
"https://$storageAccountName.blob.core.windows.net/$environmentCode-sql-iaas-resources/software-packages/SysInternalsSuite.zip" `
-OutFile "C:\ComputerConfiguration\Installer\SysInternalsSuite.zip"
$currentTimestamp = Get-Date
$outputText = "The SysInternalsSuite has been successfully downloaded to $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path 'C:\ComputerConfiguration\Logs\commonVMSetup-Log.txt' "`n$outputText"


#Install Software Packages
Expand-Archive -LiteralPath "$computerConfigurationInstallerDirectory\SysInternalsSuite.zip" -DestinationPath 'C:\SysInternalsSuite'
$currentTimestamp = Get-Date
$outputText = "The SysInternalsSuite has been successfully installed on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Set-Location $computerConfigurationInstallerDirectory
msiexec.exe /package PowerShell-7.3.1-win-x64.msi /quiet ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=1 ADD_FILE_CONTEXT_MENU_RUNPOWERSHELL=1 ENABLE_PSREMOTING=0 REGISTER_MANIFEST=1 USE_MU=1 ENABLE_MU=1 ADD_PATH=1
Wait-Process 'msiexec'
$currentTimestamp = Get-Date
$outputText = "PowerShell has been successfully installed on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

.\SSMS-Setup-ENU-18-12-1.exe /Install /Passive
Wait-Process 'SSMS-Setup-ENU-18-12-1'
$currentTimestamp = Get-Date
$outputText = "SQL Server Management Studio has been successfully installed on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Install Nuget Package Provider
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
$currentTimestamp = Get-Date
$outputText = "The Nuget package provider has been installed on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Configure PowerShell Gallery Trust Status
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
$currentTimestamp = Get-Date
$outputText = "PSGallery has been set to be a trusted package repository on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Install Common PowerShell Modules
Install-Module SQLServer -Force
$currentTimestamp = Get-Date
$outputText = "The SQLServer PowerShell module has been successfully installed on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

$currentTimestamp = Get-Date
$outputText = "commonVMSetup.ps1 has completed execution on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer