﻿/*
Clean the postal addresses by replacing originals with fictional postal address
*/
create procedure LettersCleanDbPostalAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Letters].[dbo].[Letters_CustomerDDLetter] SET [AccountNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber]);
	UPDATE [Letters].[dbo].[Letters_CustomerDDLetter] SET [SortCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SortCode]);
	UPDATE [Letters].[dbo].[Letters_DDLetter] SET [AccountNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber]);
	UPDATE [Letters].[dbo].[Letters_DDLetter] SET [SortCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SortCode]);
	UPDATE [Letters].[dbo].[RecipientAddresses_RecipientPostalAddress] SET [AddressLine1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine1]);
	UPDATE [Letters].[dbo].[RecipientAddresses_RecipientPostalAddress] SET [AddressLine2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine2]);
	UPDATE [Letters].[dbo].[RecipientAddresses_RecipientPostalAddress] SET [AddressLine3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine3]);
	UPDATE [Letters].[dbo].[RecipientAddresses_RecipientPostalAddress] SET [AddressLine4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine4]);
	UPDATE [Letters].[dbo].[RecipientAddresses_RecipientPostalAddress] SET [AddressPostCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressPostCode]);
return 0