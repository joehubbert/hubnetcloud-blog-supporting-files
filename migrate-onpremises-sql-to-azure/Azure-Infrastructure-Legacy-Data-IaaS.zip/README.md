# Introduction 
This repository stores the templates and configuration scripts for deploying a SQL Server AlwaysOn Availability Group (AOAG) to Windows Server and deploying SQL Server Reporting Services (SSRS) to Windows Server.
- The current configuration:
   - Windows Server 2022
   - SQL Server 2019

# Getting Started
- You will need to clone this repository to your local machine.

**Tools**:
- Visual Studio Code
- PowerShell 7+
- Bicep extension for Visual Studio Code
- ARM Template extension for Visual Studio Code

**Active Directory Provisions**
- Service Accounts deployed as per .\resourceDeployment\deploymentScripts\manualDeployment\provisionADGMSA.ps1, ran on the domain controllers directly
- Domain account with permissions to join machines to domain (ideally OU delegation) and be a member of DNS Admins, NOT DOMAIN ADMIN
  - Local administrator permissions to be set through group policy where appropriate
- Domain account with no domain-level permissions to be used as Active Directory breakglass account e.g. 'CONTOSO\sqlbreakglass'
- Security group that has all domain users that need sysadmin access to the database engine, these should be local domain users and not federated

**SSRS**
-Export the encryption keys from the existing instance of SSRS

# Deployment
## YAML Release Pipeline - Automated Deployment
1. Infrastructure is deployed using YAML release pipeline with two possible flows for each release stage (DEV, QUA, STG and PRD).
   - New Deployment
      - Copy Deployment Scripts to Storage Account (There is a folder for each release stage in the 'sql-iaas-resources' containers)
      - Generate & Store SQL AOAG VM local admin credentials in centralised KeyVault (If deploySQLAlwaysOnCluster == true)
      - Generate & Store SQL RS VM local admin credentials in centralised KeyVault (If deploySQLReportingServices == true)
      - Generate & Store SQL AOAG Master Encryption Key, Master Encryption Key Backup Password and Service Certificate Backup Password in centralised KeyVault (If deploySQLAlwaysOnCluster == true)
      - Generate & Store SQL RS Master Encryption Key, Master Encryption Key Backup Password and Service Certificate Backup Password in centralised KeyVault (If deploySQLReportingServices == true)
      - Get required Key Vault secrets not specific to flow (All Deployment Types) - SQLAOAG (If deploySQLAlwaysOnCluster == true)
      - Get required Key Vault secrets not specific to flow (All Deployment Types) - SQLRS (If deploySQLReportingServices == true)
      - Get required Key Vault secrets specifc to flow (New Deployment)
      - Deploy Resource Groups Bicep Template, these are specifc for each release stage
        - Management
        - Networking
        - Storage
        - Virtual Machine
      - Deploy Core Resources Bicep Template, these are specifc for each release stage (If deployCoreServices == true)
        - SQL AOAG Subnet Network Security Group
        - SQL AOAG Subnet Network Security Group Rules
        - SQL SSRS Subnet Network Security Group
        - SQL SSRS Subnet Network Security Group Rules
        - Route Table
        - Virtual Network
        - Bi-Directional Virtual Network Peering to Virtual Network where Windows Active Directory Domain Services Servers/DNS Servers are located
        - Bi-Directional Virtual Network Peering to Hub Virtual Network which is attached to Azure Firewall
        - Route Table Route
        - Storage Account
        - Storage Account Containers (Cloud Witness for Windows Server Failover Cluster and Database Static Backup)
      - Deploy SQL AOAG Resources Bicep Template, these are specifc for each release stage (If deploySQLAlwaysOnCluster == true)
        - SQL AOAG Virtual Machine Nodes (A,B,C)
        - Maintenance Configurations for each SQL AOAG Virtual Machine to be deployed (Different times specified in schedule to ensure high-availability)
      - Deploy SQL RS Resources Bicep Template, these are specifc for each release stage (If deploySQLReportingServices == true)
        - SQL SSRS Virtual Machine
        - Maintenance Configuration for SQL RS Virtual Machine
      - Prepare and Configure each SQL AOAG VM (If deploySQLAlwaysOnCluster == true)
        - Run preparation scripts on each virtual machine (Creates required directories and downloads common scripts)
        - Copy AOAG setup scripts to each SQL AOAG virtual machine
        - Join each virtual machine to Windows Active Directory
        - Execute common virtual machine setup script on each virtual machine
        - Execute AOAG setup scripts on each SQL AOAG virtual machine
      - Prepare and Configure each SQL RS VM (If deploySQLReportingServices == true)
        - Run preparation scripts on each virtual machine (Creates required directories and downloads common scripts)
        - Copy SSRS setup scripts to each SQL SSRS virtual machine
        - Join each virtual machine to Windows Active Directory
        - Execute common virtual machine setup script on each virtual machine
        - Execute SSRS setup scripts on each SQL SSRS virtual machine
      - Enrol each SQL AOAG virtual machine into SQL IaaS extension for Azure using sqlVirtualMachine Bicep Template. (If deploySQLAlwaysOnCluster == true)
      - Enrol each SQL RS virtual machine into SQL IaaS extension for Azure using sqlVirtualMachine Bicep Template. (If deploySQLReportingServices == true)
   - Existing Deployment
      - Get required Key Vault secrets not specific to flow (All Deployment Types)
      - Deploy Resource Groups Bicep Template, these are specifc for each release stage
        - Management
        - Networking
        - Storage
        - Virtual Machine
      - Deploy Core Resources Bicep Template, these are specifc for each release stage (If deployCoreServices == true)
        - SQL AOAG Subnet Network Security Group
        - SQL AOAG Subnet Network Security Group Rules
        - SQL SSRS Subnet Network Security Group
        - SQL SSRS Subnet Network Security Group Rules
        - Route Table
        - Virtual Network
        - Bi-Directional Virtual Network Peering to Virtual Network where Windows Active Directory Domain Services Servers/DNS Servers are located
        - Bi-Directional Virtual Network Peering to Hub Virtual Network which is attached to Azure Firewall
        - Route Table Route
        - Storage Account
        - Storage Account Containers (Cloud Witness for Windows Server Failover Cluster and Database Static Backup)
      - Deploy SQL AOAG Resources Bicep Template, these are specifc for each release stage (If deploySQLAlwaysOnCluster == true)
        - SQL AOAG Virtual Machine Nodes (A,B,C)
        - Maintenance Configurations for each SQL AOAG Virtual Machine to be deployed (Different times specified in schedule to ensure high-availability)
      - Deploy SQL RS Resources Bicep Template, these are specifc for each release stage (If deploySQLReportingServices == true)
        - SQL SSRS Virtual Machine
        - Maintenance Configuration for SQL RS Virtual Machine
      - Enrol each virtual machine into SQL IaaS extension for Azure using sqlVirtualMachine Bicep Template.
2. Manual intervention required beyond this point  
3. Follow further steps specific to each resource type below

## SQL AOAG Specifc
### Windows Server Failover Cluster Setup
1. Open the Azure portal and navigate to the storage account created by the bicep deployment, get the primary storage key and copy to your clipboard
2. Check to see if computer objects already exist for the WSFC Listener Name and the SQL Listener Name e.g. NPDEVSQLAOAGWSFC and NPDEVSQLCLUSTER (These will be in the same Organisational Unit (OU) as the computer objects for the SQL AOAG nodes)
  - If they do already exist, delete them
3. Run **Windows PowerShell** as administrator **on the primary node** with code similar to the below
    - You can get the following values from the variable group for the release stage
        - windowsServerFailoverClusterNodeASubnetPrefix = virtualNetworkSQLAOAGNodeASubnetPrefix
        - windowsServerFailoverClusterNodeBSubnetPrefix = virtualNetworkSQLAOAGNodeBSubnetPrefix
        - windowsServerFailoverClusterNodeCSubnetPrefix = virtualNetworkSQLAOAGNodeCSubnetPrefix
        - windowsServerFailoverClusterWSFCListenerName = windowsServerFailoverClusterWSFCListenerName
```
Set-Location C:\ComputerConfiguration\Scripts
.\sqlAOAGWSFCSetup.ps1 `
-windowsServerFailoverClusterCloudWitnessAccount 'allpayuksnpdevdba' `
-windowsServerFailoverClusterCloudWitnessKey '<Primary Storage Account Key>' `
-windowsServerFailoverClusterWSFCListenerName 'NPDEVSQLAOAGWSFC' `
-windowsServerFailoverClusterNodeA 'NPVMIDEVSQLDB01' `
-windowsServerFailoverClusterNodeASubnetPrefix '10.177.176.0/29' `
-windowsServerFailoverClusterNodeB 'NPVMIDEVSQLDB02' `
-windowsServerFailoverClusterNodeBSubnetPrefix '10.177.176.8/29' `
-windowsServerFailoverClusterNodeC 'NPVMIDEVSQLDB03' `
-windowsServerFailoverClusterNodeCSubnetPrefix '10.177.176.16/29'
```
4. After reboot, login to **each AOAG node** as the same domain user used previously
5. Open SQL Server Configuration Manager
6. Go to SQL Server Services
7. Right-Click on 'SQL Server (MSSQLSERVER)' and select Properties
8. Go to the Always On Availability Groups tab
9. Enable Always On Availability Groups
10. Restart each node
11. Open Active Directory Users & Computers with a user that has administrative access in the OU the Cluster Name (CNO) computer object is in
12. Ensure that 'Advanced Features' is checked in the View menu
13. Right-click on the OU and select Properties
14. On the Security tab, select Advanced
15. In the Advanced Security Settings dialog box, select Add
16. Next to Principal, select Select a principal
17. In the Select User, Computer, Service Account, or Groups dialog box, select Object Types, select the Computers check box, and then select OK
18. Under Enter the object names to select, enter the name of the CNO, select Check Names, and then select OK. In response to the warning message that says that you are about to add a disabled object, select OK
19. In the Permission Entry dialog box, make sure that the Type list is set to Allow, and the Applies to list is set to This object and all descendant objects
20. Under Permissions, select the 'Create Computer objects' check box
21. Click OK

### SQL Server Integration Services Catalog Creation
1. Login to the **primary node** machine as the SQL Install domain user used previously to join the machine to the domain
2. Open SQL Server Management Studio (SSMS) and connect to the database engine on the primary node only using Windows Authentication
3. Open the centralised key vault locally and find the secret named in the format similar to this example for the release stage (nds01-dev-sql-ssiscatalog-master-key) and copy to clipboard
4. Right-click on 'Integration Services Catalogs' in the object explorer
5. Select 'Create Catalog...'
6. Ensure that both 'Enable CLR Integration' and 'Enable automatic execution of Integration Services stored procedure at SQL Server statup.' are selected
7. Paste key vault secret in the 'Password' and 'Retype Password' fields and click 'OK'
8. Close SSMS

### Creation of the Always-On Availability Group
1. Login to the **primary node** machine as the SQL Install domain user used previously to join the machine to the domain
2. Open SQL Server Management Studio (SSMS) and connect to the database engine on the primary node only using Windows Authentication
3. Right-click on 'AlwaysOn High Availability' and click on 'New Availability Group Wizard'
4. Give the availability group a name in this convention e.g. NPDEVSQLAOAG
5. Check the Database Level Health Detection checkbox
6. Click 'Next'
7. Add SSISDB into the scope and retrieve the catalog master key from Azure Keyvault
    - Paste the password into the password field
    - Click 'Refresh'
    - Check the checkbox next to SSISDB
8. Click 'Next'
9. For each secondary node, click 'Add Replica' and connect to each replica
10. Check the 'Automatic Failover' checkbox for each node
11. Change the 'Readable Secondary' dropdown to 'Yes' for each node
12. Go to the 'Endpoints' tab and ensure that the database mirroring endpoint has been set as per the automated PowerShell setup script 'sqlAOAGNodeCommonVMSetup'
13. On the backup preferences, ensure that 'Prefer Secondary' is selected
14. Go to the listener tab, ensure that the Active Directory steps as part of the WSFC setup have been completed before proceeding
15. Click on the 'Create an Availability Group Listener' radio button
16. For the name, choose a name that follows this convention e.g. 'NPDEVSQLCLUSTER'. This is what users/applications will use to connect to the AOAG
17. For the port, choose '1433'
18. Ensure that the network mode dropdown is set to 'Static IP'
18. For the IP Addresses, it will show each 'Cluster Network' that you have added on the WSFC setup e.g. the subnet for each AOAG node in the 'Subnet' dropdown
19. The IPv4 address for each subnet will be the secondary IP address you created for each corresponding cluster node
20. Once you have added each IP Address to the listener, click 'Next'
21. For the data synchronization preferences, ensure that the radio option is set to 'Automatic Seeding'
22. Click 'Next'
23. Click 'Next'
24. Click 'Close'
25. Run **Windows PowerShell** as administrator **on the primary node** with code similar to the below
```
Set-Location C:\ComputerConfiguration\Scripts
.\improveAvailabilityLegacyClient.ps1 `
-availabilityGroupName 'NPDEVSQLAOAG' `
-availabilityGroupListenerName 'NPDEVSQLCLUSTER'
```

### Adding Databases Into Availability Group
1. Install all databases on primary node
2. A full local backup must be taken of each database before it can be added into the availability group as a prerequisite
    - As there is limited disk space on the local backup drive on the server databases should be batched when being added to the availability group
    - SSISDB can and should be added into the availability group **Auto-failover of SSISDB database is not supported until you enable SSIS Support for Always On.**
      - Once added, Always-On support should be enabled by re-connecting to the database engine in SSMS
      - Right-click on 'Integration Service Catalogs'
      - Click on 'Enable Always On Support'
      - Click on 'Connect...' to authenticate to each node in the availability group
      - Click on 'OK' to apply

## Configuration of SQL Server Master Encryption Key/Server Certificate
1. Repeat these instructions on each node
2. Login to each machine and open SSMS
3. On the primary node (Use this script for the SSRS DB instance), open 'provisionTDEPrimaryNode.sql' stored in 'C:\ComputerConfiguration\Scripts'
4. Populate the empty strings as instructed in the comments of the script
5. Execute the query
6. Ensure that certificates and keys are backed up remotely
7. On the secondary nodes, open 'provisionTDESecondaryNode.sql' stored in 'C:\ComputerConfiguration\Scripts'
8. Populate the empty strings as instructed in the comments of the script
9. Execute the query
10. Ensure that certificates and keys are backed up remotely

## SSRS Specific Notes
1. Login to the machine as the Windows Admin domain user used previously to join the machine to the domain
2. Connect to the database engine as one of the sql breakglass logins, can be Windows/SQL Auth, it doesn't matter
3. Restore the ReportServer and ReportServerTempDB databases to the server
4. Upgrade the compatibility level to be the same as the instance e.g. SQL Server 2014 > SQL Server 2019
5. Create a login and add the DOMAIN\svcMSSQLRS$ as a user to **both** databases, ensure that the default schema is dbo and the database roles have been set
   - db_owner
   - RS_Exec
6. Copy the backed up SSRS encryption key to the new host
7. Open the SSRS Configuration Manager
8. Configure the Service account to be DOMAIN\svcMSSQLRS$
9. Set the databases to be the one you just restored and use DOMAIN\svcMSSQLRS$ as the credential in service account mode
10. Restore the encryption key that you copied over from the previous host
11. Generate a new encryption key and ensure that it is backed up securely to a location such as key vault
12. Configure the Web Service URL, you may need to install TLS certificates if HTTPS will be used
13. Configure the Report Manager URL
14. Configure E-mail settings, sender address should be the same as what is deployed as clients will likely have that e-mail address whitelisted