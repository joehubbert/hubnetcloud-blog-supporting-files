﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure DirectDebitsCleanAccountHolderDetails1of2 @seedA int, @seedB int
as
	set nocount on;
	--[AccountHolderDetails];
	-- the work table
	select 
	 [AccountHolderDetailsId]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Surname]) [Surname]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine1]) [AddressLine1]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine2]) [AddressLine2]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine3]) [AddressLine3]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine4]) [AddressLine4]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PostCode]) [PostCode]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [TitileInitials]) [TitileInitials]
	into [DirectDebits].[dbo].[AccountHolderDetails_WORK] 
	from [DirectDebits].[dbo].[AccountHolderDetails];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [DirectDebits]; create clustered index [CIX_AccountHolderDetails_WORK(AccountHolderDetailsId)] on AccountHolderDetails_WORK(AccountHolderDetailsId);';
	exec (@sql);
return 0