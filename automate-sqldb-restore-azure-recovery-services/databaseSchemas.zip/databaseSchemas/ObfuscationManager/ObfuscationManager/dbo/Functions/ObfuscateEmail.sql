﻿CREATE FUNCTION [dbo].[ObfuscateEmail]
(@seedA INT, @seedB INT, @email NVARCHAR (MAX))
RETURNS NVARCHAR (MAX)
AS
 EXTERNAL NAME [ObfuscationManager].[UserDefinedFunctions].[ObfuscateEmail]

