--PLEASE ENSURE THAT ALL REQUIRED VALUES HAVE BEEN POPULATED BEFORE RUNNING!!

-- Use <subscriptioncode>-<environmentcode>-sql-<aoag/rs>-master-key-password from relevant key vault for the password
CREATE MASTER KEY ENCRYPTION BY PASSWORD = ''

-- Always use the same prefix C:\ComputerConfiguration\EncryptionKeys\SQLTDE
-- Backup file should follow the format of <ComputerConfigurationDirectory>\<EncryptionKeysDirectory>\<ComputerName>-server-master-key.bak e.g. C:\ComputerConfiguration\EncryptionKeys\SQLTDE\NPVMIDEVSQLDB01-server-master-key.bak
-- Use <subscriptioncode>-<environmentcode>-sql-<aoag/rs>-master-key-backup-password from relevant key vault for the password
BACKUP MASTER KEY TO FILE = '.bak'
ENCRYPTION BY PASSWORD = ''

-- Certificate name should be the name of the cluster e.g. NPDEVSQLCLUSTER
-- File path for the certificate should be UNC path of Primary Node SQL Certificates Backup Share e.g. \\NPVMIDEVSQLDB01\SQLCertificates$\SQLTDE\NPVMIDEVSQLDB01-server-certificate.cer
-- File path for the private key should be UNC path of Primary Node SQL Encryption Keys Backup Share e.g. \\NPVMIDEVSQLDB01\SQLEncryptionKeys$\SQLTDE\NPVMIDEVSQLDB01-server-certificate-private-key.pvk
-- Use <subscriptioncode>-<environmentcode>-sql-<aoag/rs>-server-certificate-backup-password from relevant key vault for the password
CREATE CERTIFICATE EXAMPLE
FROM FILE = ''
WITH PRIVATE KEY (
    FILE = '',
    DECRYPTION BY PASSWORD = ''
)