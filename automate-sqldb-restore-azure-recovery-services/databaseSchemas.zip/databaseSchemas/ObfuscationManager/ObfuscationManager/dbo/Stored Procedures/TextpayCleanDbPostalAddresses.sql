﻿/*
Clean the postal addresses by replacing originals with fictional postal address
*/
create procedure TextpayCleanDbPostalAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Textpay].[dbo].[Blacklist] SET [MobileNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MobileNumber]);
	UPDATE [Textpay].[dbo].[Sessions] SET [IPAddress] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [IPAddress]);
	UPDATE [Textpay].[dbo].[Users] SET [MobileNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MobileNumber]);
return 0