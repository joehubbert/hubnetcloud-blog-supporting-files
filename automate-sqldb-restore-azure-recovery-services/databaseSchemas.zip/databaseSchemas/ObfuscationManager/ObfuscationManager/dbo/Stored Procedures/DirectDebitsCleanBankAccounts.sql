﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure DirectDebitsCleanBankAccounts @seedA int, @seedB int
as
	set nocount on;
	--[BankAccounts];
	-- the work table
	select 
	 [BankAccountId]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]) [AccountName]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber]) [AccountNumber]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SortCode]) [SortCode]
	into [DirectDebits].[dbo].[BankAccounts_WORK] 
	from [DirectDebits].[dbo].[BankAccounts];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [DirectDebits]; create clustered index [CIX_BankAccounts_WORK(BankAccountId)] on BankAccounts_WORK(BankAccountId);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @BankAccounts table(BankAccountId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [DirectDebits].[dbo].[BankAccounts] 
		SET 
		 [AccountName] = [DirectDebits].[dbo].[BankAccounts_WORK].[AccountName]
		,[AccountNumber] = [DirectDebits].[dbo].[BankAccounts_WORK].[AccountNumber]
		,[SortCode] = [DirectDebits].[dbo].[BankAccounts_WORK].[SortCode]
		output INSERTED.BankAccountId into @BankAccounts
		from [DirectDebits].[dbo].[BankAccounts_WORK]
		where [DirectDebits].[dbo].[BankAccounts_WORK].[BankAccountId] = [DirectDebits].[dbo].[BankAccounts].[BankAccountId];
		--remove the records already updated
		delete from [DirectDebits].[dbo].[BankAccounts_WORK] where BankAccountId in (select BankAccountId from @BankAccounts);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @BankAccounts;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [DirectDebits].[dbo].[BankAccounts_WORK];
return 0