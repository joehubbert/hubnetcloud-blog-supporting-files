﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure PaymentsCleanIncomingCustomerDirectDebitPayments @seedA int, @seedB int
as
	set nocount on;
	--[IncomingCustomerDirectDebitPayments];
	-- the work table
	select 
	 [PaymentId]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]) [AccountName] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber]) [AccountNumber] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [BACSReference]) [BACSReference] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SortCode]) [SortCode] 
	into [Payments].[dbo].[IncomingCustomerDirectDebitPayments_WORK] 
	from [Payments].[dbo].[IncomingCustomerDirectDebitPayments];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [Payments]; create clustered index [CIX_IncomingCustomerDirectDebitPayments_WORK(PaymentId)] on IncomingCustomerDirectDebitPayments_WORK(PaymentId);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @IncomingCustomerDirectDebitPayments table(PaymentId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [Payments].[dbo].[IncomingCustomerDirectDebitPayments] 
		SET 
		 [AccountName] = [Payments].[dbo].[IncomingCustomerDirectDebitPayments_WORK].[AccountName] 
		,[AccountNumber] = [Payments].[dbo].[IncomingCustomerDirectDebitPayments_WORK].[AccountNumber] 
		,[BACSReference] = [Payments].[dbo].[IncomingCustomerDirectDebitPayments_WORK].[BACSReference] 
		,[SortCode] = [Payments].[dbo].[IncomingCustomerDirectDebitPayments_WORK].[SortCode] 
		output INSERTED.PaymentId into @IncomingCustomerDirectDebitPayments
		from [Payments].[dbo].[IncomingCustomerDirectDebitPayments_WORK]
		where [Payments].[dbo].[IncomingCustomerDirectDebitPayments_WORK].[PaymentId] = [Payments].[dbo].[IncomingCustomerDirectDebitPayments].[PaymentId];
		--remove the records already updated
		delete from [Payments].[dbo].[IncomingCustomerDirectDebitPayments_WORK] where PaymentId in (select PaymentId from @IncomingCustomerDirectDebitPayments);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @IncomingCustomerDirectDebitPayments;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [Payments].[dbo].[IncomingCustomerDirectDebitPayments_WORK];
return 0