﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure DirectDebitsCleanTheRest @seedA int, @seedB int
as
	set nocount on;
	--[TheRest];
	UPDATE [DirectDebits].[dbo].[ApiLog] SET [LastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LastName]);
	UPDATE [DirectDebits].[dbo].[EmailNotifications] SET [EmailAddress] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [EmailAddress]);
	UPDATE [DirectDebits].[dbo].[ImportedInstructions_UpdateEmailInstruction] SET [EmailAddress] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [EmailAddress]);
	UPDATE [DirectDebits].[dbo].[UpdateAccountHolderActionProperties] SET [EmailAddress] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [EmailAddress]);
	UPDATE [DirectDebits].[dbo].[ImportedAccountHolderDetails] SET [Address1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Address1]);
	UPDATE [DirectDebits].[dbo].[ImportedAccountHolderDetails] SET [Address2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Address2]);
	UPDATE [DirectDebits].[dbo].[ImportedAccountHolderDetails] SET [Address3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Address3]);
	UPDATE [DirectDebits].[dbo].[ImportedAccountHolderDetails] SET [Address4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Address4]);
	UPDATE [DirectDebits].[dbo].[ImportedAccountHolderDetails] SET [PostCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PostCode]);
	UPDATE [DirectDebits].[dbo].[ImportedAccountHolderDetails] SET [TitleAndInitials] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [TitleAndInitials]);
	UPDATE [DirectDebits].[dbo].[ImportedBankAccountDetails] SET [AccountNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber]);
	UPDATE [DirectDebits].[dbo].[ImportedBankAccountDetails] SET [SortCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SortCode]);
	UPDATE [DirectDebits].[dbo].[ImportedBankAccountHolderDetails] SET [Address1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Address1]);
	UPDATE [DirectDebits].[dbo].[ImportedBankAccountHolderDetails] SET [Address2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Address2]);
	UPDATE [DirectDebits].[dbo].[ImportedBankAccountHolderDetails] SET [Address3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Address3]);
	UPDATE [DirectDebits].[dbo].[ImportedBankAccountHolderDetails] SET [Address4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Address4]);
	UPDATE [DirectDebits].[dbo].[ImportedBankAccountHolderDetails] SET [PostCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PostCode]);
	UPDATE [DirectDebits].[dbo].[ImportedBankAccountHolderDetails] SET [TitleAndInitials] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [TitleAndInitials]);
	UPDATE [DirectDebits].[dbo].[ImportedInstructions_UpdateMobileNumberInstruction] SET [MobileNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MobileNumber]);
	UPDATE [DirectDebits].[dbo].[ImportedInstructions_VariableDdiPaymentInstruction] SET [AddressLine1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine1]);
	UPDATE [DirectDebits].[dbo].[ImportedInstructions_VariableDdiPaymentInstruction] SET [Postcode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Postcode]);
	UPDATE [DirectDebits].[dbo].[NotificationQueue] SET [Address] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Address]);
	UPDATE [DirectDebits].[dbo].[SMSNotificationDetails] SET [MobileNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MobileNumber]);
	UPDATE [DirectDebits].[dbo].[UpdateAccountHolderActionProperties] SET [MobileNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MobileNumber]);
	UPDATE [DirectDebits].[dbo].[ImportedBankAccountDetails] SET [AccountName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]);
	UPDATE [DirectDebits].[dbo].[ImportedBankAccountHolderDetails] SET [BillingName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [BillingName]);
	UPDATE [DirectDebits].[dbo].[NotificationQueue] SET [Lastname] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Lastname]);
return 0