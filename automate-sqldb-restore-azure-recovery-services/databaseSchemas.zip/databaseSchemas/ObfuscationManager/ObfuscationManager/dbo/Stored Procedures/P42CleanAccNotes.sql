﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure P42CleanAccNotes @seedA int, @seedB int
as
	set nocount on;
	--[AP_ACCNOTES];
	-- the work table
	select 
	 [AP_RECNO]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_NOTES]) [AP_NOTES]
	into [P42].[dbo].[AP_ACCNOTES_WORK] 
	from [P42].[dbo].[AP_ACCNOTES];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [P42]; create clustered index [CIX_AP_ACCNOTES_WORK(AP_RECNO)] on AP_ACCNOTES_WORK(AP_RECNO);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @AP_ACCNOTES table(AP_RECNO int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [P42].[dbo].[AP_ACCNOTES] 
		SET 
		 [AP_NOTES] = [P42].[dbo].[AP_ACCNOTES_WORK].[AP_NOTES] 
		output INSERTED.AP_RECNO into @AP_ACCNOTES
		from [P42].[dbo].[AP_ACCNOTES_WORK]
		where [P42].[dbo].[AP_ACCNOTES_WORK].[AP_RECNO] = [P42].[dbo].[AP_ACCNOTES].[AP_RECNO];
		--remove the records already updated
		delete from [P42].[dbo].[AP_ACCNOTES_WORK] where AP_RECNO in (select AP_RECNO from @AP_ACCNOTES);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @AP_ACCNOTES;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [P42].[dbo].[AP_ACCNOTES_WORK];
return 0