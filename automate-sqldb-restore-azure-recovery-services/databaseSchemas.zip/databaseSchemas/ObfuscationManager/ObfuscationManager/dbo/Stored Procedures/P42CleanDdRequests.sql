﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure P42CleanDdRequests @seedA int, @seedB int
as
	set nocount on;
	--[DD_REQUESTS];
	-- the work table
	select 
	 [id]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [surname]) [surname]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [billing_name]) [billing_name]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [title_initials]) [title_initials]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [bank_sort_code]) [bank_sort_code]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [billing_postcode]) [billing_postcode]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [primary_postcode]) [primary_postcode]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [billing_address_1]) [billing_address_1]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [billing_address_2]) [billing_address_2]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [billing_address_3]) [billing_address_3]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [billing_address_4]) [billing_address_4]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [primary_address_1]) [primary_address_1]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [primary_address_2]) [primary_address_2]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [primary_address_3]) [primary_address_3]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [primary_address_4]) [primary_address_4]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [bank_account_name]) [bank_account_name]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [secondary_postcode]) [secondary_postcode]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [bank_account_number]) [bank_account_number]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [secondary_address_1]) [secondary_address_1]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [secondary_address_2]) [secondary_address_2]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [secondary_address_3]) [secondary_address_3]
		,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [secondary_address_4]) [secondary_address_4]
	into [P42].[dbo].[DD_REQUESTS_WORK] 
	from [P42].[dbo].[DD_REQUESTS];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [P42]; create clustered index [CIX_DD_REQUESTS_WORK(id)] on DD_REQUESTS_WORK(id);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @DD_REQUESTS table(id int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [P42].[dbo].[DD_REQUESTS] 
		SET 
		 [bank_account_number] = [P42].[dbo].[DD_REQUESTS_WORK].[bank_account_number]
		,[bank_sort_code] = [P42].[dbo].[DD_REQUESTS_WORK].[bank_sort_code]
		,[billing_address_1] = [P42].[dbo].[DD_REQUESTS_WORK].[billing_address_1]
		,[billing_address_2] = [P42].[dbo].[DD_REQUESTS_WORK].[billing_address_2]
		,[billing_address_3] = [P42].[dbo].[DD_REQUESTS_WORK].[billing_address_3]
		,[billing_address_4] = [P42].[dbo].[DD_REQUESTS_WORK].[billing_address_4]
		,[billing_postcode] = [P42].[dbo].[DD_REQUESTS_WORK].[billing_postcode]
		,[primary_address_1] = [P42].[dbo].[DD_REQUESTS_WORK].[primary_address_1]
		,[primary_address_2] = [P42].[dbo].[DD_REQUESTS_WORK].[primary_address_2]
		,[primary_address_3] = [P42].[dbo].[DD_REQUESTS_WORK].[primary_address_3]
		,[primary_address_4] = [P42].[dbo].[DD_REQUESTS_WORK].[primary_address_4]
		,[primary_postcode] = [P42].[dbo].[DD_REQUESTS_WORK].[primary_postcode]
		,[secondary_address_1] = [P42].[dbo].[DD_REQUESTS_WORK].[secondary_address_1]
		,[secondary_address_2] = [P42].[dbo].[DD_REQUESTS_WORK].[secondary_address_2]
		,[secondary_address_3] = [P42].[dbo].[DD_REQUESTS_WORK].[secondary_address_3]
		,[secondary_address_4] = [P42].[dbo].[DD_REQUESTS_WORK].[secondary_address_4]
		,[secondary_postcode] = [P42].[dbo].[DD_REQUESTS_WORK].[secondary_postcode]
		,[title_initials] = [P42].[dbo].[DD_REQUESTS_WORK].[title_initials]
		,[bank_account_name] = [P42].[dbo].[DD_REQUESTS_WORK].[bank_account_name]
		,[billing_name] = [P42].[dbo].[DD_REQUESTS_WORK].[billing_name]
		,[surname] = [P42].[dbo].[DD_REQUESTS_WORK].[surname]
		output INSERTED.id into @DD_REQUESTS
		from [P42].[dbo].[DD_REQUESTS_WORK]
		where [P42].[dbo].[DD_REQUESTS_WORK].[id] = [P42].[dbo].[DD_REQUESTS].[id];
		--remove the records already updated
		delete from [P42].[dbo].[DD_REQUESTS_WORK] where id in (select id from @DD_REQUESTS);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @DD_REQUESTS;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [P42].[dbo].[DD_REQUESTS_WORK];
return 0