﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure DoshCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Dosh].[dbo].[Accounts] SET [AccountName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]);
	UPDATE [Dosh].[dbo].[FSM_Updates] SET [Forename] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Forename]);
	UPDATE [Dosh].[dbo].[FSM_Updates] SET [LegalSurname] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LegalSurname]);
	UPDATE [Dosh].[dbo].[Institutions] SET [ContactForename] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [ContactForename]);
	UPDATE [Dosh].[dbo].[Institutions] SET [ContactSurname] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [ContactSurname]);
	UPDATE [Dosh].[dbo].[Users] SET [FirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FirstName]);
	UPDATE [Dosh].[dbo].[Users] SET [Surname] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Surname]);
return 0