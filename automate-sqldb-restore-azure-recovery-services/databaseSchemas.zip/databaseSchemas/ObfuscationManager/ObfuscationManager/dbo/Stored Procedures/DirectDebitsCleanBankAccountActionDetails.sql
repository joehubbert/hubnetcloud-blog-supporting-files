﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure DirectDebitsCleanBankAccountActionDetails @seedA int, @seedB int
as
	set nocount on;
	--[BankAccountActionDetails];
	-- the work table
	select 
	 [BankAccountActionDetailsId]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]) [AccountName]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber]) [AccountNumber]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SortCode]) [SortCode]
	into [DirectDebits].[dbo].[BankAccountActionDetails_WORK] 
	from [DirectDebits].[dbo].[BankAccountActionDetails];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [DirectDebits]; create clustered index [CIX_BankAccountActionDetails_WORK(BankAccountActionDetailsId)] on BankAccountActionDetails_WORK(BankAccountActionDetailsId);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @BankAccountActionDetails table(BankAccountActionDetailsId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [DirectDebits].[dbo].[BankAccountActionDetails] 
		SET 
		 [AccountName] = [DirectDebits].[dbo].[BankAccountActionDetails_WORK].[AccountName]
		,[AccountNumber] = [DirectDebits].[dbo].[BankAccountActionDetails_WORK].[AccountNumber]
		,[SortCode] = [DirectDebits].[dbo].[BankAccountActionDetails_WORK].[SortCode]
		output INSERTED.BankAccountActionDetailsId into @BankAccountActionDetails
		from [DirectDebits].[dbo].[BankAccountActionDetails_WORK]
		where [DirectDebits].[dbo].[BankAccountActionDetails_WORK].[BankAccountActionDetailsId] = [DirectDebits].[dbo].[BankAccountActionDetails].[BankAccountActionDetailsId];
		--remove the records already updated
		delete from [DirectDebits].[dbo].[BankAccountActionDetails_WORK] where BankAccountActionDetailsId in (select BankAccountActionDetailsId from @BankAccountActionDetails);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @BankAccountActionDetails;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [DirectDebits].[dbo].[BankAccountActionDetails_WORK];
return 0