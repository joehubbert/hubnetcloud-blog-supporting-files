Import-Module ActiveDirectory
Add-KdsRootKey -EffectiveTime ((Get-Date).Addhours(-10)) 
$activeDirectoryDomainFQDN = '<DomainFQDN>'
$aoagServerList = @('<primaryNodeName>','<secondaryNodeName>','<secondaryNodeName>')
$rsServerList = @('<reportingServicesServerName>')

$aoagServerList = $aoagServerList.ForEach{ return (Get-ADComputer $_)  }
Write-Output $aoagServerList

$rsServerList = $rsServerList.ForEach{ return (Get-ADComputer $_)  }
Write-Output $rsServerList

New-ADServiceAccount `
-Name svcMSSQLAOAGDB `
-Description 'Service Account for MSSQL Database Engine in AlwaysOn-Availability Group' `
-DNSHostName "svcmssqlaoagdb.$activeDirectoryDomainFQDN" `
-ManagedPasswordIntervalInDays 7 `
-PrincipalsAllowedToRetrieveManagedPassword $aoagServerList `
-TrustedForDelegation $true `
-Enabled $true `
-PassThru

New-ADServiceAccount `
-Name svcMSSQLAOAGIS `
-Description 'Service Account for MSSQL Integration Services in AlwaysOn-Availability Group' `
-DNSHostName "svcmssqlaoagis.$activeDirectoryDomainFQDN" `
-ManagedPasswordIntervalInDays 7 `
-PrincipalsAllowedToRetrieveManagedPassword $aoagServerList `
-TrustedForDelegation $true `
-Enabled $true `
-PassThru

New-ADServiceAccount `
-Name svcMSSQLAOAGA `
-Description 'Service Account for MSSQL Agent in AlwaysOn-Availability Group' `
-DNSHostName "svcmssqlaoaga.$activeDirectoryDomainFQDN" `
-ManagedPasswordIntervalInDays 7 `
-PrincipalsAllowedToRetrieveManagedPassword $aoagServerList `
-TrustedForDelegation $true `
-Enabled $true `
-PassThru

New-ADServiceAccount `
-Name svcMSSQLRS `
-Description 'Service Account for MSSQL Reporting Services' `
-DNSHostName "svcmssqlrs.$activeDirectoryDomainFQDN" `
-ManagedPasswordIntervalInDays 7 `
-PrincipalsAllowedToRetrieveManagedPassword $rsServerList `
-TrustedForDelegation $true `
-Enabled $true `
-PassThru

New-ADServiceAccount `
-Name svcMSSQLRSDB `
-Description 'Service Account for MSSQL Database Engine for SQL Server Reporting Services Instance' `
-DNSHostName "svcmssqlrsdb.$activeDirectoryDomainFQDN" `
-ManagedPasswordIntervalInDays 7 `
-PrincipalsAllowedToRetrieveManagedPassword $rsServerList `
-TrustedForDelegation $true `
-Enabled $true `
-PassThru

New-ADServiceAccount `
-Name svcMSSQLRSA `
-Description 'Service Account for MSSQL Agent for SQL Server Reporting Services Instance' `
-DNSHostName "svcmssqlrsa.$activeDirectoryDomainFQDN" `
-ManagedPasswordIntervalInDays 7 `
-PrincipalsAllowedToRetrieveManagedPassword $rsServerList `
-TrustedForDelegation $true `
-Enabled $true `
-PassThru