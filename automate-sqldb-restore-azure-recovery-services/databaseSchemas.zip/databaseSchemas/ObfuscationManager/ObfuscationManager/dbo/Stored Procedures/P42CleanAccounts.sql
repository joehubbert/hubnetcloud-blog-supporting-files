﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure P42CleanAccounts @seedA int, @seedB int
as
	set nocount on;
	--[AP_ACCOUNTS]
	-- the work table
	select 
	 [AP_RECNO]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD1]) [AP_ADD1]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD2]) [AP_ADD2]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD3]) [AP_ADD3]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD4]) [AP_ADD4]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_POSTCODE]) [AP_POSTCODE]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_TITLEINITS]) [AP_TITLEINITS]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_NAMEONCARD]) [AP_NAMEONCARD]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SURNAME]) [AP_SURNAME]
	into [P42].[dbo].[AP_ACCOUNTS_WORK] 
	from [P42].[dbo].[AP_ACCOUNTS];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [P42]; create clustered index [CIX_AP_ACCOUNTS_WORK(AP_RECNO)] on AP_ACCOUNTS_WORK(AP_RECNO);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @AP_ACCOUNTS table(AP_RECNO int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [P42].[dbo].[AP_ACCOUNTS] 
		SET 
		 [AP_ADD1] = [P42].[dbo].[AP_ACCOUNTS_WORK].[AP_ADD1]
		,[AP_ADD2] = [P42].[dbo].[AP_ACCOUNTS_WORK].[AP_ADD2]
		,[AP_ADD3] = [P42].[dbo].[AP_ACCOUNTS_WORK].[AP_ADD3]
		,[AP_ADD4] = [P42].[dbo].[AP_ACCOUNTS_WORK].[AP_ADD4]
		,[AP_POSTCODE] = [P42].[dbo].[AP_ACCOUNTS_WORK].[AP_POSTCODE]
		,[AP_TITLEINITS] = [P42].[dbo].[AP_ACCOUNTS_WORK].[AP_TITLEINITS]
		,[AP_NAMEONCARD] = [P42].[dbo].[AP_ACCOUNTS_WORK].[AP_NAMEONCARD]
		,[AP_SURNAME] = [P42].[dbo].[AP_ACCOUNTS_WORK].[AP_SURNAME]
		output INSERTED.AP_RECNO into @AP_ACCOUNTS
		from [P42].[dbo].[AP_ACCOUNTS_WORK]
		where [P42].[dbo].[AP_ACCOUNTS_WORK].[AP_RECNO] = [P42].[dbo].[AP_ACCOUNTS].[AP_RECNO];
		--remove the records already updated
		delete from [P42].[dbo].[AP_ACCOUNTS_WORK] where AP_RECNO in (select AP_RECNO from @AP_ACCOUNTS);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @AP_ACCOUNTS;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [P42].[dbo].[AP_ACCOUNTS_WORK];
return 0