﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure P42CleanCardRequests @seedA int, @seedB int
as
	set nocount on;
	--[CARD_REQUESTS];
	-- the work table
	select 
	 [id]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [primary_address_1]) [primary_address_1]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [primary_address_2]) [primary_address_2]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [primary_address_3]) [primary_address_3]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [primary_address_4]) [primary_address_4]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [primary_postcode]) [primary_postcode]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [secondary_address_1]) [secondary_address_1]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [secondary_address_2]) [secondary_address_2]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [secondary_address_3]) [secondary_address_3]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [secondary_address_4]) [secondary_address_4]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [secondary_postcode]) [secondary_postcode]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [title_initials]) [title_initials]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [name_on_card]) [name_on_card]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [surname]) [surname]
	into [P42].[dbo].[CARD_REQUESTS_WORK] 
	from [P42].[dbo].[CARD_REQUESTS];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [P42]; create clustered index [CIX_CARD_REQUESTS_WORK(id)] on CARD_REQUESTS_WORK(id);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @CARD_REQUESTS table(id int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [P42].[dbo].[CARD_REQUESTS] 
		SET 
		 [primary_address_1] = [P42].[dbo].[CARD_REQUESTS_WORK].[primary_address_1]
		,[primary_address_2] = [P42].[dbo].[CARD_REQUESTS_WORK].[primary_address_2]
		,[primary_address_3] = [P42].[dbo].[CARD_REQUESTS_WORK].[primary_address_3]
		,[primary_address_4] = [P42].[dbo].[CARD_REQUESTS_WORK].[primary_address_4]
		,[primary_postcode] = [P42].[dbo].[CARD_REQUESTS_WORK].[primary_postcode]
		,[secondary_address_1] = [P42].[dbo].[CARD_REQUESTS_WORK].[secondary_address_1]
		,[secondary_address_2] = [P42].[dbo].[CARD_REQUESTS_WORK].[secondary_address_2]
		,[secondary_address_3] = [P42].[dbo].[CARD_REQUESTS_WORK].[secondary_address_3]
		,[secondary_address_4] = [P42].[dbo].[CARD_REQUESTS_WORK].[secondary_address_4]
		,[secondary_postcode] = [P42].[dbo].[CARD_REQUESTS_WORK].[secondary_postcode]
		,[title_initials] = [P42].[dbo].[CARD_REQUESTS_WORK].[title_initials]
		,[name_on_card] = [P42].[dbo].[CARD_REQUESTS_WORK].[name_on_card]
		,[surname] = [P42].[dbo].[CARD_REQUESTS_WORK].[surname]
		output INSERTED.id into @CARD_REQUESTS
		from [P42].[dbo].[CARD_REQUESTS_WORK]
		where [P42].[dbo].[CARD_REQUESTS_WORK].[id] = [P42].[dbo].[CARD_REQUESTS].[id];
		--remove the records already updated
		delete from [P42].[dbo].[CARD_REQUESTS_WORK] where id in (select id from @CARD_REQUESTS);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @CARD_REQUESTS;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [P42].[dbo].[CARD_REQUESTS_WORK];
return 0