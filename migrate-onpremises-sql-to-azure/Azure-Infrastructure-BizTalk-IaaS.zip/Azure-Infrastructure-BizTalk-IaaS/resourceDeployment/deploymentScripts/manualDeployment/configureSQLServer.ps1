param
(
    [Parameter(Mandatory)][string]$activeDirectoryDomainFullyQualifiedName,
    [Parameter(Mandatory)][string]$activeDirectoryDomainNETBIOSName,
    [Parameter(Mandatory)][string]$sqlServerBreakGlassAdminPassword,
    [Parameter(Mandatory)][string]$sqlServerBreakGlassAdminUsername,
    [Parameter(Mandatory)][string]$sqlServerDevOpsDeployUserPassword,
    [Parameter(Mandatory)][string]$sqlServerDevOpsDeployUserUsername,
    [Parameter(Mandatory)][string]$sqlServerSAAccountPassword,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterSQLListenerName
)

$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$progressPreference = 'SilentlyContinue'
$scriptLogFileName = 'configureSQLServer-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"
$sqlServerBreakGlassAdminPasswordForCredential = ConvertTo-SecureString $sqlServerBreakGlassAdminPassword -AsPlainText -Force
$sqlServerBreakGlassAdminCredential = New-Object System.Management.Automation.PSCredential($sqlServerBreakGlassAdminUsername, $sqlServerBreakGlassAdminPasswordForCredential)
$sqlServerDatabaseMailAccountDisplayName = "MSSQLDB Mail - $windowsServerFailoverClusterSQLListenerName"
$sqlServerDatabaseMailAccountEmailAddress = "$windowsServerFailoverClusterSQLListenerName@$activeDirectoryDomainFullyQualifiedName"
$sqlServerDatabaseMailAccountSMTPServer = "smtp.$activeDirectoryDomainFullyQualifiedName"
$sqlServerSAAccountPasswordForCredential = ConvertTo-SecureString $sqlServerSAAccountPassword -AsPlainText -Force
$sqlServerSAAccountCredential = New-Object System.Management.Automation.PSCredential('sa', $sqlServerSAAccountPasswordForCredential)

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Create Breakglass Login
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerSAAccountCredential `
    -Database 'master' `
    -Query "CREATE LOGIN [$sqlServerBreakGlassAdminUsername] WITH PASSWORD = '$sqlServerBreakGlassAdminPassword' `
    GO `
    ALTER SERVER ROLE sysadmin ADD MEMBER[$sqlServerBreakGlassAdminUsername]" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "The breakglass login has been successfully created on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the breakglass login on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Disable sa Login
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "ALTER LOGIN [sa] DISABLE" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "The sa login has been sucessfully disabled on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when disabling the sa login on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create DevOps Deploy User Login
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "CREATE LOGIN [$sqlServerDevOpsDeployUserUsername] WITH PASSWORD = '$sqlServerDevOpsDeployUserPassword' `
    GO `
    ALTER SERVER ROLE sysadmin ADD MEMBER[$sqlServerDevOpsDeployUserUsername]" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "The DevOpsDeployUser login has been successfully created on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the DevOpsDeployUser login on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Enable Require Distributed Transactions for server to server communication (Needed for BizTalk - Can be removed once BizTalk has been decommissioned.)
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "EXEC sp_configure 'Remote Proc Trans', 1; RECONFIGURE; `
    GO" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "'Require Distributed Transactions for server to server communication' has been enabled on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when enabling 'Require Distributed Transactions for server to server communication' on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Enable Ad Hoc Distributed Queries (Needed for BizTalk - Can be removed once BizTalk has been decommissioned.)
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "EXEC sp_configure 'Show Advanced Options', 1; RECONFIGURE; `
    GO `
    EXEC sp_configure 'Ad Hoc Distributed Queries', 1; RECONFIGURE; `
    GO" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "Ad Hoc Distributed Queries have been enabled on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when enabling Ad Hoc Distributed Queries on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Enable XACT_ABORT
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "SET XACT_ABORT ON" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "XACT_ABORT has been enabled on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when enabling XACT_ABORT on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Enable Database Mail XPs
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "sp_configure 'Show Advanced Options', 1; RECONFIGURE; `
    GO `
    sp_configure 'Database Mail XPs', 1; RECONFIGURE" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "Database Mail XPs has been successfully enabled on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when enabling Database Mail XPs on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Add Database Mail Profile
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'msdb' `
    -Query "EXEC [dbo].[sysmail_add_profile_sp] `
    @profile_name = 'MSSQLDBMailProfile', `
    @description = 'Profile for sending MSSQL Database Mail.'" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "The Database Mail Profile 'MSSQLDBMailProfile' has been successfully created on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the Database Mail Profile 'MSSQLDBMailProfile' on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Add Database Mail Account
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'msdb' `
    -Query "EXEC [dbo].[sysmail_add_account_sp] `
    @account_Name = 'MSSQLDBMailAccount', `
    @description = 'Account for sending MSSQL Database Mail.', `
    @email_address = '$sqlServerDatabaseMailAccountEmailAddress', `
    @display_name = '$sqlServerDatabaseMailAccountDisplayName', `
    @mailserver_name = '$sqlServerDatabaseMailAccountSMTPServer', `
    @replyto_address = 'IT@allpay.net', `
    @port = 25" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "The Database Mail Account 'MSSQLDBMailAccount' has been successfully created on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the Database Mail Account 'MSSQLDBMailAccount' on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Add Database Mail Account to Database Mail Profile
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'msdb' `
    -Query "EXEC [dbo].[sysmail_add_profileaccount_sp] `
    @profile_name = 'MSSQLDBMailProfile', `
    @account_name = 'MSSQLDBMailAccount', `
    @sequence_number = 1" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "The Database Mail Account 'MSSQLDBMailAccount' has been successfully added to the Database Mail Profile 'MSSQLDBMailProfile' on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when adding the Database Mail Account 'MSSQLDBMailAccount' to the Database Mail Profie 'MSSQLDBMailProfile' on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure SQL Server Agent To Use Database Mail
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "EXEC [dbo].[xp_instance_regwrite] N'HKEY_LOCAL_MACHINE', `
    N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', `
    N'UseDatabaseMail', `
    N'REG_DWORD', 1`
    EXEC [dbo].[xp_instance_regwrite] N'HKEY_LOCAL_MACHINE', `
    N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', `
    N'DatabaseMailProfile', `
    N'REG_SZ', `
    N'MSSQLDBMailProfile'" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "SQL Server Agent has been enabled to use the Database Mail Profile 'MSSQLDBMailProfile' on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when SQL Server Agent to use the Database Mail Profie 'MSSQLDBMailProfile' on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create Operator for SQL Server Agent
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'msdb' `
    -Query "EXEC [dbo].[sp_add_operator] `
    @name = 'DBASupport', `
    @enabled = 1, `
    @email_address = 'InfrastructureTeam@allpay.net; IT@allpay.net'" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "The operator 'DBASupport' has been added to the SQL Server Agent on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when adding the operator 'DBASupport' to the SQL Server Agent on the SQL instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure TempDB File Sizes
$tempDBFileList = @('tempdev', 'temp2', 'temp3', 'temp4', 'templog')

foreach($file in $tempDBFileList)
{
    try
    {
    Start-Job -ArgumentList $file, $scriptLogPath, $sqlServerBreakGlassAdminCredential, $sqlServerInstanceName, $tempDBFileSize -ScriptBlock {
    param
    (
        $file,
        $scriptLogPath,
        [PSCredential]$sqlServerBreakGlassAdminCredential,
        $sqlServerInstanceName,
        $tempDBFileSize
    )
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'tempdb' `
    -Query "ALTER DATABASE [tempdb] MODIFY FILE (NAME = $file, SIZE = $tempDBFileSize MB, MAXSIZE = $tempDBFileSize MB)" `
    -ServerInstance $windowsServerFailoverClusterSQLListenerName
    $currentTimestamp = Get-Date
    $outputText = "The tempdb file $file has been changed to $tempDBFileSize MB on the SQL Instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
    }
    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $currentTimestamp = Get-Date
        $outputText = "An error occured when setting the tempdb file $file to $tempDBFileSize MB on the SQL Instance $windowsServerFailoverClusterSQLListenerName at $currentTimestamp with the following error '$errorMessage'."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
}

Get-Job | Wait-Job

$currentTimestamp = Get-Date
$outputText = "Execution of configureSQLServer.ps1 successfully completed on $windowsServerFailoverClusterSQLListenerName at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"