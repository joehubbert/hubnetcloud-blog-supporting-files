$clusterWitnessDiskName = 'ClusterWitness'
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$diskFormat = 'NTFS'
$diskPartitionStyle = 'GPT'
$errorActionPreference = 'Stop'
$msdtcDiskName = 'MSDTC'
$progressPreference = 'SilentlyContinue'
$scriptLogFileName = 'initialiseDisk-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"
$sqlBackupDiskName = 'SQLBackup'
$sqlDataDiskName = 'SQLData'
$sqlLogDiskName = 'SQLLog'
$sqlTempDBDiskName = 'SQLTempDB'

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Setup Data Disks
try
{
    Initialize-Disk -Number 2 -PartitionStyle $diskPartitionStyle -PassThru | `
    New-Volume -FileSystem $diskFormat -DriveLetter F -FriendlyName $clusterWitnessDiskName
    $currentTimestamp = Get-Date
    $outputText = "The data disk $clusterWitnessDiskName has been successfully initialised on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to initialise the data disk $clusterWitnessDiskName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Initialize-Disk -Number 3 -PartitionStyle $diskPartitionStyle -PassThru | `
    New-Volume -FileSystem $diskFormat -DriveLetter G -FriendlyName $msdtcDiskName
    $currentTimestamp = Get-Date
    $outputText = "The data disk $msdtcDiskName has been successfully initialised on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to initialise the data disk $msdtcDiskName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Initialize-Disk -Number 4 -PartitionStyle $diskPartitionStyle -PassThru | `
    New-Volume -FileSystem $diskFormat -DriveLetter H -FriendlyName $sqlDataDiskName
    $currentTimestamp = Get-Date
    $outputText = "The data disk $sqlDataDiskName has been successfully initialised on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to initialise the data disk $sqlDataDiskName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Initialize-Disk -Number 5 -PartitionStyle $diskPartitionStyle -PassThru | `
    New-Volume -FileSystem $diskFormat -DriveLetter I -FriendlyName $sqlLogDiskName
    $currentTimestamp = Get-Date
    $outputText = "The data disk $sqlLogDiskName has been successfully initialised on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to initialise the data disk $sqlLogDiskName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Initialize-Disk -Number 6 -PartitionStyle $diskPartitionStyle -PassThru | `
    New-Volume -FileSystem $diskFormat -DriveLetter J -FriendlyName $sqlBackupDiskName
    $currentTimestamp = Get-Date
    $outputText = "The data disk $sqlBackupDiskName has been successfully initialised on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to initialise the data disk $sqlBackupDiskName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Initialize-Disk -Number 7 -PartitionStyle $diskPartitionStyle -PassThru | `
    New-Volume -FileSystem $diskFormat -DriveLetter K -FriendlyName $sqlTempDBDiskName
    $currentTimestamp = Get-Date
    $outputText = "The data disk $sqlTempDBDiskName has been successfully initialised on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to initialise the data disk $sqlTempDBDiskName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

$currentTimestamp = Get-Date
$outputText = "initialiseDisk.ps1 has completed execution on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer