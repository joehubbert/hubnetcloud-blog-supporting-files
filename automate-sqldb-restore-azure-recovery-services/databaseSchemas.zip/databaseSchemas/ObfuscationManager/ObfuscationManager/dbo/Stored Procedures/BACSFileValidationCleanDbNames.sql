﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure BACSFileValidationCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	UPDATE [BACSFileValidation].[dbo].[Archive_DDCollectionDetail] SET [AccountName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]);
	UPDATE [BACSFileValidation].[dbo].[DDCollectionDetail] SET [AccountName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]);
	UPDATE [BACSFileValidation].[dbo].[DDCollectionDetailAudit] SET [AccountName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]);
return 0