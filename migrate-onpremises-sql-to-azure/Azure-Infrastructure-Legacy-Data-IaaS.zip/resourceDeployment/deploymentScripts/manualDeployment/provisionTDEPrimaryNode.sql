--PLEASE ENSURE THAT ALL REQUIRED VALUES HAVE BEEN POPULATED BEFORE RUNNING!!

-- Use <subscriptioncode>-<environmentcode>-sql-<aoag/rs>-master-key-password from relevant key vault for the password
CREATE MASTER KEY ENCRYPTION BY PASSWORD = ''

-- Always use the same prefix C:\ComputerConfiguration\EncryptionKeys\SQLTDE
-- Backup file should follow the format of <ComputerConfigurationDirectory>\<EncryptionKeysDirectory>\<ComputerName>-server-master-key.bak e.g. C:\ComputerConfiguration\EncryptionKeys\SQLTDE\NPVMIDEVSQLDB01-server-master-key.bak
-- Use <subscriptioncode>-<environmentcode>-sql-<aoag/rs>-master-key-backup-password from relevant key vault for the password
BACKUP MASTER KEY TO FILE = '.bak'
ENCRYPTION BY PASSWORD = ''

-- Certificate name should be the name of the cluster e.g. NPDEVSQLCLUSTER
-- The subject must include the active directory FQDN e.g. NPDEVSQLCLUSTER.corp.allpoc.dc
-- The expiry date must follow this format '20200101'
CREATE CERTIFICATE EXAMPLE
WITH SUBJECT = '',
EXPIRY_DATE = ''

-- Certificate name should be the same as what is defined above
-- Certificate file should follow the format of <ComputerConfigurationDirectory>\<CertificatesDirectory>\<ComputerName>-server-certificate.cer e.g. C:\ComputerConfiguration\Certificates\SQLTDE\NPVMIDEVSQLDB01-server-certificate.cer
-- Private Key should follow the format of <ComputerConfigurationDirectory>\<EncryptionKeysDirectory>\<ComputerName>-server-certificate-private-key.pvk e.g. C:\ComputerConfiguration\EncryptionKeys\SQLTDE\NPVMIDEVSQLDB01-server-certificate-private-key.pvk
-- Use <subscriptioncode>-<environmentcode>-sql-<aoag/rs>-server-certificate-backup-password from relevant key vault for the password
BACKUP CERTIFICATE EXAMPLE
TO FILE = '.cer'
WITH PRIVATE KEY ( FILE = '.pvk',
ENCRYPTION BY PASSWORD = '')