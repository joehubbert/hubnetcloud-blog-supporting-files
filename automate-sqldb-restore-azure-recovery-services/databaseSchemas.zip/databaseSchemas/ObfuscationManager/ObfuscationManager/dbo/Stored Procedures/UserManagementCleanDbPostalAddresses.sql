﻿/*
Clean the postal addresses by replacing originals with fictional postal address
*/
create procedure UserManagementCleanDbPostalAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [UserManagement].[dbo].[Customer_PhoneNumber] SET [Number] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Number]);
	UPDATE [UserManagement].[dbo].[TextPay_User] SET [MobileNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MobileNumber]);
	UPDATE [UserManagement].[dbo].[User] SET [MobileAlias] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MobileAlias]);
	UPDATE [UserManagement].[dbo].[User] SET [PasswordQuestion] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PasswordQuestion]);
return 0