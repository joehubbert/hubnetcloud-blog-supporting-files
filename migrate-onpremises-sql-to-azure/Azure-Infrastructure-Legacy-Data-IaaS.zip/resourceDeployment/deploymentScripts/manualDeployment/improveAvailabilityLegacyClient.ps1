param
(
    [Parameter(Mandatory)][string]$availabilityGroupName,
    [Parameter(Mandatory)][string]$availabilityGroupListenerName    
)

#Set Common Variables
$clusterResourceName = ($availabilityGroupName + "_" + $availabilityGroupListenerName)
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$scriptLogFileName = 'improveAvailabilityLegacyClient-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Update HostRecordTTL
try
{
    Get-ClusterResource $clusterResourceName | Set-ClusterParameter HostRecordTTL 300
    Stop-ClusterResource -Name $clusterResourceName
    Start-ClusterResource -Name $clusterResourceName
    $currentTimestamp = Get-Date
    $outputText = "The Availability Group Listener $availabilityGroupListenerName has been altered to a shorter HostRecordTTL time of 300 seconds instead of the default 1200 seconds at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to set the HostRecordTTL to 300 seconds at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Update RegisterAllProvidersIP
try
{
    Get-ClusterResource $clusterResourceName | Set-ClusterParameter RegisterAllProvidersIP 0
    Stop-ClusterResource -Name $clusterResourceName
    Start-ClusterResource -Name $clusterResourceName
    $currentTimestamp = Get-Date
    $outputText = "The Availability Group Listener $availabilityGroupListenerName has been altered to disable RegisterAllProvidersIP at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to set the RegisterAllProvidersIP to 0 at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

$currentTimestamp = Get-Date
$outputText = "Execution of improveAvailabilityLegacyClient.ps1 successfully completed on $env:computername at $currentTimestamp. A server reboot will be triggered immediately."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"