﻿CREATE PROCEDURE [dbo].[RemoveStaleObfuscationLogRecords]
AS

DELETE FROM [dbo].[ObfuscationLog]
WHERE [Operation_Timestamp_UTC] <= DATEADD(DD,-45,GETUTCDATE())