﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure P42CleanAccAddr @seedA int, @seedB int
as
	set nocount on;
	--[AP_ACCADDR];
	-- the work table
	select 
	 [AP_RECNO]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_OTHERADD1]) [AP_OTHERADD1] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_OTHERADD2]) [AP_OTHERADD2] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_OTHERADD3]) [AP_OTHERADD3] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_OTHERADD4]) [AP_OTHERADD4] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_OTHERPCODE]) [AP_OTHERPCODE]
	into [P42].[dbo].[AP_ACCADDR_WORK] 
	from [P42].[dbo].[AP_ACCADDR];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [P42]; create clustered index [CIX_AP_ACCADDR_WORK(AP_RECNO)] on AP_ACCADDR_WORK(AP_RECNO);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @AP_ACCADDR table(AP_RECNO int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [P42].[dbo].[AP_ACCADDR] 
		SET 
		 [AP_OTHERADD1] = [P42].[dbo].[AP_ACCADDR_WORK].[AP_OTHERADD1] 
		,[AP_OTHERADD2] = [P42].[dbo].[AP_ACCADDR_WORK].[AP_OTHERADD2] 
		,[AP_OTHERADD3] = [P42].[dbo].[AP_ACCADDR_WORK].[AP_OTHERADD3] 
		,[AP_OTHERADD4] = [P42].[dbo].[AP_ACCADDR_WORK].[AP_OTHERADD4] 
		,[AP_OTHERPCODE] = [P42].[dbo].[AP_ACCADDR_WORK].[AP_OTHERPCODE]
		output INSERTED.AP_RECNO into @AP_ACCADDR
		from [P42].[dbo].[AP_ACCADDR_WORK]
		where [P42].[dbo].[AP_ACCADDR_WORK].[AP_RECNO] = [P42].[dbo].[AP_ACCADDR].[AP_RECNO];
		--remove the records already updated
		delete from [P42].[dbo].[AP_ACCADDR_WORK] where AP_RECNO in (select AP_RECNO from @AP_ACCADDR);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @AP_ACCADDR;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [P42].[dbo].[AP_ACCADDR_WORK];
return 0