# Introduction 
This repository stores the templates and configuration scripts for deploying a SQL Server AlwaysOn Availability Group (AOAG) to Windows Server and deploying SQL Server Reporting Services (SSRS) to Windows Server.
- The current configuration:
   - Windows Server 2022
   - SQL Server 2019

# Getting Started
- You will need to clone this repository to your local machine.

**Tools**:
- Visual Studio Code
- PowerShell 7+
- Bicep extension for Visual Studio Code
- ARM Template extension for Visual Studio Code

**Active Directory Provisions**
- Service Accounts deployed as per .\resourceDeployment\deploymentScripts\manualDeployment\provisionADGMSA.ps1, ran on the domain controllers directly

- Domain account with permissions to join machines to domain (ideally OU delegation) and be a member of DNS Admins, NOT DOMAIN ADMIN
  - Local administrator permissions to be set through group policy where appropriate
- Domain account with no domain-level permissions to be used as Active Directory breakglass account e.g. 'CONTOSO\sqlbreakglass'
- Security group that has all domain users that need sysadmin access to the database engine, these should be local domain users and not federated

**SSRS**
-Export the encryption keys from the existing instance of SSRS

# Deployment
## YAML Release Pipeline - Automated Deployment
1. Infrastructure is deployed using YAML release pipeline with two possible flows for each release stage (DEV, QUA and PRD).
   - New Deployment
      - Copy Deployment Scripts to Storage Account (There is a container specific to each release stage)
      - Generate VM local admin username
      - Store VM local admin username in centralised KeyVault
      - Generate VM local admin password
      - Store VM local admin password in centralised KeyVault
      - Get required Key Vault secrets not specific to flow
      - Get required Key Vault secrets specifc to flow (New Deployment)
      - Deploy Resource Groups Bicep Template, these are specifc for each release stage
        - KeyVault 
        - Management
        - Networking
        - Storage
        - Virtual Machine
      - Deploy Resources Bicep Template, these are specifc for each release stage
        - SQL AOAG Subnet Network Security Group
        - SQL AOAG Subnet Network Security Group Rules
        - SQL SSRS Subnet Network Security Group
        - SQL SSRS Subnet Network Security Group Rules
        - Route Table
        - Virtual Network
        - Bi-Directional Virtual Network Peering to Virtual Network where Windows Active Directory Domain Services Servers/DNS Servers are located
        - Bi-Directional Virtual Network Peering to Hub Virtual Network which is attached to Azure Firewall
        - Route Table Route
        - Internal Load Balancer for SQL AOAG
        - Storage Account
        - Storage Account Containers (Cloud Witness for Windows Server Failover Cluster and Database Static Backups)
        - Key Vault
        - Maintenance Configurations for each Virtual Machine to be deployed (Different times specified in schedule to ensure high-availability)
        - Recovery Services Vault (Bicep template currently not working for this and should be deployed manually)
        - SQL AOAG Virtual Machine Nodes (A,B,C)
        - SQL SSRS Virtual Machine
      - Run preparation scripts on each virtual machine (Creates required directories and downloads common scripts)
      - Copy AOAG setup scripts to each SQL AOAG virtual machine
      - Copy SSRS setup scripts to each SQL SSRS virtual machine
      - Join each virtual machine to Windows Active Directory
      - Execute common virtual machine setup script on each virtual machine
      - Execute AOAG setup scripts on each SQL AOAG virtual machine
      - Execute SSRS setup scripts on each SQL SSRS virtual machine
      - Enrol each virtual machine into SQL IaaS extension for Azure
   - Existing Deployment
      - Copy Deployment Scripts to Storage Account (There is a container specific to each release stage)
      - Get required Key Vault secrets not specific to flow
      - Remove existing bi-directional Virtual Network Peering to Virtual Network where Windows Active Directory Domain Services Servers/DNS Servers are located
      - Remove existing bi-directional Virtual Network Peering to Hub Virtual Network which is attached to Azure Firewall
      - Deploy Resource Groups Bicep Template, these are specifc for each release stage
        - KeyVault 
        - Management
        - Networking
        - Storage
        - Virtual Machine
      - Deploy Resources Bicep Template, these are specifc for each release stage
        - SQL AOAG Subnet Network Security Group
        - SQL AOAG Subnet Network Security Group Rules
        - SQL SSRS Subnet Network Security Group
        - SQL SSRS Subnet Network Security Group Rules
        - Route Table
        - Virtual Network
        - Bi-Directional Virtual Network Peering to Virtual Network where Windows Active Directory Domain Services Servers/DNS Servers are located
        - Bi-Directional Virtual Network Peering to Hub Virtual Network which is attached to Azure Firewall
        - Route Table Route
        - Internal Load Balancer for SQL AOAG
        - Storage Account
        - Storage Account Containers (Cloud Witness for Windows Server Failover Cluster and Database Static Backups)
        - Key Vault
        - Maintenance Configurations for each Virtual Machine to be deployed (Different times specified in schedule to ensure high-availability)
        - Recovery Services Vault (Bicep template currently not working for this and should be deployed manually)
        - SQL AOAG Virtual Machine Nodes (A,B,C)
        - SQL SSRS Virtual Machine
2. Manual intervention required beyond this point
3. Create a recovery services vault using PowerShell similar to the below
    ```
    New-AzRecoveryServicesVault -Name 'allpay-nds01-dev-uks-recovery-services-vault' -ResourceGroupName 'allpay-dev-infrastructure-rg-management' -Location 'uksouth'
    ```
4. Create recovery services vault policies using PowerShell similar to the below
   ```

   ```
  
3. Follow further steps specific to each resource type below

## SQL AOAG Specifc 
1. Login to the machine as the Windows Admin domain user used previously to join the machine to the domain
2. Open SQL Server Management Studio (SSMS) and connect to the database engine on this node only using the break glass credentials, either Windows/SQL Auth, it doesn't matter
3. Enable line numbers as per https://www.mssqltips.com/sqlservertip/2542/display-line-numbers-in-a-sql-server-management-studio-query-window/
4. Open the following script file C:\ComputerConfiguration\Scripts\sqlIntegrationServicesCatalog.sql
5. Open the centralised key vault locally and find the secret named in the format similar to this example for the release stage (nds-dev01-sql-ssiscatalog-master-key) and copy to clipboard
4. Set the catalog master key value on line 197 of the script using the key vault secret and execute the script
   - There may need to be some manual intervention required i.e. re-run certain code blocks
5. Open the Azure portal and navigate to the storage account created by the bicep deployment, get the primary storage key and copy to your clipboard
5. On your local machine, open https://learn.microsoft.com/en-us/windows-server/failover-clustering/prestage-cluster-adds#grant-the-cno-permissions-to-the-ou, this will be needed for the next step.
   - You will be prompted by the following PowerShell script when to take action.
6. Run **Windows PowerShell** as administrator with code similar to the below
    - You can get the following values from the variable group for the release stage
        - windowsServerFailoverClusterLoadBalancerIPAddressSQL = loadBalancerFrontendIPAddressSQL
        - windowsServerFailoverClusterLoadBalancerIPAddressWSFC = loadBalancerFrontendIPAddressWSFC
        - windowsServerFailoverClusterLoadBalancerSubnetMask = virtualNetworkSQLAOAGSubnetMask
        - windowsServerFailoverClusterLoadBalancerTripleOctet = virtualNetworkSQLAOAGSubnetTripleOctet

    ```
    Set-Location C:\ComputerConfiguration\Scripts
    .\sqlAOAGWSFCSetup.ps1 `
    -windowsServerFailoverClusterCloudWitnessAccount 'allpayuksnpdevdba' `
    -windowsServerFailoverClusterCloudWitnessKey '<Storage account key copied to clipboard>' `
    -windowsServerFailoverClusterSQLListenerName 'NONPRODDEVSQLCLUSTER `
    -windowsServerFailoverClusterWSFCListenerName 'NONPRODDEVSQLAOAGWSFC `
    -windowsServerFailoverClusterLoadBalancerIPAddressSQL '10.177.176.5'  `
    -windowsServerFailoverClusterLoadBalancerIPAddressWSFC '10.177.176.4' `
    -windowsServerFailoverClusterLoadBalancerSubnetMask '10.177.176.0/28'  `
    -windowsServerFailoverClusterLoadBalancerTripleOctet '10.177.176' `
    -windowsServerFailoverClusterNodeA 'NPVMIDEVSQLDB01' `
    -windowsServerFailoverClusterNodeB 'NPVMIDEVSQLDB02' `
    -windowsServerFailoverClusterNodeC 'NPVMIDEVSQLDB03'
    ```
9. After reboot, login to **each AOAG node** as the same domain user used previously
10. Open SQL Server Configuration Manager
11. Go to SQL Server Services
12. Right-Click on 'SQL Server (MSSQLSERVER)' and select Properties
13. Go to the Always On Availability Groups tab
14. Enable Always On Availability Groups
15. Restart the server

## SSRS Specific Notes
1. Login to the machine as the Windows Admin domain user used previously to join the machine to the domain
2. Connect to the database engine as one of the sql breakglass logins, can be Windows/SQL Auth, it doesn't matter
5. Restore the ReportServer and ReportServerTempDB databases to the server
6. Upgrade the compatibility level to be the same as the instance e.g. SQL Server 2014 > SQL Server 2019
7. Add the DOMAIN\svcMSSQLRS$ as a user to **both** databases, ensure that the default schema is dbo and the database roles have been set
   - db_owner
   - RS_Exec
8. Copy the backed up SSRS encryption key to the new host
9. Open the SSRS Configuration Manager
10. Configure the Service account to be DOMAIN\svcMSSQLRS$
11. Set the databases to be the one you just restored and use DOMAIN\svcMSSQLRS$ as the credential in service account mode
12. Restore the encryption key that you copied over from the previous host
13. Generate a new encryption key and ensure that it is backed up securely to a location such as key vault
12. Configure the Web Service URL, you may need to install TLS certificates if HTTPS will be used
13. Configure the Report Manager URL
14. Configure E-mail settings, sender address should be the same as what is deployed as clients will likely have that e-mail address whitelisted


# Adding Databases Into Availability Group
- Install all databases on primary node
- A full local backup must be taken of each database before it can be added into the availability group as a prerequisite
  - As there is limited disk space on the local backup drive on the server databases should be batched when being added to the availability group
- SSISDB can and should be added into the availability group
  - Once added, Always-On support should be enabled as per https://learn.microsoft.com/en-us/sql/integration-services/catalog/ssis-catalog?view=sql-server-ver15#Firsttime