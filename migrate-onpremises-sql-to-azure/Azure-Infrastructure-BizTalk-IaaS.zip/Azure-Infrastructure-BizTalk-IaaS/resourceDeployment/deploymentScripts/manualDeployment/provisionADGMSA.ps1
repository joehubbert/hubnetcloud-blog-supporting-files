Import-Module ActiveDirectory
Add-KdsRootKey -EffectiveTime ((Get-Date).Addhours(-10)) 
$activeDirectoryDomainFQDN = '<DomainFQDN>'
$fciServerList = @('<primaryNodeName>','<secondaryNodeName>')

$fciServerList = $fciServerList.ForEach{ return (Get-ADComputer $_)  }
Write-Output $fciServerList

New-ADServiceAccount `
-Name svcMSSQLBZDB `
-Description 'Service Account for MSSQL Database Engine in BizTalk Failover Cluster' `
-DNSHostName "svcmssqlbzdb.$activeDirectoryDomainFQDN" `
-ManagedPasswordIntervalInDays 7 `
-PrincipalsAllowedToRetrieveManagedPassword $fciServerList `
-TrustedForDelegation $true `
-Enabled $true `
-PassThru

New-ADServiceAccount `
-Name svcMSSQLBZIS `
-Description 'Service Account for MSSQL Integration Services in BizTalk Failover Cluster' `
-DNSHostName "svcmssqlbzis.$activeDirectoryDomainFQDN" `
-ManagedPasswordIntervalInDays 7 `
-PrincipalsAllowedToRetrieveManagedPassword $fciServerList `
-TrustedForDelegation $true `
-Enabled $true `
-PassThru

New-ADServiceAccount `
-Name svcMSSQLBZA `
-Description 'Service Account for MSSQL Agent in BizTalk Failover Cluster' `
-DNSHostName "svcmssqlbza.$activeDirectoryDomainFQDN" `
-ManagedPasswordIntervalInDays 7 `
-PrincipalsAllowedToRetrieveManagedPassword $fciServerList `
-TrustedForDelegation $true `
-Enabled $true `
-PassThru