﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure P42CleanOthers @seedA int, @seedB int
as
	set nocount on;

	UPDATE [P42].[dbo].[AP_ACCAUD] 
	SET 
	 [AP_ADD1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD1])
	,[AP_ADD2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD2])
	,[AP_ADD3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD3])
	,[AP_ADD4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD4])
	,[AP_POSTCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_POSTCODE])
	,[AP_TITLEINITS] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_TITLEINITS])
	,[AP_NAMEONCARD] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_NAMEONCARD])
	,[AP_SURNAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SURNAME]);

	UPDATE [P42].[dbo].[AP_BANKARCH] 
	SET 
	 [AP_ACCOUNTNO] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACCOUNTNO])
	,[AP_BILLADD1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD1])
	,[AP_BILLADD2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD2])
	,[AP_BILLADD3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD3])
	,[AP_BILLADD4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD4])
	,[AP_BILLPCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLPCODE])
	,[AP_SORTCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SORTCODE])
	,[AP_ACC_NAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACC_NAME])
	,[AP_BILLNAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLNAME]);

	UPDATE [P42].[dbo].[AP_BANKARCH_ARCH] 
	SET 
	 [AP_ACCOUNTNO] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACCOUNTNO])
	,[AP_BILLADD1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD1])
	,[AP_BILLADD2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD2])
	,[AP_BILLADD3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD3])
	,[AP_BILLADD4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD4])
	,[AP_BILLPCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLPCODE])
	,[AP_SORTCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SORTCODE])
	,[AP_ACC_NAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACC_NAME])
	,[AP_BILLNAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLNAME]);

	UPDATE [P42].[dbo].[AP_BANKDETS] 
	SET 
	 [AP_ACCOUNTNO] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACCOUNTNO])
	,[AP_BILLADD1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD1])
	,[AP_BILLADD2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD2])
	,[AP_BILLADD3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD3])
	,[AP_BILLADD4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD4])
	,[AP_BILLPCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLPCODE])
	,[AP_SORTCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SORTCODE])
	,[AP_ACC_NAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACC_NAME])
	,[AP_BILLNAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLNAME]);

	UPDATE [P42].[dbo].[AP_DDLETTER_ARCH] 
	 SET [AP_ACCOUNTNO] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACCOUNTNO])
	,[AP_BILLADD1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD1])
	,[AP_BILLADD2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD2])
	,[AP_BILLADD3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD3])
	,[AP_BILLADD4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD4])
	,[AP_BILLPCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLPCODE])
	,[AP_SORTCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SORTCODE])
	,[AP_ACC_NAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACC_NAME])
	,[AP_BILLNAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLNAME]);

	UPDATE [P42].[dbo].[AP_DDQUEUE] 
	SET 
	 [AP_ACCOUNTNO] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACCOUNTNO])
	,[AP_BILLADD1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD1])
	,[AP_BILLADD2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD2])
	,[AP_BILLADD3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD3])
	,[AP_BILLADD4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD4])
	,[AP_BILLPCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLPCODE])
	,[AP_SORTCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SORTCODE])
	,[AP_ACC_NAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACC_NAME])
	,[AP_BILLNAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLNAME]);

	UPDATE [P42].[dbo].[AP_DDTRAN] 
	SET 
	 [AP_ACCOUNTNO] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACCOUNTNO])
	,[AP_ADD1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD1])
	,[AP_ADD2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD2])
	,[AP_ADD3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD3])
	,[AP_ADD4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ADD4])
	,[AP_BILLADD1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD1])
	,[AP_BILLADD2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD2])
	,[AP_BILLADD3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD3])
	,[AP_BILLADD4] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLADD4])
	,[AP_BILLPCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLPCODE])
	,[AP_POSTCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_POSTCODE])
	,[AP_SORTCODE] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SORTCODE])
	,[AP_TITLEINITS] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_TITLEINITS])
	,[AP_ACC_NAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACC_NAME])
	,[AP_BILLNAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_BILLNAME])
	,[AP_SURNAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SURNAME]);

	UPDATE [P42].[dbo].[AP_EXTRADATA] SET [AP_EXTRADATA] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_EXTRADATA]);

	UPDATE [P42].[dbo].[Auddis] 
	SET 
	 [AccountNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber])
	,[SortCode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SortCode])
	,[AccountName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]);

	UPDATE [P42].[dbo].[AP_REPDATA] SET [AP_REPNAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_REPNAME]);

	UPDATE [P42].[dbo].[AP_USERS] SET [AP_FULLNAME] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_FULLNAME]);
	
return 0