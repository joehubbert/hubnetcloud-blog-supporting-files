﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure DirectDebitsCleanCreateDdiActionCommonProperties @seedA int, @seedB int
as
	set nocount on;
	--[CreateDdiActionCommonProperties];
	-- the work table
	select 
	 [CreateDdiActionCommonPropertiesId]
	,[ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [EmailAddress]) [EmailAddress]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MobileNumber]) [MobileNumber]
	into [DirectDebits].[dbo].[CreateDdiActionCommonProperties_WORK] 
	from [DirectDebits].[dbo].[CreateDdiActionCommonProperties];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [DirectDebits]; create clustered index [CIX_CreateDdiActionCommonProperties_WORK(CreateDdiActionCommonPropertiesId)] on CreateDdiActionCommonProperties_WORK(CreateDdiActionCommonPropertiesId);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @CreateDdiActionCommonProperties table(CreateDdiActionCommonPropertiesId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [DirectDebits].[dbo].[CreateDdiActionCommonProperties] 
		SET 
		 [EmailAddress] = [DirectDebits].[dbo].[CreateDdiActionCommonProperties_WORK].[EmailAddress]
		,[MobileNumber] = [DirectDebits].[dbo].[CreateDdiActionCommonProperties_WORK].[MobileNumber]
		output INSERTED.CreateDdiActionCommonPropertiesId into @CreateDdiActionCommonProperties
		from [DirectDebits].[dbo].[CreateDdiActionCommonProperties_WORK]
		where [DirectDebits].[dbo].[CreateDdiActionCommonProperties_WORK].[CreateDdiActionCommonPropertiesId] = [DirectDebits].[dbo].[CreateDdiActionCommonProperties].[CreateDdiActionCommonPropertiesId];
		--remove the records already updated
		delete from [DirectDebits].[dbo].[CreateDdiActionCommonProperties_WORK] where CreateDdiActionCommonPropertiesId in (select CreateDdiActionCommonPropertiesId from @CreateDdiActionCommonProperties);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @CreateDdiActionCommonProperties;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [DirectDebits].[dbo].[CreateDdiActionCommonProperties_WORK];
return 0