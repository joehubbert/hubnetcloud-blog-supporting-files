﻿/*
Clean the email addresses by replacing originals with fictional email address
*/
create procedure PrepaidCleanDbEmailAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Prepaid].[dbo].[CardHolders] SET [Email] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [Email]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [EmailAddress] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [EmailAddress]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [Email] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [Email]);
	UPDATE [Prepaid].[dbo].[UpdateCardHolderDetailsRequests] SET [Email] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [Email]);
return 0