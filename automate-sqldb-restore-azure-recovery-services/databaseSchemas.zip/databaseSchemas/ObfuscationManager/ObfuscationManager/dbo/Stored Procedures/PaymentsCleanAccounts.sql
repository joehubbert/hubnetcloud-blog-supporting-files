﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure PaymentsCleanAccounts @seedA int, @seedB int
as
	set nocount on;
	--[Accounts];
	-- the work table
	select 
	 [AccountId]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Surname]) [Surname] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [TitleAndInitials]) [TitleAndInitials] 
	into [Payments].[dbo].[Accounts_WORK] 
	from [Payments].[dbo].[Accounts];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [Payments]; create clustered index [CIX_Accounts_WORK(AccountId)] on Accounts_WORK(AccountId);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @Accounts table(AccountId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [Payments].[dbo].[Accounts] 
		SET 
		 [Surname] = [Payments].[dbo].[Accounts_WORK].[Surname] 
		,[TitleAndInitials] = [Payments].[dbo].[Accounts_WORK].[TitleAndInitials] 
		output INSERTED.AccountId into @Accounts
		from [Payments].[dbo].[Accounts_WORK]
		where [Payments].[dbo].[Accounts_WORK].[AccountId] = [Payments].[dbo].[Accounts].[AccountId];
		--remove the records already updated
		delete from [Payments].[dbo].[Accounts_WORK] where AccountId in (select AccountId from @Accounts);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @Accounts;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [Payments].[dbo].[Accounts_WORK];
return 0