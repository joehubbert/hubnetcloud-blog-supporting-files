﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure PrepaidCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Prepaid].[dbo].[CardHolders] SET [FirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FirstName]);
	UPDATE [Prepaid].[dbo].[CardHolders] SET [LastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LastName]);
	UPDATE [Prepaid].[dbo].[CardHolders] SET [MiddleName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MiddleName]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [DispatchFirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchFirstName]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [DispatchLastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchLastName]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [FirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FirstName]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [LastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LastName]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [MiddleName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MiddleName]);
	UPDATE [Prepaid].[dbo].[ImportedRecords] SET [NameOnCard] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [NameOnCard]);
	UPDATE [Prepaid].[dbo].[IssueAdditionalCardRequests] SET [DispatchFirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchFirstName]);
	UPDATE [Prepaid].[dbo].[IssueAdditionalCardRequests] SET [DispatchLastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchLastName]);
	UPDATE [Prepaid].[dbo].[IssueAdditionalCardRequests] SET [CardHolderName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [CardHolderName]);
	UPDATE [Prepaid].[dbo].[IssueCardRequests] SET [CardHolderName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [CardHolderName]);
	UPDATE [Prepaid].[dbo].[IssueCardRequests] SET [DispatchFirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchFirstName]);
	UPDATE [Prepaid].[dbo].[IssueCardRequests] SET [DispatchLastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DispatchLastName]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [FirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FirstName]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [LastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LastName]);
	UPDATE [Prepaid].[dbo].[NewCardHolderRequests] SET [MiddleName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [MiddleName]);
	UPDATE [Prepaid].[dbo].[ReissueCardRequests] SET [CardHolderName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [CardHolderName]);
return 0