param
(
    [Parameter(Mandatory)][string]$sqlServerAdministratorGroupName,
    [Parameter(Mandatory)][string]$sqlServerDatabaseEngineServiceAccount
)

$backupDriveLetter = Read-Host "Please enter drive letter of backup drive"
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$progressPreference = 'SilentlyContinue'
$scriptLogFileName = 'configureSQLBackupRestoreSMB-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"
$sqlServerBackupDirectory = "${backupDriveLetter}:\MSSQL12.MSSQLSERVER\MSSQL\Backup"
$sqlServerBackupRestoreDirectory = "${backupDriveLetter}:\MSSQL12.MSSQLSERVER\MSSQL\Restore"
$sqlServerLocalIdentity = 'NT SERVICE\MSSQLSERVER'

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Create Directory for SQL Server Database Restores
try
{
    New-Item -Path $sqlServerBackupRestoreDirectory -ItemType Directory
    $acl = Get-Acl $sqlServerBackupRestoreDirectory
    $permissionsToAdd = New-Object System.Security.AccessControl.FileSystemAccessRule($sqlServerLocalIdentity, "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
    $acl.SetAccessRule($permissionsToAdd)
    Set-Acl $sqlServerBackupRestoreDirectory $acl
    $currentTimestamp = Get-Date
    $outputText = "The database restore directory $sqlServerBackupRestoreDirectory has been successfully created and permissions have been granted to $sqlServerLocalIdentity on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the directory $sqlServerBackupRestoreDirectory on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure Windows SMB Fileshare for SQL Backups
try
{
    New-SmbShare `
    -Description 'SMB Share for hosting SQL Backups.' `
    -FolderEnumerationMode 'Unrestricted' `
    -FullAccess ($sqlServerAdministratorGroupName, $sqlServerDatabaseEngineServiceAccount) `
    -Name 'SQLBackups' `
    -Path $sqlServerBackupDirectory
    $currentTimestamp = Get-Date
    $outputText = "The Windows SMB Share called 'SQLBackups' has been successfully created on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the SMB Share 'SQLBackups' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure Windows SMB Fileshare for SQL Restores
try
{
    New-SmbShare `
    -Description 'SMB Share for hosting SQL Restores.' `
    -FolderEnumerationMode 'Unrestricted' `
    -FullAccess ($sqlServerAdministratorGroupName, $sqlServerDatabaseEngineServiceAccount) `
    -Name 'SQLRestore' `
    -Path $sqlServerBackupRestoreDirectory
    $currentTimestamp = Get-Date
    $outputText = "The Windows SMB Share called 'SQLRestore' has been successfully created on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the SMB Share 'SQLRestore' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

$currentTimestamp = Get-Date
$outputText = "Execution of configureSQLBackupRestoreSMB.ps1 successfully completed on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"