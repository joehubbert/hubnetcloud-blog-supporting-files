﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure LettersCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Letters].[dbo].[Letters_ClientAccountInformationLetter] SET [AccountName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]);
	UPDATE [Letters].[dbo].[Letters_ClientPaymentLetter] SET [AccountName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]);
	UPDATE [Letters].[dbo].[Letters_CustomerDDLetter] SET [BankAccountName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [BankAccountName]);
	UPDATE [Letters].[dbo].[Letters_CustomerDDLetter] SET [CustomerName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [CustomerName]);
	UPDATE [Letters].[dbo].[Letters_DDLetter] SET [AccountName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]);
	UPDATE [Letters].[dbo].[Letters_DDLetter] SET [CustomerName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [CustomerName]);
return 0