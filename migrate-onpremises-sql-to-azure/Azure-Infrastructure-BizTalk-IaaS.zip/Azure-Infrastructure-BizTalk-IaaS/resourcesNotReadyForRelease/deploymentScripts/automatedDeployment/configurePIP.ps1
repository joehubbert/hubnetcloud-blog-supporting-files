param 
(
    [Parameter(Mandatory)][string]$pipIPAddress
)

$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$scriptLogFileName = 'configurePIP-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Create PIP IIS Site
try
{
    $site = 'PIP'
    $siteFolder = "C:\inetpub\wwwroot\$site"
    New-Item -Path $siteFolder -ItemType Directory

    New-Website -Name $site -PhysicalPath $siteFolder -Force
    New-WebBinding -Name $site -Port 443 -Protocol https -IPAddress $pipIPAddress
    Remove-WebBinding -Name $site -Port 80 -Protocol http -IPAddress *
    Start-Website -Name $site

    $currentTimestamp = Get-Date
    $outputText = "The IIS site $site has been installed and is listening $pipIPAddress on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"    
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "There was an error installing the IIS site $site on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"    
}

$currentTimestamp = Get-Date
$outputText = "configurePIP.ps1 has completed execution on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer