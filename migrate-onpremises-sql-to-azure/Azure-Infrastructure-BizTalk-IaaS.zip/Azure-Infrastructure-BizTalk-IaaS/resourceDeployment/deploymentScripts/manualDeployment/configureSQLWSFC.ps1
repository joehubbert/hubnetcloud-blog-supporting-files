param 
(
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterNodeA,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterNodeB,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterPrivateIPAddressWSFC,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterSubnetPrefix,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterWSFCListenerName
)

#Set Common Variables
$clusterNetworkName = 'BizTalk SQL FCI Cluster Network'
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$progressPreference = 'SilentlyContinue'
$scriptLogFileName = 'configureSQLWSFC-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"
$windowsServerFailoverClusterSubnetPrefixAddress = ($windowsServerFailoverClusterSubnetPrefix.split('/')[0])

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Create and Configure Windows Server Failover Cluster
try
{
    Import-Module FailoverClusters
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to import the PowerShell module 'FailoverClusters' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create Windows Server Failover Cluster & Add Secondary Node
try
{
    New-Cluster -Name $windowsServerFailoverClusterWSFCListenerName -ManagementPointNetworkType Singleton -Node $windowsServerFailoverClusterNodeA, $windowsServerFailoverClusterNodeB -NoStorage -StaticAddress $windowsServerFailoverClusterPrivateIPAddressWSFC
    $currentTimestamp = Get-Date
    $outputText = "The Windows Server Failover Cluster $windowsServerFailoverClusterWSFCListenerName has been created on $windowsServerFailoverClusterNodeA, $windowsServerFailoverClusterNodeB, in Singleton mode at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the Windows Server Failover Cluster $windowsServerFailoverClusterWSFCListenerName on $windowsServerFailoverClusterNodeA, $windowsServerFailoverClusterNodeB, in Singleton mode at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Rename Cluster Network
try
{
    $oldClusterNetworkName = Get-ClusterNetwork | Where-Object{$_.Address -eq $windowsServerFailoverClusterSubnetPrefixAddress }| Select-Object Name | ForEach-Object {$_.Name}
    (Get-ClusterNetwork -Name $oldClusterNetworkName).Name = $clusterNetworkName
    $currentTimestamp = Get-Date
    $outputText = "$windowsServerFailoverClusterWSFCListenerName has renamed the cluster network from $oldClusterNetworkName to $clusterNetworkName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when renaming the cluster networks on $windowsServerFailoverClusterNodeA on the Windows Server Failover Cluster $windowsServerFailoverClusterWSFCListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Set IP Address Probe Port properties for Cluster Network Name
try
{
    Get-ClusterResource -Name 'Cluster IP Address' | Set-ClusterParameter -Name ProbePort -Value 57777
    $currentTimestamp = Get-Date
    $outputText = "The IP Address probe port has been set to 57777 on $windowsServerFailoverClusterWSFCListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the probe port to 57777 on $windowsServerFailoverClusterWSFCListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Set SameSubnetDelay
try
{
    (Get-Cluster).SameSubnetDelay = 1000
    $currentTimestamp = Get-Date
    $outputText = "The SameSubnetDelay on $windowsServerFailoverClusterWSFCListenerName has been set to 1 second at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"   
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the SameSubnetDelay on the Windows Server Failover Cluster $windowsServerFailoverClusterWSFCListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Set SameSubnetThreshold
try
{
    (Get-Cluster).SameSubnetThreshold = 40
    $currentTimestamp = Get-Date
    $outputText = "The SameSubnetThreshold on $windowsServerFailoverClusterWSFCListenerName has been set to 40 heartbeats at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"   
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the SameSubnetThreshold on the Windows Server Failover Cluster $windowsServerFailoverClusterWSFCListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Set CrossSubnetDelay
try
{
    (Get-Cluster).CrossSubnetDelay = 1000
    $currentTimestamp = Get-Date
    $outputText = "The CrossSubnetDelay on $windowsServerFailoverClusterWSFCListenerName has been set to 1 second at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"   
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the CrossSubnetDelay on the Windows Server Failover Cluster $windowsServerFailoverClusterWSFCListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Set CrossSubnetThreshold
try
{
    (Get-Cluster).CrossSubnetThreshold = 40
    $currentTimestamp = Get-Date
    $outputText = "The CrossSubnetThreshold on $windowsServerFailoverClusterWSFCListenerName has been set to 40 heartbeats at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"   
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the CrossSubnetThreshold on the Windows Server Failover Cluster $windowsServerFailoverClusterWSFCListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Run Cluster Validation Tests
try
{
    $testStartTime = Get-Date
    Test-Cluster
    $currentTimestamp = Get-Date
    $outputText = "The cluster $windowsServerFailoverClusterWSFCListenerName has been tested between $testStartTime and $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"   
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when testing the Windows Server Failover Cluster $windowsServerFailoverClusterWSFCListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

$currentTimestamp = Get-Date
$outputText = "The Windows Server Failover Cluster has been has been successfully installed on $windowsServerFailoverClusterNodeA, $windowsServerFailoverClusterNodeB at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

$currentTimestamp = Get-Date
$outputText = "Execution of configureSQLWSFC.ps1 successfully completed on $env:computername at $currentTimestamp. A server reboot will be triggered immediately."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer -ComputerName $windowsServerFailoverClusterNodeB, $windowsServerFailoverClusterNodeA