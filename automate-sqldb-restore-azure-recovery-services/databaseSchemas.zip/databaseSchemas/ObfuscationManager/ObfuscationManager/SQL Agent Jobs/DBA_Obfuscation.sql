﻿USE [msdb]
GO

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBA_Obfuscation', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Performs obfuscation of production databases defined in the scope of this agent job', 
		@category_name=N'Database Maintenance', 
--Insert SQL Auth Breakglass login below before executing script
		@owner_login_name=N'', 
		@notify_email_operator_name=N'DBASupport', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AccountManagement - Process Database', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''AccountManagement'',''AccountManagement_log'')
$sqlStoredProcedureArray = @(
''AccountManagementCleanDbEmailAddresses'',
''AccountManagementCleanDbNames'',
''AccountManagementCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''AccountManagement'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Allpay_Passport - Process Database', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''allpay_passport'',''allpay_passport_log'')
$sqlStoredProcedureArray = @(
''Allpay_PassportCleanDbEmailAddresses'',
''Allpay_PassportCleanDbNames'',
''Allpay_PassportCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Allpay_Passport'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AllpayHost - Process Database', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''allpayhost_Data'',''allpayhost_log'')
$sqlStoredProcedureArray = @(
''allpayhostCleanTransactionCards''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''allpayhost'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BACSFileValidation - Process Database', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''BACSFileValidation'',''BACSFileValidation_log'')
$sqlStoredProcedureArray = @(
''BACSFileValidationCleanDbEmailAddresses'',
''BACSFileValidationCleanDbNames'',
''BACSFileValidationCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''BACSFileValidation'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CardManagement - Process Database', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''CardManagement'',''CardManagement_log'')
$sqlStoredProcedureArray = @(
''CardManagementCleanDbEmailAddresses'',
''CardManagementCleanDbNames'',
''CardManagementCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''CardManagement'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Clients - Process Database', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''Clients'',''Clients_log'')
$sqlStoredProcedureArray = @(
''ClientsCleanDbEmailAddresses'',
''ClientsCleanDbNames'',
''ClientsCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Clients'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CSeries - Process Database', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''CSeries'',''CSeries_log'')
$sqlStoredProcedureArray = @(
''CSeriesCleanDbEmailAddresses'',
''CSeriesCleanDbNames'',
''CSeriesCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''CSeries'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CUSLogging - Process Database', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''CUSLogging'',''CUSLogging_log'')
$sqlStoredProcedureArray = @(
''CUSLoggingCleanDbEmailAddresses'',
''CUSLoggingCleanDbNames'',
''CUSLoggingCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''CUSLogging'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DirectDebits - Process Database', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''DirectDebits'',''DirectDebits_log'')
$sqlStoredProcedureArray = @(
''DirectDebitsCleanAccountHolderDetails1of2'',
''DirectDebitsCleanAccountHolderDetails2of2'',
''DirectDebitsCleanAllpayAccountKeys'',
''DirectDebitsCleanBankAccountActionDetails'',
''DirectDebitsCleanBankAccountHolderDetails'',
''DirectDebitsCleanBankAccountHolders'',
''DirectDebitsCleanBankAccounts'',
''DirectDebitsCleanCreateDdiActionCommonProperties'',
''DirectDebitsCleanDbSettings'',
''DirectDebitsCleanImportedInstructions'',
''DirectDebitsCleanImportedInstructions_BulkAmendmentInstruction'',
''DirectDebitsCleanTheRest''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''DirectDebits'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Dosh - Process Database', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''Lunchpay'',''Lunchpay_log'')
$sqlStoredProcedureArray = @(
''DoshCleanDbEmailAddresses'',
''DoshCleanDbNames'',
''DoshCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Dosh'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'EnvConfig - Process Database', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''EnvConf'',''EnvConf_log'')
$sqlStoredProcedureArray = @(
''EnvConfigCleanDbEmailAddresses'',
''EnvConfigCleanDbNames'',
''EnvConfigCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''EnvConfig'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Letters - Process Database', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''Letters'',''Letters_log'')
$sqlStoredProcedureArray = @(
''LettersCleanDbEmailAddresses'',
''LettersCleanDbNames'',
''LettersCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Letters'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Logging - Process Database', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''Logging'',''Logging_log'')
$sqlStoredProcedureArray = @(
''LoggingCleanDbEmailAddresses'',
''LoggingCleanDbNames'',
''LoggingCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Logging'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Metadata - Process Database', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''Metadata'',''Metadata_log'')
$sqlStoredProcedureArray = @(
''MetadataCleanDbEmailAddresses'',
''MetadataCleanDbNames'',
''MetadataCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Metadata'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ModulusCheck - Process Database', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''ModulusCheck'',''ModulusCheck_log'')
$sqlStoredProcedureArray = @(
''ModulusCheckCleanDbEmailAddresses'',
''ModulusCheckCleanDbNames'',
''ModulusCheckCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''ModulusCheck'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Notifications - Process Database', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''Notifications'',''Notifications_log'')
$sqlStoredProcedureArray = @(
''NotificationsCleanDbEmailAddresses'',
''NotificationsCleanDbNames'',
''NotificationsCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Notifications'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'P42 - Process Database', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''P42'',''P42_log'')
$sqlStoredProcedureArray = @(
''P42CleanAccAddr'',
''P42CleanAccNotes'',
''P42CleanAccounts'',
''P42CleanAdHocPrn'',
''P42CleanCardRequests'',
''P42CleanClieLtr'',
''P42CleanDdLetter'',
''P42CleanDdPayIns'',
''P42CleanDdRequests'',
''P42CleanOthers''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''P42'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PaymentManagement - Process Database', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''PaymentManagement'',''PaymentManagement_log'')
$sqlStoredProcedureArray = @(
''PaymentManagementCleanDbEmailAddresses'',
''PaymentManagementCleanDbNames'',
''PaymentManagementCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''PaymentManagement'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Payments - Process Database', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''Payments'',''Payments_log'')
$sqlStoredProcedureArray = @(
''PaymentsCleanAccounts'',
''PaymentsCleanCfp_UnreportedIncomingCustomerDirectDebitPayments'',
''PaymentsCleanCfp_UnreportedIncomingCustomerHostedPayments'',
''PaymentsCleanCfp_UnreportedIncomingCustomerNetworkPayments'',
''PaymentsCleanIncomingCustomerDirectDebitPayments''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Payments'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PifMiddleware - Process Database', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''PifMiddleware'',''PifMiddleware_log'')
$sqlStoredProcedureArray = @(
''PifMiddlewareCleanDbEmailAddresses'',
''PifMiddlewareCleanDbNames'',
''PifMiddlewareCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''PifMiddleware'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Prepaid - Process Database', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''PrimaryFileName'',''PrimaryLogFileName'')
$sqlStoredProcedureArray = @(
''PrepaidCleanDbEmailAddresses'',
''PrepaidCleanDbNames'',
''PrepaidCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Prepaid'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Scheduling - Process Database', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''Scheduling'',''Scheduling_log'')
$sqlStoredProcedureArray = @(
''SchedulingCleanDbEmailAddresses'',
''SchedulingCleanDbNames'',
''SchedulingCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Scheduling'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ServiceAuthentication - Process Database', 
		@step_id=23, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''ServiceAuthentication'',''ServiceAuthentication_log'')
$sqlStoredProcedureArray = @(
''ServiceAuthenticationCleanDbEmailAddresses'',
''ServiceAuthenticationCleanDbNames'',
''ServiceAuthenticationCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''ServiceAuthentication'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'STSConfigurationDatabase - Process Database', 
		@step_id=24, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''StsConfigurationDatabase'',''StsConfigurationDatabase_log'')
$sqlStoredProcedureArray = @(
''StsConfigurationDatabaseCleanDbEmailAddresses'',
''StsConfigurationDatabaseCleanDbNames'',
''StsConfigurationDatabaseCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''StsConfigurationDatabase'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Textpay - Process Database', 
		@step_id=25, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''Textpay_Data'',''Textpay_Log'')
$sqlStoredProcedureArray = @(
''TextpayCleanDbEmailAddresses'',
''TextpayCleanDbNames'',
''TextpayCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''Textpay'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'UserManagement - Process Database', 
		@step_id=26, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'#NOSQLPS
Set-Location "C:\Process\DB-Obfuscate\Script"

$databaseLogicalFileNames = @(''UserManagement'',''UserManagement_log'')
$sqlStoredProcedureArray = @(
''UserManagementCleanDbEmailAddresses'',
''UserManagementCleanDbNames'',
''UserManagementCleanDbPostalAddresses''
)

.\db-obfuscate-trigger.ps1 `
-databaseLogicalFileArray $databaseLogicalFileNames `
-databaseName ''UserManagement'' `
-sqlStoredProcedureArray $sqlStoredProcedureArray', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'SQL Obfuscation Service Account Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Remove Stale Obfuscation Logs', 
		@step_id=27, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [dbo].[RemoveStaleObfuscationLogRecords]', 
		@database_name=N'ObfuscationManager', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Weekly Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=2, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20231016, 
		@active_end_date=99991231, 
		@active_start_time=20000, 
		@active_end_time=235959, 
		@schedule_uid=N'38e14d82-a3cf-4864-995b-9876e1dd4e68'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO