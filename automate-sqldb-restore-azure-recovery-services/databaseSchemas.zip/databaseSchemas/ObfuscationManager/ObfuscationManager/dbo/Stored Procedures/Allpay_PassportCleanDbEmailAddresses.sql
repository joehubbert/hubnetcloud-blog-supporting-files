﻿/*
Clean the email addresses by replacing originals with fictional email address
*/
create procedure Allpay_PassportCleanDbEmailAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Allpay_Passport].[dbo].[appass_Users] SET [Email] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [Email]);
	UPDATE [Allpay_Passport].[dbo].[appass_Users] SET [LoweredEmail] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [LoweredEmail]);
return 0