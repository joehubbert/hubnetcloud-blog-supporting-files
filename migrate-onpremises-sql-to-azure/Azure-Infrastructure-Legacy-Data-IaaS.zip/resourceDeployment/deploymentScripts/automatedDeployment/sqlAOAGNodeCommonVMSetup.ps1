param
(
    [Parameter(Mandatory)][string]$activeDirectoryDomainFullyQualifiedName,
    [Parameter(Mandatory)][string]$activeDirectoryDomainNETBIOSName,
    [Parameter(Mandatory)][string]$deploymentSoftwarePackageStorageBlobPrefix,
    [Parameter(Mandatory)][string]$sqlInstallAdminUsername,
    [Parameter(Mandatory)][string]$sqlServerAdministratorGroupName,
    [Parameter(Mandatory)][string]$sqlServerBreakGlassAdminPassword,
    [Parameter(Mandatory)][string]$sqlServerBreakGlassAdminUsername,
    [Parameter(Mandatory)][string]$sqlServerDevOpsDeployUserPassword,
    [Parameter(Mandatory)][string]$sqlServerDevOpsDeployUserUsername,
    [Parameter(Mandatory)][string]$sqlServerProductKey,
    [Parameter(Mandatory)][string]$sqlServerSAAccountPassword
)

#Set Common Variables
$computerConfigurationInstallerDirectory = 'C:\ComputerConfiguration\Installer'
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$firewallRuleDisplayGroup = 'Allpay Custom Windows Firewall Rules'
$globallyManagedServiceAccountsToInstall = @('svcMSSQLAOAGA', 'svcMSSQLAOAGDB', 'svcMSSQLAOAGIS')
$scriptLogFileName = 'sqlAOAGNodeCommonVMSetup-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"
$serverMemoryCapacityBytes = (Get-WmiObject -class 'cim_physicalmemory' | Measure-Object -Property Capacity -Sum).Sum
$serverMemoryCapacityMegabytes = $serverMemoryCapacityBytes / 1Mb
$sqlServerAgentServiceAccount = "$activeDirectoryDomainNETBIOSName\svcMSSQLAOAGA$"
$sqlServerBackupRestoreDirectory = 'H:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\RESTORE'
$sqlServerBreakGlassAdminPasswordForCredential = ConvertTo-SecureString $sqlServerBreakGlassAdminPassword -AsPlainText -Force
$sqlServerBreakGlassAdminCredential = New-Object System.Management.Automation.PSCredential($sqlServerBreakGlassAdminUsername, $sqlServerBreakGlassAdminPasswordForCredential)
$sqlServerDatabaseEngineServiceAccount = "$activeDirectoryDomainNETBIOSName\svcMSSQLAOAGDB$"
$sqlServerDatabaseMailAccountDisplayName = "MSSQLDB Mail - $env:computername"
$sqlServerDatabaseMailAccountEmailAddress = "$env:computername@$activeDirectoryDomainFullyQualifiedName"
$sqlServerDatabaseMailAccountSMTPServer = "smtp.$activeDirectoryDomainFullyQualifiedName"
$sqlServerInstanceName = 'MSSQLSERVER'
$sqlServerIntegrationServicesServiceAccount = "$activeDirectoryDomainNETBIOSName\svcMSSQLAOAGIS$"
$sqlServerLocalIdentity = 'NT SERVICE\MSSQLSERVER'
$sqlServerMemoryCapacity = [math]::Round($serverMemoryCapacityMegabytes / 100 * 90)
$sqlServerSAAccountPasswordForCredential = ConvertTo-SecureString $sqlServerSAAccountPassword -AsPlainText -Force
$sqlServerSAAccountCredential = New-Object System.Management.Automation.PSCredential('sa', $sqlServerSAAccountPasswordForCredential)
$sqlServerSystemDatabaseFileDirectory = 'F:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA'
$sqlServerSystemDatabaseLogFileDirectory =  'G:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA_LOG'
$tempDBDiskTotalSizeBytes = (Get-Volume -DriveLetter I).Size
$tempDBDiskTotalSizeMegabytes = $tempDBDiskTotalSizeBytes / 1Mb
$tempDBDiskUsableSize = ($tempDBDiskTotalSizeMegabytes / 100) * 90
$tempDBFileSize = [math]::Round($tempDBDiskUsableSize /9)
$windowsFeaturesToInstall = @('RSAT-Clustering', 'RSAT-Clustering-Mgmt', 'RSAT-Clustering-PowerShell', 'Failover-Clustering')

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Install Windows Features
try
{
    Import-Module ServerManager
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to import the PowerShell module 'ServerManager' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

foreach($feature in $windowsFeaturesToInstall)
{
    try
    {
        Install-WindowsFeature $feature
        $currentTimestamp = Get-Date
        $outputText = "The Windows Feature $feature has been successfully installed on $env:computername at $currentTimestamp."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"        
    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $currentTimestamp = Get-Date
        $outputText = "An error occured when installing the Windows Feature $feature on $env:computername at $currentTimestamp with the following error '$errorMessage'."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
}

#Install Active Directory Globally Managed Service Accounts
try
{
    Import-Module ActiveDirectory
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to import the PowerShell module 'ActiveDirectory' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

foreach($gMSA in $globallyManagedServiceAccountsToInstall)
{
    try
    {
        Install-ADServiceAccount -Identity $gMSA
        $gMSATest = Test-AdServiceAccount $gMSA
        if ($gMSATest -eq $true)
        {
            $currentTimestamp = Get-Date
            $outputText = "The Active Directory Globally Managed Service Account $gMSA was successfully installed on $env:computername at $currentTimestamp."
            Write-Host $outputText
            Add-Content -Path $scriptLogPath "`n$outputText"
        }
        elseif ($gMSATest -eq $false)
        {
            $currentTimestamp = Get-Date
            $outputText = "The Active Directory Globally Managed Service Account $gMSA was not installed on $env:computername. Please investigate. Error logged at $currentTimestamp."
            Write-Host $outputText
            Add-Content -Path $scriptLogPath "`n$outputText"
        }            
    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $currentTimestamp = Get-Date
        $outputText = "An error occured when trying to install the Active Directory Globally Managed Service Account $gMSA on $env:computername at $currentTimestamp with the following error '$errorMessage'."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
}

#Configure Windows Firewall
try
{
    New-NetFirewallRule `
    -Action Allow `
    -Description 'Allows inbound connectivity for SQL Server Integration Services.' `
    -Direction Inbound `
    -DisplayName 'SQL Server - Allow Inbound MSSQL Integration Services' `
    -Group $firewallRuleDisplayGroup `
    -LocalPort 135 `
    -Name 'SQL Server - Allow Inbound MSSQL Integration Services' `
    -Profile "Domain, Private" `
    -Protocol TCP
    $currentTimestamp = Get-Date
    $outputText = "The MSSQL Integration Services Windows Firewall Rule has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing the MSSQL Integration Services Windows Firewall Rule on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    New-NetFirewallRule `
    -Action Allow `
    -Description 'Allows inbound connectivity for the SQL Server Database Mirroring Endpoint for the MSSQLSERVER instance.' `
    -Direction Inbound `
    -DisplayName 'SQL Server - Allow Inbound MSSQLDB Database Mirroring Endpoint' `
    -Group $firewallRuleDisplayGroup `
    -LocalPort 5022 `
    -Name 'SQL Server - Allow Inbound MSSQLDB Database Mirroring Endpoint' `
    -Profile "Domain, Private" `
    -Protocol TCP
    $currentTimestamp = Get-Date
    $outputText = "The MSSQL Database Mirroring Endpoint Windows Firewall Rule has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing the MSSQL Database Mirroring Endpoint Windows Firewall Rule on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    netsh int ipv4 add excludedportrange tcp startport=135 numberofports=1 store=persistent
    $currentTimestamp = Get-Date
    $outputText = "The port 135 has been successfully excluded from the Windows Dynamic Port Range on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when exluding the port 135 from the Windows Dynamic Port Range on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    netsh int ipv4 add excludedportrange tcp startport=5022 numberofports=1 store=persistent
    $currentTimestamp = Get-Date
    $outputText = "The port 5022 has been successfully excluded from the Windows Dynamic Port Range on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when exluding the port 5022 from the Windows Dynamic Port Range on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Download Software Packages
try
{
    Invoke-WebRequest `
    -Uri "$deploymentSoftwarePackageStorageBlobPrefix/AccessDatabaseEngine_x64.exe" `
    -OutFile "$computerConfigurationInstallerDirectory\AccessDatabaseEngine_x64.exe"
    $currentTimestamp = Get-Date
    $outputText = "The Microsoft Access Database Engine installer has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"    
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the Microsoft Access Database Engine installer to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Install Software Packages
Set-Location $computerConfigurationInstallerDirectory
try
{
    .\AccessDatabaseEngine_x64.exe /quiet
    Wait-Process 'AccessDatabaseEngine_x64'
    $currentTimestamp = Get-Date
    $outputText = "Microsoft Access Database Engine has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing Microsoft Access Database Engine on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    $diskMount = (Mount-DiskImage -ImagePath "$computerConfigurationInstallerDirectory\en_sql_server_2019_x64_dvd.iso")
    Set-Location ((Get-DiskImage -DevicePath $diskMount.DevicePath | Get-Volume).DriveLetter + ':\')
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to mount the SQL Server ISO file on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    .\setup.exe `
    /Action='Install' `
    /AgtSvcAccount=$sqlServerAgentServiceAccount `
    /AgtSvcStartupType='Automatic' `
    /BrowserSvcStartupType='Disabled' `
    /Features='SQLENGINE,REPLICATION,IS' `
    /FilestreamLevel=3 `
    /FilestreamShareName='DB01' `
    /ENU `
    /IAcceptSQLServerLicenseTerms `
    /IndicateProgress `
    /InstanceName=$sqlServerInstanceName `
    /ISSvcAccount=$sqlServerIntegrationServicesServiceAccount `
    /IsSvcStartupType='Automatic' `
    /PID=$sqlServerProductKey `
    /Quiet `
    /SAPWD=$sqlServerSAAccountPassword `
    /SecurityMode='SQL' `
    /SQLBackupDir='H:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\BACKUP' `
    /SQLMaxDOP=16 `
    /SQLMaxMemory=$sqlServerMemoryCapacity `
    /SQLSvcAccount=$sqlServerDatabaseEngineServiceAccount `
    /SQLSvcStartupType='Automatic' `
    /SQLSysAdminAccounts=$sqlInstallAdminUsername `
    /SQLTempDBDir='I:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\TEMPDB' `
    /SQLTempDBFileCount=8 `
    /SQLTempDBFileGrowth=1 `
    /SQLTempDBFileSize=8 `
    /SQLTempDBLogDir='I:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\TEMPDB_LOG' `
    /SQLTempDBLogFileSize=8 `
    /SQLTempDBLogFileGrowth=1 `
    /SQLUserDBDir='F:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\USER_DATA' `
    /SQLUserDBLogDir='G:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\USER_LOG' `
    /SuppressPrivacyStatementNotice `
    /TCPEnabled=1 `
    /UpdateEnabled=1 `
    /UpdateSource='MU'
    $currentTimestamp = Get-Date
    $outputText = "SQL Server has been successfully installed on $env:computername at $currentTimestamp using the Always-On Availability Group Configuration."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing SQL Server on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create Directory for SQL Server Database Restores
try
{
    New-Item -Path $sqlServerBackupRestoreDirectory -ItemType Directory
    $acl = Get-Acl $sqlServerBackupRestoreDirectory
    $permissionsToAdd = New-Object System.Security.AccessControl.FileSystemAccessRule($sqlServerLocalIdentity, "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
    $acl.SetAccessRule($permissionsToAdd)
    Set-Acl $sqlServerBackupRestoreDirectory $acl
    $currentTimestamp = Get-Date
    $outputText = "The database restore directory $sqlServerBackupRestoreDirectory has been successfully created and permissions have been granted to $sqlServerLocalIdentity on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the directory $sqlServerBackupRestoreDirectory on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create Directory for SQL Server System Database Data Files
try
{
    New-Item -Path $sqlServerSystemDatabaseFileDirectory -ItemType Directory
    $acl = Get-Acl $sqlServerSystemDatabaseFileDirectory
    $permissionsToAdd = New-Object System.Security.AccessControl.FileSystemAccessRule($sqlServerLocalIdentity, "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
    $acl.SetAccessRule($permissionsToAdd)
    Set-Acl $sqlServerSystemDatabaseFileDirectory $acl
    $currentTimestamp = Get-Date
    $outputText = "The database restore directory $sqlServerSystemDatabaseFileDirectory has been successfully created and permissions have been granted to $sqlServerLocalIdentity on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the directory $sqlServerSystemDatabaseFileDirectory on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create Directory for SQL Server System Database Log Files
try
{
    New-Item -Path $sqlServerSystemDatabaseLogFileDirectory -ItemType Directory
    $acl = Get-Acl $sqlServerSystemDatabaseLogFileDirectory
    $permissionsToAdd = New-Object System.Security.AccessControl.FileSystemAccessRule($sqlServerLocalIdentity, "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")
    $acl.SetAccessRule($permissionsToAdd)
    Set-Acl $sqlServerSystemDatabaseLogFileDirectory $acl
    $currentTimestamp = Get-Date
    $outputText = "The database restore directory $sqlServerSystemDatabaseLogFileDirectory has been successfully created and permissions have been granted to $sqlServerLocalIdentity on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the directory $sqlServerSystemDatabaseLogFileDirectory on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure Windows SMB Fileshare for SQL Backups
try
{
    New-SmbShare `
    -Description 'SMB Share for hosting SQL Backups.' `
    -FolderEnumerationMode 'Unrestricted' `
    -FullAccess ($sqlServerAdministratorGroupName, $sqlServerDatabaseEngineServiceAccount) `
    -Name 'SQLBackups' `
    -Path 'H:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\BACKUP'
    $currentTimestamp = Get-Date
    $outputText = "The Windows SMB Share called 'SQLBackups' has been successfully created on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the SMB Share 'SQLBackups' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure Windows SMB Fileshare for SQL Restores
try
{
    New-SmbShare `
    -Description 'SMB Share for hosting SQL Restores.' `
    -FolderEnumerationMode 'Unrestricted' `
    -FullAccess ($sqlServerAdministratorGroupName, $sqlServerDatabaseEngineServiceAccount) `
    -Name 'SQLRestore' `
    -Path $sqlServerBackupRestoreDirectory
    $currentTimestamp = Get-Date
    $outputText = "The Windows SMB Share called 'SQLRestore' has been successfully created on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the SMB Share 'SQLRestore' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure Windows SMB Fileshare for SQL Certificates
try
{
    New-SmbShare `
    -Description 'SMB Share for hosting SQL Certificates.' `
    -FolderEnumerationMode 'Unrestricted' `
    -FullAccess ($sqlServerAdministratorGroupName, $sqlServerDatabaseEngineServiceAccount) `
    -Name 'SQLCertificates$' `
    -Path 'C:\ComputerConfiguration\Certificates'
    $currentTimestamp = Get-Date
    $outputText = "The Windows SMB Share called 'SQLCertificates$' has been successfully created on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the SMB Share 'SQLCertificates$' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure Windows SMB Fileshare for SQL Encryption Keys
try
{
    New-SmbShare `
    -Description 'SMB Share for hosting SQL Encryption Keys.' `
    -FolderEnumerationMode 'Unrestricted' `
    -FullAccess ($sqlServerAdministratorGroupName, $sqlServerDatabaseEngineServiceAccount) `
    -Name 'SQLEncryptionKeys$' `
    -Path 'C:\ComputerConfiguration\EncryptionKeys' 
    $currentTimestamp = Get-Date
    $outputText = "The Windows SMB Share called 'SQLEncryptionKeys$' has been successfully created on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the SMB Share 'SQLEncryptionKeys$' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

Set-Location $computerConfigurationInstallerDirectory

#Install SQL Server 2019 Cumulative Update 19
try
{
    .\SQLServer2019-KB5023049-x64.exe /X:$computerConfigurationInstallerDirectory\SQLServer2019-KB5023049
    Wait-Process 'SQLServer2019-KB5023049-x64'
    $currentTimestamp = Get-Date
    $outputText = "SQLServer2019-KB5023049-x64.exe has been extracted to '$computerConfigurationInstallerDirectory\SQLServer2019-KB5023049' on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when extracting SQLServer2019-KB5023049-x64.exe on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

Set-Location $computerConfigurationInstallerDirectory\SQLServer2019-KB5023049

try
{
    .\setup.exe `
    /action=patch `
    /IAcceptSQLServerLicenseTerms `
    /instancename='MSSQLSERVER' `
    /quiet
    $currentTimestamp = Get-Date
    $outputText = "SQL Server 2019 CU19 has been installed on the sql server instance on the SQL Instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing SQL Server 2019 CU19 on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

Set-Location $computerConfigurationInstallerDirectory

try
{
    Remove-Item -LiteralPath $computerConfigurationInstallerDirectory\SQLServer2019-KB5023049 -Force -Recurse
    $currentTimestamp = Get-Date
    $outputText = "The extracted SQL Server 2019 CU19 installer directory has been removed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when removing the SQL Server 2019 CU19 installer directory on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure SQL Server into desired state
#Create Breakglass Login
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerSAAccountCredential `
    -Database 'master' `
    -Query "CREATE LOGIN [$sqlServerBreakGlassAdminUsername] WITH PASSWORD = '$sqlServerBreakGlassAdminPassword' `
    GO `
    ALTER SERVER ROLE sysadmin ADD MEMBER[$sqlServerBreakGlassAdminUsername]" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The breakglass login has been successfully created on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the breakglass login on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Disable sa Login
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "ALTER LOGIN [sa] DISABLE" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The sa login has been sucessfully disabled on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when disabling the sa login on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create SQL Server Administrators Group Login
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "CREATE LOGIN [$sqlServerAdministratorGroupName] FROM WINDOWS `
    GO `
    ALTER SERVER ROLE sysadmin ADD MEMBER [$sqlServerAdministratorGroupName]" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The SQL Server Administrators Group login has been successfully created on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the SQL Server Administrators Group login on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create DevOps Deploy User Login
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "CREATE LOGIN [$sqlServerDevOpsDeployUserUsername] WITH PASSWORD = '$sqlServerDevOpsDeployUserPassword' `
    GO `
    ALTER SERVER ROLE sysadmin ADD MEMBER[$sqlServerDevOpsDeployUserUsername]" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The DevOpsDeployUser login has been successfully created on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the DevOpsDeployUser login on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Enable Database Mail XPs
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "sp_configure 'Show Advanced Options', 1; RECONFIGURE; `
    GO `
    sp_configure 'Database Mail XPs', 1; RECONFIGURE" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "Database Mail XPs has been successfully enabled on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when enabling Database Mail XPs on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Add Database Mail Profile
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'msdb' `
    -Query "EXEC [dbo].[sysmail_add_profile_sp] `
    @profile_name = 'MSSQLDBMailProfile', `
    @description = 'Profile for sending MSSQL Database Mail.'" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The Database Mail Profile 'MSSQLDBMailProfile' has been successfully created on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the Database Mail Profile 'MSSQLDBMailProfile' on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Add Database Mail Account
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'msdb' `
    -Query "EXEC [dbo].[sysmail_add_account_sp] `
    @account_Name = 'MSSQLDBMailAccount', `
    @description = 'Account for sending MSSQL Database Mail.', `
    @email_address = '$sqlServerDatabaseMailAccountEmailAddress', `
    @display_name = '$sqlServerDatabaseMailAccountDisplayName', `
    @mailserver_name = '$sqlServerDatabaseMailAccountSMTPServer', `
    @replyto_address = 'IT@allpay.net', `
    @port = 25" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The Database Mail Account 'MSSQLDBMailAccount' has been successfully created on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the Database Mail Account 'MSSQLDBMailAccount' on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Add Database Mail Account to Database Mail Profile
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'msdb' `
    -Query "EXEC [dbo].[sysmail_add_profileaccount_sp] `
    @profile_name = 'MSSQLDBMailProfile', `
    @account_name = 'MSSQLDBMailAccount', `
    @sequence_number = 1" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The Database Mail Account 'MSSQLDBMailAccount' has been successfully added to the Database Mail Profile 'MSSQLDBMailProfile' on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when adding the Database Mail Account 'MSSQLDBMailAccount' to the Database Mail Profie 'MSSQLDBMailProfile' on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure SQL Server Agent To Use Database Mail
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "EXEC [dbo].[xp_instance_regwrite] N'HKEY_LOCAL_MACHINE', `
    N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', `
    N'UseDatabaseMail', `
    N'REG_DWORD', 1`
    EXEC [dbo].[xp_instance_regwrite] N'HKEY_LOCAL_MACHINE', `
    N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', `
    N'DatabaseMailProfile', `
    N'REG_SZ', `
    N'MSSQLDBMailProfile'" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "SQL Server Agent has been enabled to use the Database Mail Profile 'MSSQLDBMailProfile' on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when SQL Server Agent to use the Database Mail Profie 'MSSQLDBMailProfile' on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create Operator for SQL Server Agent
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'msdb' `
    -Query "EXEC [dbo].[sp_add_operator] `
    @name = 'DBASupport', `
    @enabled = 1, `
    @email_address = 'InfrastructureTeam@allpay.net; IT@allpay.net'" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The operator 'DBASupport' has been added to the SQL Server Agent on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when adding the operator 'DBASupport' to the SQL Server Agent on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create SQL Database Mirroring HADR Endpoint
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "CREATE ENDPOINT [sql_always_on_mirroring_endpoint] `
    STATE=STARTED `
    AS TCP `
    (LISTENER_PORT = 5022) `
    FOR DATABASE_MIRRORING
    ( `
    ENCRYPTION = REQUIRED, `
    ROLE = PARTNER)" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The Database Mirroring Endpoint 'sql_always_on_database_mirroring_endpoint' has been configured to listen on 5022 on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the Database Mirroring Endpoint 'sql_always_on_database_mirroring_endpoint' on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Set Cost Threshold for Parallelism
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "EXEC sp_configure 'Show Advanced Options', 1; RECONFIGURE; `
    GO `
    EXEC sp_configure 'Cost Threshold for Parallelism', 50; RECONFIGURE; `
    GO" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The Cost Threshold for Parallelism has been set to 50 on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the Cost Threshold for Parallelism on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Enable XACT_ABORT
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "SET XACT_ABORT ON" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "XACT_ABORT has been enabled on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when enabling XACT_ABORT on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure Permissions to Allow NTAUTHORITY\SYSTEM To Create Always-On Availability Groups
try
{
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'master' `
    -Query "GRANT ALTER ANY AVAILABILITY GROUP TO [NT AUTHORITY\SYSTEM] `
    GO `
    GRANT CONNECT SQL TO [NT AUTHORITY\SYSTEM] `
    GO `
    GRANT VIEW SERVER STATE TO [NT AUTHORITY\SYSTEM] `
    GO" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "NTAUTHORITY\SYSTEM now has permission to create Always-On Availability Groups on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when giving NTAUTHORITY\SYSTEM permission to create Always-On Availability Groups on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Give SQL Server Agent permission to Microsoft Access Database Engine WMI Object
try
{
    $user = 'svcMSSQLAOAGA$'
    $appDescription = 'MSDAINITIALIZE'
    $app = Get-WmiObject -Query ('SELECT * FROM Win32_DCOMApplicationSetting WHERE Description = "' + $appDescription + '"') -enableallprivileges
    $appSecurityDescriptor = $app.GetLaunchSecurityDescriptor()
    $appSecurityDescriptor = $appSecurityDescriptor.Descriptor
    $trustee = ([wmiclass] 'Win32_Trustee').CreateInstance()
    $trustee.Domain = $activeDirectoryDomainNETBIOSName
    $trustee.Name = $user
    $permissionLevel = 31
    $ace = ([wmiclass] 'Win32_ACE').CreateInstance()
    $ace.AccessMask = $permissionLevel
    $ace.AceFlags = 0
    $ace.AceType = 0
    $ace.Trustee = $trustee
    [System.Management.ManagementBaseObject[]] $permissionDACL = $appSecurityDescriptor.DACL + @($ace)
    $appSecurityDescriptor.DACL = $permissionDACL
    $app.SetLaunchSecurityDescriptor($appSecurityDescriptor)
    $currentTimestamp = Get-Date
    $outputText = "$sqlServerAgentServiceAccount now has permission to utilize the Microsoft Access Database Engine on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when giving $sqlServerAgentServiceAccount permission to utilize the Microsoft Access Database Engine on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure TempDB File Sizes
$tempDBFileList = @('tempdev', 'temp2', 'temp3', 'temp4', 'temp5', 'temp6', 'temp7', 'temp8', 'templog')

foreach($file in $tempDBFileList)
{
    try
    {
    Start-Job -ArgumentList $file, $scriptLogPath, $sqlServerBreakGlassAdminCredential, $sqlServerInstanceName, $tempDBFileSize -ScriptBlock {
    param
    (
        $file,
        $scriptLogPath,
        [PSCredential]$sqlServerBreakGlassAdminCredential,
        $sqlServerInstanceName,
        $tempDBFileSize
    )
    Invoke-SqlCmd `
    -Credential $sqlServerBreakGlassAdminCredential `
    -Database 'tempdb' `
    -Query "ALTER DATABASE [tempdb] MODIFY FILE (NAME = $file, SIZE = $tempDBFileSize MB, MAXSIZE = $tempDBFileSize MB)" `
    -ServerInstance $env:computername
    $currentTimestamp = Get-Date
    $outputText = "The tempdb file $file has been changed to $tempDBFileSize MB on the SQL Instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
    }
    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $currentTimestamp = Get-Date
        $outputText = "An error occured when setting the tempdb file $file to $tempDBFileSize MB on the SQL Instance $sqlServerInstanceName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
}

Get-Job | Wait-Job

$currentTimestamp = Get-Date
$outputText = "Execution of sqlAOAGNodeCommonVMSetup.ps1 successfully completed on $env:computername at $currentTimestamp. A server reboot will be triggered immediately."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer