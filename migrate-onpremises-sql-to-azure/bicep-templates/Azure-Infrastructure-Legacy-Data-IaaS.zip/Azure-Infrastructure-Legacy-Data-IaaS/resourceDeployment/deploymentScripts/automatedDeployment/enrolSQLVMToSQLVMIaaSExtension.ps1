param
(
    [Parameter(Mandatory)][string]$environmentDescriptionShort,
    [Parameter(Mandatory)][string]$resourceGroupName,
    [Parameter(Mandatory)][string]$virtualMachineName,
    [Parameter(Mandatory)][string]$virtualMachineRole
)

$vm = Get-AzVM -Name $virtualMachineName -ResourceGroupName $resourceGroupName

if($environmentDescriptionShort -eq 'NonProd')
{
    New-AzSqlVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName -Location $vm.Location -LicenseType 'PAYG' -SqlManagementType Full
}
elseif($environmentDescriptionShort -eq 'Prod')
{
    if($virtualMachineRole -eq 'Primary')
    {
        New-AzSqlVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName -Location $vm.Location -LicenseType 'AHUB' -SqlManagementType Full
    }
    elseif($virtualMachineRole -eq 'Secondary')
    {
        New-AzSqlVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName -Location $vm.Location -LicenseType 'DR' -SqlManagementType Full
    }
    else
    {
        Write-Host "Invalid virtualMachineRole was parsed. $virtualMachineRole was parsed. Only 'Primary' and 'Secondary' are accepted."
    }
}
else 
{
    Write-Host "Invalid environmentDescriptionShort was parsed. $environmentDescriptionShort was parsed. Only 'NonProd' and 'Prod' are accepted."
}
