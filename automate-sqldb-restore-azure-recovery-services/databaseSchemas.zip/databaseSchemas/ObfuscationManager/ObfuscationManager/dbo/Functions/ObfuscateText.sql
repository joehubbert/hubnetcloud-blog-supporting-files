﻿CREATE FUNCTION [dbo].[ObfuscateText]
(@seedA INT, @seedB INT, @text NVARCHAR (MAX))
RETURNS NVARCHAR (MAX)
AS
 EXTERNAL NAME [ObfuscationManager].[UserDefinedFunctions].[ObfuscateText]

