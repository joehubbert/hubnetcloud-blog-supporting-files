﻿/*
Clean the email addresses by replacing originals with fictional email address
*/
create procedure TextpayCleanDbEmailAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Textpay].[dbo].[ITSupportObfuscatedPANAffectedCustomers] SET [Email] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [Email]);
	UPDATE [Textpay].[dbo].[Users] SET [EmailAddress] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [EmailAddress]);
return 0