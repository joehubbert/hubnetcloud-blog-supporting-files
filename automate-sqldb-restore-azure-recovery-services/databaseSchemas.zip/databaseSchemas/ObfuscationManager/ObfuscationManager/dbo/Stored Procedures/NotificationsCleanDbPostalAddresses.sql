﻿/*
Clean the postal addresses by replacing originals with fictional postal address
*/
create procedure NotificationsCleanDbPostalAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Notifications].[dbo].[EmailMessage] SET [BodyHTML] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [BodyHTML]);
	UPDATE [Notifications].[dbo].[EmailMessage] SET [BodyText] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [BodyText]);
	UPDATE [Notifications].[dbo].[EmailMessage] SET [ToAddress] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [ToAddress]);
	UPDATE [Notifications].[dbo].[EmailMessage_Primary] SET [BodyHTML] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [BodyHTML]);
	UPDATE [Notifications].[dbo].[EmailMessage_Primary] SET [BodyText] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [BodyText]);
	UPDATE [Notifications].[dbo].[EmailMessage_Primary] SET [ToAddress] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [ToAddress]);
	UPDATE [Notifications].[dbo].[EmailMessage_Secondary] SET [BodyHTML] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [BodyHTML]);
	UPDATE [Notifications].[dbo].[EmailMessage_Secondary] SET [BodyText] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [BodyText]);
	UPDATE [Notifications].[dbo].[EmailMessage_Secondary] SET [ToAddress] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [ToAddress]);
	UPDATE [Notifications].[dbo].[SMSMessage] SET [Body] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Body]);
	UPDATE [Notifications].[dbo].[SMSMessage] SET [DestinationNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DestinationNumber]);
	UPDATE [Notifications].[dbo].[SMSMessage_Primary] SET [Body] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Body]);
	UPDATE [Notifications].[dbo].[SMSMessage_Primary] SET [DestinationNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DestinationNumber]);
	UPDATE [Notifications].[dbo].[SMSMessage_Secondary] SET [Body] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Body]);
	UPDATE [Notifications].[dbo].[SMSMessage_Secondary] SET [DestinationNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [DestinationNumber]);
return 0