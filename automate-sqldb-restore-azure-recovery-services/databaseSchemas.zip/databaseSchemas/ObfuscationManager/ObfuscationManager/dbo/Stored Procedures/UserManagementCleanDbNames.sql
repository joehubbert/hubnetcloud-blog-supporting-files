﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure UserManagementCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	UPDATE [UserManagement].[dbo].[Customer_PhoneNumber] SET [FriendlyName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FriendlyName]);
	UPDATE [UserManagement].[dbo].[Customer_PhoneNumber] SET [Number] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Number]);
	UPDATE [UserManagement].[dbo].[TextPay_User] SET [FirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FirstName]);
	UPDATE [UserManagement].[dbo].[TextPay_User] SET [LastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LastName]);
	UPDATE [UserManagement].[dbo].[TextPay_User] SET [Nickname] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Nickname]);
	UPDATE [UserManagement].[dbo].[User] SET [FamilyName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FamilyName]);
	UPDATE [UserManagement].[dbo].[User] SET [FirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FirstName]);
	UPDATE [UserManagement].[dbo].[User] SET [LoweredUserName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LoweredUserName]);
	UPDATE [UserManagement].[dbo].[User] SET [UserName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [UserName]);
return 0