﻿/*
Clean the email addresses by replacing originals with fictional email address
*/
create procedure allpayhostCleanTransactionCards @seedA int, @seedB int
as
	set nocount on;
	--[TransactionCards];
	-- the work table
	select 
	 [TransactionCardId]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [TransactionCard_NameOnCard]) [TransactionCard_NameOnCard] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [TransactionCard_Address]) [TransactionCard_Address] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [TransactionCard_City]) [TransactionCard_City] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [TransactionCard_PostCode]) [TransactionCard_PostCode] 
	into [allpayhost].[dbo].[TransactionCards_WORK] 
	from [allpayhost].[dbo].[TransactionCards];
	-- update the parent table with obfuscations
	UPDATE [allpayhost].[dbo].[TransactionCards] 
	SET 
	 [TransactionCard_NameOnCard] = [allpayhost].[dbo].[TransactionCards_WORK].[TransactionCard_NameOnCard] 
	,[TransactionCard_Address] = [allpayhost].[dbo].[TransactionCards_WORK].[TransactionCard_Address] 
	,[TransactionCard_City] = [allpayhost].[dbo].[TransactionCards_WORK].[TransactionCard_City] 
	,[TransactionCard_PostCode] = [allpayhost].[dbo].[TransactionCards_WORK].[TransactionCard_PostCode] 
	from [allpayhost].[dbo].[TransactionCards_WORK]
	where [allpayhost].[dbo].[TransactionCards_WORK].[TransactionCardId] = [allpayhost].[dbo].[TransactionCards].[TransactionCardId];
	-- drop the work table
	drop table [allpayhost].[dbo].[TransactionCards_WORK];
return 0