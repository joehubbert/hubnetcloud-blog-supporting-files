﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure AccountManagementCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	UPDATE [AccountManagement].[dbo].[PaymentRecipient] SET [FriendlyName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FriendlyName]);
return 0