﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure P42CleanClieLtr @seedA int, @seedB int
as
	set nocount on;
	--[AP_CLIELTR];
	-- the work table
	select 
	 [AP_RECNO]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_AADD1]) [AP_AADD1]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_AADD2]) [AP_AADD2]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_AADD3]) [AP_AADD3]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_AADD4]) [AP_AADD4]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_APOSTCODE]) [AP_APOSTCODE]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ANAME]) [AP_ANAME]
	into [P42].[dbo].[AP_CLIELTR_WORK] 
	from [P42].[dbo].[AP_CLIELTR];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [P42]; create clustered index [CIX_AP_CLIELTR_WORK(AP_RECNO)] on AP_CLIELTR_WORK(AP_RECNO);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @AP_CLIELTR table(AP_RECNO int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [P42].[dbo].[AP_CLIELTR] 
		SET 
		 [AP_AADD1] = [P42].[dbo].[AP_CLIELTR_WORK].[AP_AADD1]
		,[AP_AADD2] = [P42].[dbo].[AP_CLIELTR_WORK].[AP_AADD2]
		,[AP_AADD3] = [P42].[dbo].[AP_CLIELTR_WORK].[AP_AADD3]
		,[AP_AADD4] = [P42].[dbo].[AP_CLIELTR_WORK].[AP_AADD4]
		,[AP_APOSTCODE] = [P42].[dbo].[AP_CLIELTR_WORK].[AP_APOSTCODE]
		,[AP_ANAME] = [P42].[dbo].[AP_CLIELTR_WORK].[AP_ANAME]
		output INSERTED.AP_RECNO into @AP_CLIELTR
		from [P42].[dbo].[AP_CLIELTR_WORK]
		where [P42].[dbo].[AP_CLIELTR_WORK].[AP_RECNO] = [P42].[dbo].[AP_CLIELTR].[AP_RECNO];
		--remove the records already updated
		delete from [P42].[dbo].[AP_CLIELTR_WORK] where AP_RECNO in (select AP_RECNO from @AP_CLIELTR);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @AP_CLIELTR;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [P42].[dbo].[AP_CLIELTR_WORK];
return 0