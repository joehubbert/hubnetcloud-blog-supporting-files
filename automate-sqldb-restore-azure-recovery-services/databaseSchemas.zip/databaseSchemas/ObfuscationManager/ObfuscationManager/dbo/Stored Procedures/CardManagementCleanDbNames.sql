﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure CardManagementCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	UPDATE [CardManagement].[dbo].[PaymentCard] SET [NameOnCard] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [NameOnCard]);
return 0