#Set Common Variables
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$globallyManagedServiceAccountsToInstall = @('svcMSSQLBZA', 'svcMSSQLBZDB', 'svcMSSQLBZIS')
$progressPreference = 'SilentlyContinue'
$scriptLogFileName = 'prepareSQLServerB-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Install Active Directory Globally Managed Service Accounts
try
{
    Import-Module ActiveDirectory
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to import the PowerShell module 'ActiveDirectory' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

foreach($gMSA in $globallyManagedServiceAccountsToInstall)
{
    try
    {
        Install-ADServiceAccount -Identity $gMSA
        $gMSATest = Test-AdServiceAccount $gMSA
        if ($gMSATest -eq $true)
        {
            $currentTimestamp = Get-Date
            $outputText = "The Active Directory Globally Managed Service Account $gMSA was successfully installed on $env:computername at $currentTimestamp."
            Write-Host $outputText
            Add-Content -Path $scriptLogPath "`n$outputText"
        }
        elseif ($gMSATest -eq $false)
        {
            $currentTimestamp = Get-Date
            $outputText = "The Active Directory Globally Managed Service Account $gMSA was not installed on $env:computername. Please investigate. Error logged at $currentTimestamp."
            Write-Host $outputText
            Add-Content -Path $scriptLogPath "`n$outputText"
        }            
    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $currentTimestamp = Get-Date
        $outputText = "An error occured when trying to install the Active Directory Globally Managed Service Account $gMSA on $env:computername at $currentTimestamp with the following error '$errorMessage'."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
}

$currentTimestamp = Get-Date
$outputText = "prepareSQLServerB.ps1 has completed execution on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer