Import-Module ActiveDirectory
Add-KdsRootKey -EffectiveTime ((Get-Date).Addhours(-10)) 
$activeDirectoryDomainFQDN = '<DomainFQDN>'
$serverList  = @('<primaryNodeName>','<secondaryNodeName>','<secondaryNodeName>','<reportingServicesServerName>')

$ListOfServersAccountsWillBeUsedOn = $serverList.ForEach{ return (Get-ADComputer $_)  }
Write-Output $ListOfServersAccountsWillBeUsedOn


New-ADServiceAccount -Name svcMSSQLDB `
                     -Description 'Service Account for MSSQL Database Engine' `
                     -DNSHostName "svcmssqldb.$activeDirectoryDomainFQDN" `
                     -ManagedPasswordIntervalInDays 7 `
                     -PrincipalsAllowedToRetrieveManagedPassword $ListOfServersAccountsWillBeUsedOn `
                     -TrustedForDelegation $true `
                     -Enabled $true `
                     -PassThru 

New-ADServiceAccount -Name svcMSSQLIS `
                     -Description 'Service Account for MSSQL Integration Services' `
                     -DNSHostName "svcmssqlis.$activeDirectoryDomainFQDN" `
                     -ManagedPasswordIntervalInDays 7 `
                     -PrincipalsAllowedToRetrieveManagedPassword $ListOfServersAccountsWillBeUsedOn `
                     -TrustedForDelegation $true `
                     -Enabled $true `
                     -PassThru 

New-ADServiceAccount -Name svcMSSQLA `
                     -Description 'Service Account for MSSQL Agent' `
                     -DNSHostName "svcmssqla.$activeDirectoryDomainFQDN" `
                     -ManagedPasswordIntervalInDays 7 `
                     -PrincipalsAllowedToRetrieveManagedPassword $ListOfServersAccountsWillBeUsedOn `
                     -TrustedForDelegation $true `
                     -Enabled $true `
                     -PassThru 

New-ADServiceAccount -Name svcMSSQLRS `
                     -Description 'Service Account for MSSQL Reporting Services' `
                     -DNSHostName "svcmssqlrs.$activeDirectoryDomainFQDN" `
                     -ManagedPasswordIntervalInDays 7 `
                     -PrincipalsAllowedToRetrieveManagedPassword $ListOfServersAccountsWillBeUsedOn `
                     -TrustedForDelegation $true `
                     -Enabled $true `
                     -PassThru 
