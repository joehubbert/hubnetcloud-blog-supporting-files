﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure PaymentsCleanCfp_UnreportedIncomingCustomerDirectDebitPayments @seedA int, @seedB int
as
	set nocount on;
	--[Cfp_UnreportedIncomingCustomerDirectDebitPayments];
	-- the work table
	select 
	 [PaymentId]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountName]) [AccountName] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SURNAME]) [AP_SURNAME] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AccountNumber]) [AccountNumber] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_TITLEINITS]) [AP_TITLEINITS] 
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [SortCode]) [SortCode]
	into [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK] 
	from [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [Payments]; create clustered index [CIX_Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK(PaymentId)] on Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK(PaymentId);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @Cfp_UnreportedIncomingCustomerDirectDebitPayments table(PaymentId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments] 
		SET 
		 [AccountName] = [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK].[AccountName] 
		,[AP_SURNAME] = [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK].[AP_SURNAME] 
		,[AccountNumber] = [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK].[AccountNumber] 
		,[AP_TITLEINITS] = [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK].[AP_TITLEINITS] 
		,[SortCode] = [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK].[SortCode]
		output INSERTED.PaymentId into @Cfp_UnreportedIncomingCustomerDirectDebitPayments
		from [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK]
		where [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK].[PaymentId] = [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments].[PaymentId];
		--remove the records already updated
		delete from [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK] where PaymentId in (select PaymentId from @Cfp_UnreportedIncomingCustomerDirectDebitPayments);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @Cfp_UnreportedIncomingCustomerDirectDebitPayments;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [Payments].[dbo].[Cfp_UnreportedIncomingCustomerDirectDebitPayments_WORK];
return 0