﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure NotificationsCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Notifications].[dbo].[Notification] SET [LastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LastName]);
	UPDATE [Notifications].[dbo].[Notification_Primary] SET [LastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LastName]);
	UPDATE [Notifications].[dbo].[Notification_Secondary] SET [LastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LastName]);
return 0