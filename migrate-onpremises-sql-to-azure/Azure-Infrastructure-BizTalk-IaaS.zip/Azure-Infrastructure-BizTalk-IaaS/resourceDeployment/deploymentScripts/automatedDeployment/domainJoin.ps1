param (
    [Parameter(Mandatory)][string]$activeDirectoryDomain,
    [Parameter(Mandatory)][string]$windowsInstallPassword,
    [Parameter(Mandatory)][string]$windowsInstallUsername
)
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$scriptLogFileName = 'domainJoin-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"
$windowsInstallPasswordForCredential = ConvertTo-SecureString $windowsInstallPassword -AsPlainText -Force
$windowsInstallCredential = New-Object System.Management.Automation.PSCredential($windowsInstallUsername, $windowsInstallPasswordForCredential)

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file."
}

#Join Computer to Active Directory
try
{
    Add-Computer -DomainName $activeDirectoryDomain -Credential $windowsInstallCredential
    $currentTimestamp = Get-Date
    $outputText = "$env:computername was joined to Active Directory at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"   

}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when joining $env:computername to Active Directory at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
Start-Sleep -Seconds 10

Restart-Computer