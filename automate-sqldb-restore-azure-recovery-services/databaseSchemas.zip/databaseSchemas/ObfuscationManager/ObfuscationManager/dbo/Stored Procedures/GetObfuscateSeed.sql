﻿CREATE PROCEDURE [dbo].[GetObfuscateSeed]
@seedA INT OUTPUT, @seedB INT OUTPUT
AS EXTERNAL NAME [ObfuscationManager].[UserDefinedFunctions].[GetObfuscateSeed]

