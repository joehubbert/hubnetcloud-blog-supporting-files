﻿/*
Clean the email addresses by replacing originals with fictional email address
*/
create procedure UserManagementCleanDbEmailAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [UserManagement].[dbo].[TextPay_User] SET [EmailAddress] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [EmailAddress]);
	UPDATE [UserManagement].[dbo].[User] SET [Email] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [Email]);
	UPDATE [UserManagement].[dbo].[User] SET [LoweredEmail] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [LoweredEmail]);
return 0