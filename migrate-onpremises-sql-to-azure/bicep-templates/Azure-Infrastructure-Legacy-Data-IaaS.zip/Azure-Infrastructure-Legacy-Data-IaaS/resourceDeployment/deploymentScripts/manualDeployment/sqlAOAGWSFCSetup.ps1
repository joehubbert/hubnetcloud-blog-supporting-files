param 
(
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterCloudWitnessAccount,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterCloudWitnessKey,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterSQLListenerName,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterWSFCListenerName,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterLoadBalancerIPAddressSQL,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterLoadBalancerIPAddressWSFC,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterLoadBalancerSubnetMask,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterLoadBalancerTripleOctet,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterNodeA,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterNodeB,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterNodeC
)

$clusterNetworkName = 'SQL AOAG Cluster Network'
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$scriptFileName = 'sqlAOAGPrimaryNodeVMSetup-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptFileName"
$windowsServerFailoverClusterLoadBalancerTripleOctetWildcard = "$windowsServerFailoverClusterLoadBalancerTripleOctet.*"

#Create Script Log File
$currentTimestamp = Get-Date
New-Item -Path $computerConfigurationLogDirectory -Name $scriptFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force

#Create and Configure Windows Server Failover Cluster
Import-Module FailoverClusters
New-Cluster -Name $windowsServerFailoverClusterWSFCListenerName -ManagementPointNetworkType Singleton -Node $windowsServerFailoverClusterNodeA
Set-ClusterQuorum -CloudWitness -AccountName $windowsServerFailoverClusterCloudWitnessAccount -AccessKey $windowsServerFailoverClusterCloudWitnessKey
$oldClusterNetworkName = Get-ClusterNetwork | Where-Object{$_.Address -like $windowsServerFailoverClusterLoadBalancerTripleOctetWildcard }| Select-Object name | ForEach-Object {$_.name}
(Get-ClusterNetwork -Name $oldClusterNetworkName).Name = $clusterNetworkName
Get-ClusterResource -Name 'Cluster IP Address'  | Set-ClusterParameter -Multiple @{"Address"="$windowsServerFailoverClusterLoadBalancerIPAddressWSFC";"EnableDhcp"=0;"ProbePort"=58888;"SubnetMask"="$windowsServerFailoverClusterLoadBalancerSubnetMask"}
Get-Cluster | Start-ClusterResource "Cluster Name"

#Before running the next code block, ensure that the computer object for $windowsServerFailoverClusterWSFCListenerName has permissions to create computer objects in the OU
$activeDirectoryPermissionChangeConfirmation = Read-Host -Prompt "Please confirm that Active Directory permissions have been altered for $windowsServerFailoverClusterWSFCListenerName. Please ensure that the computer object for $windowsServerFailoverClusterWSFCListenerName has permissions to create computer objects in the same OU. Only Y or N is allowed"

if($activeDirectoryPermissionChangeConfirmation -eq 'N')
{
    Write-Host "Required Active Directory permissions have not been created. Please ensure that the computer object for $windowsServerFailoverClusterWSFCListenerName has permissions to create computer objects in the same OU."
    Read-Host -Prompt "Please confirm that Active Directory permissions have been altered for $windowsServerFailoverClusterWSFCListenerName. Only Y or N is allowed"
}

while('Y', 'N' -notcontains $activeDirectoryPermissionChangeConfirmation)
{
   Read-Host -Prompt "Please confirm that Active Directory permissions have been altered for $windowsServerFailoverClusterWSFCListenerName. Only Y or N is allowed"
   if($activeDirectoryPermissionChangeConfirmation -eq 'N')
    {
        Write-Host "Required Active Directory permissions have not been created. Please ensure that the computer object for $windowsServerFailoverClusterWSFCListenerName has permissions to create computer objects in the same OU."
        Read-Host -Prompt "Please confirm that Active Directory permissions have been altered for $windowsServerFailoverClusterWSFCListenerName. Only Y or N is allowed"
    }
}

Add-ClusterGroup -Name $windowsServerFailoverClusterWSFCListenerName
Add-ClusterResource -Name $windowsServerFailoverClusterSQLListenerName -Group $windowsServerFailoverClusterWSFCListenerName -ResourceType "Network Name"
Add-ClusterResource -Name "$windowsServerFailoverClusterSQLListenerName IP Address" -Group $windowsServerFailoverClusterWSFCListenerName -ResourceType "IP Address"
Get-ClusterResource -Name $windowsServerFailoverClusterSQLListenerName | Set-ClusterParameter -Name DNSName -Value $windowsServerFailoverClusterSQLListenerName
Get-ClusterResource -Name "$windowsServerFailoverClusterSQLListenerName IP Address"  | Set-ClusterParameter -Multiple @{"Address"="$windowsServerFailoverClusterLoadBalancerIPAddressSQL";"EnableDhcp"=0;"Network"="$clusterNetworkName";"ProbePort"=59999;"SubnetMask"="$windowsServerFailoverClusterLoadBalancerSubnetMask"}
Set-ClusterResourceDependency -Resource $windowsServerFailoverClusterSQLListenerName -Dependency "[$windowsServerFailoverClusterSQLListenerName IP Address]"
Stop-ClusterGroup -Name $windowsServerFailoverClusterWSFCListenerName
Start-ClusterGroup -Name $windowsServerFailoverClusterWSFCListenerName
Add-ClusterNode -Name $windowsServerFailoverClusterNodeB
Add-ClusterNode -Name $windowsServerFailoverClusterNodeC
Set-ClusterOwnerNode -Group $windowsServerFailoverClusterWSFCListenerName $windowsServerFailoverClusterNodeA, $windowsServerFailoverClusterNodeB, $windowsServerFailoverClusterNodeC

$currentTimestamp = Get-Date
$outputText = "The Windows Server Failover Cluster has been has been successfully installed on $windowsServerFailoverClusterNodeA, $windowsServerFailoverClusterNodeB and $windowsServerFailoverClusterNodeC at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "n$outputText"

$currentTimestamp = Get-Date
$outputText = "Execution of sqlAOAGPrimaryNodeSetup.ps1 successfully completed on $env:computername at $currentTimestamp. A server reboot will be triggered immediately."
Write-Host $outputText
Add-Content -Path $scriptLogPath "n$outputText"

Restart-Computer -ComputerName $windowsServerFailoverClusterNodeB, $windowsServerFailoverClusterNodeC, $windowsServerFailoverClusterNodeA