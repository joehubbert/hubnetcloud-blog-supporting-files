# Introduction 
This repository stores the templates and configuration scripts for deploying a SQL Server Failover Cluster Instance (FCI) to Windows Server.
- The current configuration:
   - Windows Server 2019
   - SQL Server 2014

**NB - This repository only deploys SQL Server NOT BizTalk. There is some code in resourcesNotReadyForRelease to deploy BizTalk 2020 on Windows Server 2019**

# Getting Started
- You will need to clone this repository to your local machine.

**Tools**:
- Visual Studio Code
- PowerShell 7+
- Bicep extension for Visual Studio Code
- ARM Template extension for Visual Studio Code

**Active Directory Provisions**
- Service Accounts deployed as per .\resourceDeployment\deploymentScripts\manualDeployment\provisionADGMSA.ps1, ran on the domain controllers directly
- Domain account with permissions to join machines to domain (ideally OU delegation) and be a member of DNS Admins, NOT DOMAIN ADMIN
  - Local administrator permissions to be set through group policy where appropriate
- Domain account with no domain-level permissions to be used as Active Directory breakglass account e.g. 'CONTOSO\sqlbreakglass'
- Security group that has all domain users that need sysadmin access to the database engine, these should be local domain users and not federated

# Deployment
## YAML Release Pipeline - Automated Deployment
1. Infrastructure is deployed using YAML release pipeline with two possible flows for each release stage (DEV, QUA, STG and PRD).
   - New Deployment
      - Copy Deployment Scripts to Storage Account (There is a folder for each release stage in the 'biztalk-resources' containers)
      - Generate & Store SQL VM FCI local admin credentials in centralised KeyVault
      - Get required Key Vault secrets not specific to flow (All Deployment Types) - SQL VM FCI
      - Get required Key Vault secrets specifc to flow (New Deployment)
      - Deploy Resource Groups Bicep Template, these are specifc for each release stage
        - BizTalk
      - Deploy Core Resources Bicep Template
        - Availability Sets
      - Deploy SQL VM FCI Resources Bicep Template (Assumes networking is already in place)
        - Shared Managed Disk - Cluster Witness
        - Shared Managed Disk - MSDTC
        - Shared Managed Disk - SQL Data
        - Shared Managed Disk - SQL Log
        - Shared Managed Disk - SQL Backup
        - Shared Managed Disk - SQL TempDB
        - Load Balancer (Internal)
        - Maintenance Configuration (SQL VM FCI Node A)
        - Maintenance Configuration (SQL VM FCI Node B)
        - SQL VM FCI Node A
        - SQL VM FCI Node B
        - Run preparation scripts on each SQL VM FCI virtual machine (Creates required directories and downloads required scripts)
        - Join each virtual machine to Windows Active Directory
        - Execute SQL Server setup script A on each virtual machine
        - Execute SQL Server setup script B on each virtual machine
        - Initialise data disks on SQL VM FCI Node A
   - Existing Deployment
      - Get required Key Vault secrets not specific to flow (All Deployment Types) - SQL VM FCI
      - Deploy Resource Groups Bicep Template, these are specifc for each release stage
        - BizTalk
      - Deploy Core Resources Bicep Template
        - Availability Sets
      - Deploy SQL VM FCI Resources Bicep Template (Assumes networking is already in place)
        - Availability Set
        - Shared Managed Disk - Cluster Witness
        - Shared Managed Disk - MSDTC
        - Shared Managed Disk - SQL Data
        - Shared Managed Disk - SQL Log
        - Shared Managed Disk - SQL Backup
        - Shared Managed Disk - SQL TempDB
        - Load Balancer (Internal)
        - Maintenance Configuration (SQL VM FCI Node A)
        - Maintenance Configuration (SQL VM FCI Node B)
        - SQL VM FCI Node A
        - SQL VM FCI Node B
2. Manual intervention required beyond this point  
3. Follow further steps specific to each resource type below

## SQL FCI
### Windows Server Failover Cluster Setup
1. Check to see if computer objects already exist for the WSFC Listener Name, SQL Listener Name and the MSDTC Listener Name e.g. NPDEVBZSQLWSFC, NPDEVBZSQLDB, NPDEVBZSQLMSDTC (These will be in the same Organisational Unit (OU) as the computer objects for the SQL FCI nodes)
  - If they do already exist, delete them
2. Run **Windows PowerShell** as administrator **on the primary node** with code similar to the below
    - You can get the following values from the variable group for the release stage
        - windowsServerFailoverClusterPrivateIPAddressWSFC = virtualNetworkSQLAOAGNodeASubnetPrefix
        - windowsServerFailoverClusterSubnetPrefix = virtualNetworkSQLSubnetPrefix
        - windowsServerFailoverClusterWSFCListenerName = windowsServerFailoverClusterWSFCListenerName
```
Set-Location C:\ComputerConfiguration\Scripts
.\configureSQLWSFC.ps1 `
-windowsServerFailoverClusterNodeA 'NPVMIDEVBZSQL01' `
-windowsServerFailoverClusterNodeB 'NPVMIDEVBZSQL02' `
-windowsServerFailoverClusterPrivateIPAddressWSFC '10.13.1.4' `
-windowsServerFailoverClusterSubnetPrefix '10.13.1.0/28' `
-windowsServerFailoverClusterWSFCListenerName 'NPDEVBZSQLWSFC'
```

**NB - This will take a while (10 minutes + to execute as it needs to run cluster validation tests as a prerequisite of installing SQL Server later)**

3. Login to a machine where Active Directory Users & Computers is accessible
4. Open Active Directory Users & Computers with a user that has administrative access in the OU the Cluster Name (CNO) computer object is in
5. Ensure that 'Advanced Features' is checked in the View menu
6. Right-click on the OU and select Properties
7. On the Security tab, select Advanced
8. In the Advanced Security Settings dialog box, select Add
9. Next to Principal, select Select a principal
10. In the Select User, Computer, Service Account, or Groups dialog box, select Object Types, select the Computers check box, and then select OK
11. Under Enter the object names to select, enter the name of the CNO, select Check Names, and then select OK. In response to the warning message that says that you are about to add a disabled object, select OK
12. In the Permission Entry dialog box, make sure that the Type list is set to Allow, and the Applies to list is set to This object and all descendant objects
13. Under Permissions, select the 'Create Computer objects' check box
14. Click OK
15. Login to the primary node as the same domain user used previously
16. Open Failover Cluster Manager
17. Click into Storage > Disks
18. Click Add Disk
19. Add all available disks into the cluster
20. Order by 'Disk Number'
21. Rename the disks
    - Disk Number 2 should be 'ClusterWitness'
    - Disk Number 3 should be 'MSDTC'
    - Disk Number 4 should be 'SQLData'
    - Disk Number 5 should be 'SQLLog'
    - Disk Number 6 should be 'SQLBackup'
    - Disk Number 7 should be 'SQLTempDB'
22. Go to the WSFC top level page
23. Click 'More Actions'
24. Click 'Configure Cluster Quorum Settings'
25. Click 'Next'
26. Choose 'Select the quorum witness'
27. Click 'Next'
28. Choose 'Configure a disk witness'
29. Choose 'ClusterWitness'
30. Click 'Next'
31. Click 'Next'
32. Click 'Finish'

### Configuring the Cluster Distributed Transaction Coordinator
1. Open Failover Cluster Manager on the primary node
2. Go to 'Roles'
3. Click 'SQL SERVER (MSSQLSERVER)'
4. Click 'Configure Role' in the right-hand pane
5. Click 'Next'
6. Select Distributed Transaction Coordinator (DTC)
7. Click 'Next'
8. For the name, choose the value stored in the variable windowsServerFailoverClusterMSDTCListenerName in the DevOps variable group e.g 'NPDEVBZSQLMSDTC'
9. Click 'Next'
10. Choose 'MSDTC' as the storage
11. Click 'Next'
12. Click 'Next'
13. Click 'Finish'
14. Expand the role and go to the 'Resources' tab
15. Right-Click on the 'IP Address' resource under the Server Name and go to 'Properties'
16. Change to 'Static IP Address' and enter the ip address as the value stored for the loadBalancerFrontendPrivateIpAddressMSDTC variable in the DevOps variable group
17. Click 'Apply'
18. Ensure that the role is moved to the primary node if it is not already
19. Go to 'Computer Management'
20. Go to 'Services'
21. Right-click on 'Distrubuted Transaction Coordinator' **NOT THE ONE WITH A GUID SUFFIX**
22. Click on 'Properties'
23. Change the 'Startup type' to be 'Disabled'
24. Click on Stop
25. Click 'Apply'
26. Repeat steps 19 thru 25 on the secondary node
27. On the primary node, go to start and search for and open 'Component Services'
28. Double-click on 'Computers'
29. Double-click on 'My Computer'
30. Double-click on 'Distributed Transaction Coordinator'
31. Double-click on 'Clustered DTCs'
32. Right-click on the only object
33. Click on 'Properties'
34. Enable 'Trace All Transactions'
35. Go the 'Security' tab
36. Enable 'Network DTC Access'
37. Enable 'Allow Remote Clients'
38. Enable 'Allow Inbound'
39. Enable 'Allow Outbound'
40. Change the authentication type to 'No Authentication Required'
41. Enable 'XA Transactions'
41. Click 'Apply'
42. Click 'Yes' to confirm

### Installing SQL Server on Primary Node
1. **Ensure that all WSFC cluster resources are running on the primary node: Disks, WSFC**
2. Once confirmed, open File Explorer and navigate to C:\ComputerConfiguration\Installer
3. Mount the SQL Server ISO
4. Run setup.exe
5. Click 'Installation'
6. Click 'New SQL Server failover cluster installation'
7. Ensure that the correct product key has been entered, you can get this from the DevOps variable group. Otherwise leave as the default (SQL Server Developer Edition)
8. Check 'I accept the license terms and Privacy Statement'
9. Click 'Next'
10. Ignore any warnings in the pre-flight checks
11. Click 'Next'
12. Click 'Next'
13. Check 'Database Engine Services'
14. Check 'Integration Services'
15. Click 'Next'
16. Enter the value stored in the variable windowsServerFailoverClusterSQLListenerName in the DevOps variable group e.g 'NPDEVBZSQLDB' as the 'SQL Server Network Name'
17. Click 'Next'
18. Ignore any warnings, change the 'SQL Server cluster resource group name' to be the same as entered in step 16
19. Click 'Next' - They are merely warnings rather than errors despite what the icon depicts
20. Ensure that 'SQLBackup', 'SQLData', 'SQLLog' and 'SQLTempDB' are checked
21. Click 'Next'
22. Check the checkbox to the left of 'IPv4'
23. Uncheck the checkbox 'DHCP'
24. Enter the value stored in the variable loadBalancerFrontendPrivateIpAddressSQL in the DevOps variable group
25. Click 'Next'
26. Configure the service accounts as follows
    - SQL Server Agent - DOMAIN\svcMSSQLBZA$
    - SQL Server Database Engine - DOMAIN\svcMSSQLBZDB$
    - SQL Server Integration Services 12.0 - DOMAIN\svcMSSQLBZIS$
    - SQL Server Browser - Change startup type to 'Disabled'
27. Click 'Next'
28. Change the Authentication Mode to 'Mixed Mode'
29. Retrieve the sa password from the centralised key vault named similarly to 'dcu01-dev-biztalk-sql-sa-password' and paste in both 'Enter password' and 'Confirm password'
30. Add both the AD SQL Breakglass admin and SQL Server Administrators group to be SQL Server Administrators
31. Go to the 'Data Directories' tab
32. Pull up file explorer to the side and navigate to 'This PC'
33. Change the data root directory to be the same drive letter as SQLData
34. Change the drive letter of the 'User database log directory' to match that of the SQLLog drive
35. Change the drive letter of both the 'Temp DB directory' and 'Temp DB log directory' to match that of the SQLTempDB drive
36. Change the drive letter of the 'Backup directory' to match that of the SQLBackup drive
37. Click 'Next'
38. Click 'Install'
39. Check to see all features have been installed and click 'Close'
40. Open 'SQL Server 2014 Configuration Manager'
41. Go to 'SQL Server Services'
42. Right-Click on 'SQL Full-text Filter Daemon Launcher' and click 'Properties'
43. Go to the 'Service' tab
44. Change the 'Start Mode' to 'Disabled'
45. Go back to the 'Log On' tab
46. Click 'Stop'
47. Click 'Apply

### Configure Restore Directory, Backup and Restore SMB Shares
1. On the primary node, open Windows PowerShell as an adminstrator
2. Run code similar to the below
```
Set-Location C:\ComputerConfiguration\Scripts
.\configureSQLBackupRestoreSMB.ps1 `
-sqlServerAdministratorGroupName 'DOMAIN\SQL Server Administrators' `
-sqlServerDatabaseEngineServiceAccount 'DOMAIN\svcMSSQLBZDB$'
```
3. Go to file explorer to find out the drive letter of the SQLBackup drive
4. Enter only the letter prompted and press enter

### Configure IP Address Cluster Resources for SQL & MSDTC Listeners
1. Open Windows PowerShell as an administrator on the primary node
2. Run code similar to the below
```
Set-Location C:\ComputerConfiguration\Scripts
.\configureSQLMSDTCIPAddressClusterResource.ps1 `
-windowsServerFailoverClusterMSDTCListenerName 'NPDEVBZSQLMSDTC' `
-windowsServerFailoverClusterSQLListenerName 'NPDEVBZSQLDB'
```
3. After server restart log back into the primary node
4. Ensure that the cluster and both roles have the primary node as the owner node

### SQL Server Integration Services Catalog Creation
1. Login to both the primary node as the SQL Install domain user used previously to join the machine to the domain
2. Open SQL Server Management Studio (SSMS) and connect to the database engine on the primary node only using Windows Authentication
3. Open the centralised key vault locally and find the secret named in the format similar to this example for the release stage (dcu01-dev-sql-ssiscatalog-master-key) and copy to clipboard
4. Right-click on 'Integration Services Catalogs' in the object explorer
5. Select 'Create Catalog...'
6. Ensure that both 'Enable CLR Integration' and 'Enable automatic execution of Integration Services stored procedure at SQL Server statup.' are selected
7. Paste key vault secret in the 'Password' and 'Retype Password' fields and click 'OK'
8. Close SSMS

### Configure SQL Instance
1. Open Windows PowerShell as an administrator on the primary node
2. Run code similar to the below

You will be able get all credential information from the centralised Azure KeyVault with secrets using the example naming convention below
- sqlServerBreakGlassAdminPassword - dcu01-dev-biztalk-sql-breakglass-password
- sqlServerBreakGlassAdminUsername - dcu01-dev-biztalk-sql-breakglass-username
- sqlServerDevOpsDeployUserPassword - dcu01-dev-biztalk-sql-devopsdeployuser-password
- sqlServerDevOpsDeployUserUsername - dcu01-dev-biztalk-sql-devopsdeployuser-username
- sqlServerSAAccountPassword - dcu01-dev-biztalk-sql-sa-password
```
Set-Location C:\ComputerConfiguration\Scripts
.\configureSQLServer.ps1 `
-activeDirectoryDomainFullyQualifiedName 'corp.dcallpoc.dc' `
-activeDirectoryDomainNETBIOSName 'DOMAIN' `
-sqlServerBreakGlassAdminPassword '' `
-sqlServerBreakGlassAdminUsername '' `
-sqlServerDevOpsDeployUserPassword '' `
-sqlServerDevOpsDeployUserUsername '' `
-sqlServerSAAccountPassword '' `
-windowsServerFailoverClusterSQLListenerName ''
```

### Installing SQL Server on Secondary Node
1. **Ensure that all WSFC cluster resources are running on the primary node: Disks, WSFC**
2. Once confirmed, open File Explorer and navigate to C:\ComputerConfiguration\Installer
3. Mount the SQL Server ISO
4. Run setup.exe
5. Click 'Installation'
6. Click 'Add node to a SQL Server failover cluster'
7. Ensure that the correct product key has been entered, you can get this from the DevOps variable group. Otherwise leave as the default (SQL Server Developer Edition)
8. Check 'I accept the license terms and Privacy Statement'
9. Click 'Next'
10. Ignore any warnings in the pre-flight checks
11. Click 'Next'
12. Click 'Next'
13. Configure the service accounts as follows
    - SQL Server Integration Services 12.0 - DOMAIN\svcMSSQLBZIS$
    - SQL Server Browser - Change startup type to 'Disabled'
14. Click 'Install'
15. Check to see all features have been installed and click 'Close'
16. Open 'SQL Server 2014 Configuration Manager'
17. Go to 'SQL Server Services'
18. Right-Click on 'SQL Full-text Filter Daemon Launcher' and click 'Properties'
19. Go to the 'Service' tab
20. Change the 'Start Mode' to 'Disabled'
21. Go back to the 'Log On' tab
22. Click 'Stop'
23. Click 'Apply'