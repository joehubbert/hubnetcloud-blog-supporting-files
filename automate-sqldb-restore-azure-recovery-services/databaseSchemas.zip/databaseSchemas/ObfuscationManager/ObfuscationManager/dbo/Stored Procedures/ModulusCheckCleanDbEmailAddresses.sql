﻿/*
Clean the email addresses by replacing originals with fictional email address
*/
create procedure ModulusCheckCleanDbEmailAddresses @seedA int, @seedB int
as
	set nocount on;
	-- todo: 
	-- write some sql to create a share
	-- consider using some awesome SQL
return 0