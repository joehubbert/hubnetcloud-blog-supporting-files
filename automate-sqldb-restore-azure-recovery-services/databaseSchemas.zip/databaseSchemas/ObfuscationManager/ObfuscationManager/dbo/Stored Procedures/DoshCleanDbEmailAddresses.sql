﻿/*
Clean the email addresses by replacing originals with fictional email address
*/
create procedure DoshCleanDbEmailAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Dosh].[dbo].[Users] SET [EmailAddress] = [ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [EmailAddress]);
return 0