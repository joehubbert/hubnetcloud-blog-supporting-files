﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure DirectDebitsCleanBankAccountHolders @seedA int, @seedB int
as
	set nocount on;
	--[BankAccountHolders];
	-- the work table
	select 
	 [BankAccountHolderId]
	,[ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [EmailAddress]) [EmailAddress]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FirstName]) [FirstName]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [OtherNames]) [OtherNames]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Surname]) [Surname]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [County]) [County]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Line1]) [Line1]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Line2]) [Line2]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PostCode]) [PostCode]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [TelephoneNumber]) [TelephoneNumber]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Title]) [Title]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Town]) [Town]
	into [DirectDebits].[dbo].[BankAccountHolders_WORK] 
	from [DirectDebits].[dbo].[BankAccountHolders];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [DirectDebits]; create clustered index [CIX_BankAccountHolders_WORK(BankAccountHolderId)] on BankAccountHolders_WORK(BankAccountHolderId);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @BankAccountHolders table(BankAccountHolderId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [DirectDebits].[dbo].[BankAccountHolders] 
		SET 
		 [EmailAddress] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[EmailAddress]
		,[FirstName] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[FirstName]
		,[OtherNames] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[OtherNames]
		,[Surname] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[Surname]
		,[County] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[County]
		,[Line1] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[Line1]
		,[Line2] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[Line2]
		,[PostCode] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[PostCode]
		,[TelephoneNumber] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[TelephoneNumber]
		,[Title] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[Title]
		,[Town] = [DirectDebits].[dbo].[BankAccountHolders_WORK].[Town]
		output INSERTED.BankAccountHolderId into @BankAccountHolders
		from [DirectDebits].[dbo].[BankAccountHolders_WORK]
		where [DirectDebits].[dbo].[BankAccountHolders_WORK].[BankAccountHolderId] = [DirectDebits].[dbo].[BankAccountHolders].[BankAccountHolderId];
		--remove the records already updated
		delete from [DirectDebits].[dbo].[BankAccountHolders_WORK] where BankAccountHolderId in (select BankAccountHolderId from @BankAccountHolders);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @BankAccountHolders;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [DirectDebits].[dbo].[BankAccountHolders_WORK];
return 0