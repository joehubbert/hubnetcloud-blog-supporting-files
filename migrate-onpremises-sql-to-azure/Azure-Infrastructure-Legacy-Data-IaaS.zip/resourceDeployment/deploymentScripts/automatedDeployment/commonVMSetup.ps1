param
(
    [Parameter(Mandatory)][string]$deploymentSoftwarePackageStorageBlobPrefix
)

#Set Common Variables
$computerConfigurationInstallerDirectory = 'C:\ComputerConfiguration\Installer'
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$diskFormat = 'NTFS'
$diskPartitionStyle = 'GPT'
$errorActionPreference = 'Stop'
$firewallRuleDisplayGroup = 'Allpay Custom Windows Firewall Rules'
$progressPreference = 'SilentlyContinue'
$scriptLogFileName = 'commonVMSetup-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"
$sqlBackupDiskName = 'SQLBackup'
$sqlDataDiskName = 'SQLData'
$sqlLogDiskName = 'SQLLog'
$sqlTempDBDiskName = 'SQLTempDB'
$windowsFeaturesToInstall = @('File-Services', 'FS-FileServer', 'RSAT-AD-PowerShell')

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Install Windows Features
try
{
    Import-Module ServerManager
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to import the PowerShell module 'ServerManager' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

foreach($feature in $windowsFeaturesToInstall)
{
    try
    {
        Install-WindowsFeature $feature
        $currentTimestamp = Get-Date
        $outputText = "The Windows Feature $feature has been successfully installed on $env:computername at $currentTimestamp."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"        
    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $currentTimestamp = Get-Date
        $outputText = "An error occured when installing the Windows Feature $feature on $env:computername at $currentTimestamp with the following error '$errorMessage'."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
}

#Setup Data Disks
try
{
    Initialize-Disk -Number 2 -PartitionStyle $diskPartitionStyle -PassThru | `
    New-Volume -FileSystem $diskFormat -DriveLetter F -FriendlyName $sqlDataDiskName
    $currentTimestamp = Get-Date
    $outputText = "The data disk $sqlDataDiskName has been successfully initialised on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to initialise the data disk $sqlDataDiskName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Initialize-Disk -Number 3 -PartitionStyle $diskPartitionStyle -PassThru | `
    New-Volume -FileSystem $diskFormat -DriveLetter G -FriendlyName $sqlLogDiskName
    $currentTimestamp = Get-Date
    $outputText = "The data disk $sqlLogDiskName has been successfully initialised on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to initialise the data disk $sqlLogDiskName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Initialize-Disk -Number 4 -PartitionStyle $diskPartitionStyle -PassThru | `
    New-Volume -FileSystem $diskFormat -DriveLetter H -FriendlyName $sqlBackupDiskName
    $currentTimestamp = Get-Date
    $outputText = "The data disk $sqlBackupDiskName has been successfully initialised on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to initialise the data disk $sqlBackupDiskName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Initialize-Disk -Number 5 -PartitionStyle $diskPartitionStyle -PassThru | `
    New-Volume -FileSystem $diskFormat -DriveLetter I -FriendlyName $sqlTempDBDiskName
    $currentTimestamp = Get-Date
    $outputText = "The data disk $sqlTempDBDiskName has been successfully initialised on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to initialise the data disk $sqlTempDBDiskName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure Windows Firewall
try
{
    Enable-NetFirewallRule -DisplayName 'Core Networking Diagnostics - ICMP Echo Request (ICMPv4-In)'
    $currentTimestamp = Get-Date
    $outputText = "The IpV4 Ping Reply Windows Firewall Rule has been successfully enabled on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to enable the IpV4 Ping Reply Windows Firewall Rule on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    New-NetFirewallRule `
    -Action Allow `
    -Description 'Allows inbound connectivity for clients to connect to SQL Server Database Engine for the MSSQLSERVER instance.' `
    -Direction Inbound `
    -DisplayName 'SQL Server - Allow Inbound MSSQLDB Engine' `
    -Group $firewallRuleDisplayGroup `
    -LocalPort 1433 `
    -Name 'SQL Server - Allow Inbound MSSQLDB Engine' `
    -Profile "Domain, Private" `
    -Protocol TCP
    $currentTimestamp = Get-Date
    $outputText = "The MSSQL Database Engine Windows Firewall Rule has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the MSSQL Database Engine Windows Firewall Rule on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    netsh int ipv4 add excludedportrange tcp startport=1433 numberofports=1 store=persistent
    $currentTimestamp = Get-Date
    $outputText = "The port 1433 has been successfully excluded from the Windows Dynamic Port Range on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when exluding the port 1433 from the Windows Dynamic Port Range on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Download Software Packages
try
{
    Invoke-WebRequest `
    -Uri "$deploymentSoftwarePackageStorageBlobPrefix/PowerShell-7.2.10-win-x64.msi" `
    -OutFile "$computerConfigurationInstallerDirectory\PowerShell-7.2.10-win-x64.msi"
    $currentTimestamp = Get-Date
    $outputText = "The PowerShell installer has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the PowerShell installer to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest `
    -Uri "$deploymentSoftwarePackageStorageBlobPrefix/en_sql_server_2019_x64_dvd.iso" `
    -OutFile "$computerConfigurationInstallerDirectory\en_sql_server_2019_x64_dvd.iso"
    $currentTimestamp = Get-Date
    $outputText = "The SQL Server Setup ISO file has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"

}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the SQL Server Setup ISO file to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest `
    -Uri "$deploymentSoftwarePackageStorageBlobPrefix/SSMS-Setup-ENU-18-12-1.exe" `
    -OutFile "$computerConfigurationInstallerDirectory\SSMS-Setup-ENU-18-12-1.exe"
    $currentTimestamp = Get-Date
    $outputText = "The SQL Server Management Studio Installer has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the SQL Server Management Studio Installer to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest `
    -Uri "https://go.microsoft.com/fwlink/?linkid=2216182" `
    -OutFile "$computerConfigurationInstallerDirectory\AzureStorageExplorer.exe"
    $currentTimestamp = Get-Date
    $outputText = "The Azure Storage Explorer Installer has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the Azure Storage Explorer Installer to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest -Uri `
    "$deploymentSoftwarePackageStorageBlobPrefix/SysInternalsSuite.zip" `
    -OutFile "$computerConfigurationInstallerDirectory\SysInternalsSuite.zip"
    $currentTimestamp = Get-Date
    $outputText = "The SysInternalsSuite has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the SysInternals Suite Archive to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest `
    -Uri "$deploymentSoftwarePackageStorageBlobPrefix/IISCryptoCli.exe" `
    -OutFile "C:\ComputerConfiguration\Installer\IISCryptoCli.exe"
    $currentTimestamp = Get-Date
    $outputText = "The IIS Crypto CLI tool has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the IIS Crypto CLI tool to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest `
    -Uri "$deploymentSoftwarePackageStorageBlobPrefix/SQLServer2019-KB5023049-x64.exe" `
    -OutFile "C:\ComputerConfiguration\Installer\SQLServer2019-KB5023049-x64.exe"
    $currentTimestamp = Get-Date
    $outputText = "The SQL Server 2019 CU19 Installer has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the SQL Server 2019 CU19 Installer to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Install Software Packages
Set-Location $computerConfigurationInstallerDirectory

try
{
    .\IISCryptoCli.exe /backup CryptoSettingsBackup.reg /template best
    $currentTimestamp = Get-Date
    $outputText = "IISCryptoCli has successfully configured Crypto to best practices on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when configuring Crypto on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Expand-Archive -LiteralPath "$computerConfigurationInstallerDirectory\SysInternalsSuite.zip" -DestinationPath 'C:\SysInternalsSuite'
    $currentTimestamp = Get-Date
    $outputText = "The SysInternalsSuite has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when expanding the SysInternals Suite Archive on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    msiexec.exe /package PowerShell-7.2.10-win-x64.msi /quiet ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=1 ADD_FILE_CONTEXT_MENU_RUNPOWERSHELL=1 ENABLE_PSREMOTING=0 REGISTER_MANIFEST=1 USE_MU=1 ENABLE_MU=1 ADD_PATH=1
    Wait-Process 'msiexec'
    $currentTimestamp = Get-Date
    $outputText = "PowerShell has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing PowerShell on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    .\SSMS-Setup-ENU-18-12-1.exe /Install /Passive
    Wait-Process 'SSMS-Setup-ENU-18-12-1'
    $currentTimestamp = Get-Date
    $outputText = "SQL Server Management Studio has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing SQL Server Management Studio on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    .\AzureStorageExplorer.exe /VerySilent /NoRestart /AllUsers
    Wait-Process 'AzureStorageExplorer'
    $currentTimestamp = Get-Date
    $outputText = "Azure Storage Explorer has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing Azure Storage Explorer on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Install Nuget Package Provider
try
{
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
    $currentTimestamp = Get-Date
    $outputText = "The Nuget package provider has been installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing the Nuget package provider on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure PowerShell Gallery Trust Status
try
{
    Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
    $currentTimestamp = Get-Date
    $outputText = "PSGallery has been set to be a trusted package repository on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing the Nuget package provider on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Install Common PowerShell Modules
try
{
    Install-Module SQLServer -Force
    $currentTimestamp = Get-Date
    $outputText = "The 'SqlServer' PowerShell module has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing the PowerShell module 'SqlServer' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Set Locale of Computer to en-GB
try
{
    & $env:SystemRoot\System32\control.exe "intl.cpl,,/f:`"UKRegion.xml`""
    Set-WinSystemLocale en-GB
    Set-WinHomeLocation -GeoId 242
    Set-WinUserLanguageList en-GB -Force
    $currentTimestamp = Get-Date
    $outputText = "The localisation has been to set to en-GB on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the localisation to en-GB on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

$currentTimestamp = Get-Date
$outputText = "commonVMSetup.ps1 has completed execution on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer