﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure DirectDebitsCleanImportedInstructions_BulkAmendmentInstruction @seedA int, @seedB int
as
	set nocount on;
	--[ImportedInstructions_BulkAmendmentInstruction];
	-- the work table
	select 
	 [ImportedInstructionId]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine1]) [AddressLine1]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PostCode]) [PostCode]
	into [DirectDebits].[dbo].[ImportedInstructions_BulkAmendmentInstruction_WORK] 
	from [DirectDebits].[dbo].[ImportedInstructions_BulkAmendmentInstruction];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [DirectDebits]; create clustered index [CIX_ImportedInstructions_BulkAmendmentInstruction_WORK(ImportedInstructionId)] on ImportedInstructions_BulkAmendmentInstruction_WORK(ImportedInstructionId);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @ImportedInstructions_BulkAmendmentInstruction table(ImportedInstructionId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [DirectDebits].[dbo].[ImportedInstructions_BulkAmendmentInstruction] 
		SET 
		 [AddressLine1] = [DirectDebits].[dbo].[ImportedInstructions_BulkAmendmentInstruction_WORK].[AddressLine1]
		,[PostCode] = [DirectDebits].[dbo].[ImportedInstructions_BulkAmendmentInstruction_WORK].[PostCode]
		output INSERTED.ImportedInstructionId into @ImportedInstructions_BulkAmendmentInstruction
		from [DirectDebits].[dbo].[ImportedInstructions_BulkAmendmentInstruction_WORK]
		where [DirectDebits].[dbo].[ImportedInstructions_BulkAmendmentInstruction_WORK].[ImportedInstructionId] = [DirectDebits].[dbo].[ImportedInstructions_BulkAmendmentInstruction].[ImportedInstructionId];
		--remove the records already updated
		delete from [DirectDebits].[dbo].[ImportedInstructions_BulkAmendmentInstruction_WORK] where ImportedInstructionId in (select ImportedInstructionId from @ImportedInstructions_BulkAmendmentInstruction);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @ImportedInstructions_BulkAmendmentInstruction;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [DirectDebits].[dbo].[ImportedInstructions_BulkAmendmentInstruction_WORK];
return 0