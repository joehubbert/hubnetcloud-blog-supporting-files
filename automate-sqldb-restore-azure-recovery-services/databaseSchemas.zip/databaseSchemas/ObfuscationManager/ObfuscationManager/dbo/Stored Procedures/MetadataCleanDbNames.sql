﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure MetadataCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	-- todo: 
	-- write some sql to create a share
	-- consider using some awesome SQL
return 0