﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure DirectDebitsCleanAccountHolderDetails2of2 @seedA int, @seedB int
as
	set nocount on;
	--[AccountHolderDetails];
	-- the work table
	-- was performed in SP: DirectDebitsCleanAccountHolderDetails1of2
	--some local variables
	declare @AccountHolderDetails table(AccountHolderDetailsId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [DirectDebits].[dbo].[AccountHolderDetails] 
		SET 
		 [Surname] = [DirectDebits].[dbo].[AccountHolderDetails_WORK].[Surname]
		,[AddressLine1] = [DirectDebits].[dbo].[AccountHolderDetails_WORK].[AddressLine1]
		,[AddressLine2] = [DirectDebits].[dbo].[AccountHolderDetails_WORK].[AddressLine2]
		,[AddressLine3] = [DirectDebits].[dbo].[AccountHolderDetails_WORK].[AddressLine3]
		,[AddressLine4] = [DirectDebits].[dbo].[AccountHolderDetails_WORK].[AddressLine4]
		,[PostCode] = [DirectDebits].[dbo].[AccountHolderDetails_WORK].[PostCode]
		,[TitileInitials] = [DirectDebits].[dbo].[AccountHolderDetails_WORK].[TitileInitials]
		output INSERTED.AccountHolderDetailsId into @AccountHolderDetails
		from [DirectDebits].[dbo].[AccountHolderDetails_WORK]
		where [DirectDebits].[dbo].[AccountHolderDetails_WORK].[AccountHolderDetailsId] = [DirectDebits].[dbo].[AccountHolderDetails].[AccountHolderDetailsId];
		--remove the records already updated
		delete from [DirectDebits].[dbo].[AccountHolderDetails_WORK] where AccountHolderDetailsId in (select AccountHolderDetailsId from @AccountHolderDetails);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @AccountHolderDetails;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [DirectDebits].[dbo].[AccountHolderDetails_WORK];
return 0