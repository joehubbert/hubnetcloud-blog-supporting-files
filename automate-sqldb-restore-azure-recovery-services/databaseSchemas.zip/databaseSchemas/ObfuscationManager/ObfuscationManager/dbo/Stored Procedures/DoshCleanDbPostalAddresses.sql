﻿/*
Clean the postal addresses by replacing originals with fictional postal address
*/
create procedure DoshCleanDbPostalAddresses @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Dosh].[dbo].[Users] SET [AddressLine1] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine1]);
	UPDATE [Dosh].[dbo].[Users] SET [AddressLine2] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine2]);
	UPDATE [Dosh].[dbo].[Users] SET [AddressLine3] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AddressLine3]);
	UPDATE [Dosh].[dbo].[Users] SET [ContactNumber] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [ContactNumber]);
	UPDATE [Dosh].[dbo].[Users] SET [Postcode] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Postcode]);
return 0