param
(
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterMSDTCListenerName,
    [Parameter(Mandatory)][string]$windowsServerFailoverClusterSQLListenerName
)

$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$msdtcIPAddressClusterResourceNewName = "$windowsServerFailoverClusterMSDTCListenerName - IP Address"
$msdtcIPAddressClusterResourceOldName = (Get-ClusterResource | Where-Object {$_.OwnerGroup -eq $windowsServerFailoverClusterMSDTCListenerName} | Where-Object {$_.ResourceType -eq 'IP Address'}).Name
$progressPreference = 'SilentlyContinue'
$scriptLogFileName = 'configureSQLMSDTCIPAddressClusterResource-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"
$sqlIPAddressClusterResourceNewName = "$windowsServerFailoverClusterSQLListenerName - IP Address"
$sqlIPAddressClusterResourceOldName = (Get-ClusterResource | Where-Object {$_.OwnerGroup -eq $windowsServerFailoverClusterSQLListenerName} | Where-Object {$_.ResourceType -eq 'IP Address'}).Name

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Rename MSDTC Cluster IP Address Resource
try
{
    (Get-ClusterResource -Name $msdtcIPAddressClusterResourceOldName).Name = $msdtcIPAddressClusterResourceNewName
    $currentTimestamp = Get-Date
    $outputText = "$msdtcIPAddressClusterResourceOldName has been renamed to $msdtcIPAddressClusterResourceNewName on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when renaming $msdtcIPAddressClusterResourceOldName to $msdtcIPAddressClusterResourceNewName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Rename SQL Cluster IP Address Resource
try
{
    (Get-ClusterResource -Name $sqlIPAddressClusterResourceOldName).Name = $sqlIPAddressClusterResourceNewName
    $currentTimestamp = Get-Date
    $outputText = "$sqlIPAddressClusterResourceOldName has been renamed to $sqlIPAddressClusterResourceNewName on $env:computername at $currentTimestamp"
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when renaming $sqlIPAddressClusterResourceOldName to $sqlIPAddressClusterResourceNewName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Update Probe Port - MSDTC Cluster IP Address Resource
try
{
    Get-ClusterResource -Name $msdtcIPAddressClusterResourceNewName | Set-ClusterParameter -Name ProbePort -Value 58888
    $currentTimestamp = Get-Date
    $outputText = "The IP Address probe port has been set to 58888 on $windowsServerFailoverClusterMSDTCListenerName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the probe port to 58888 on $windowsServerFailoverClusterMSDTCListenerName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Update Probe Port - SQL Cluster IP Address Resource
try
{
    Get-ClusterResource -Name $sqlIPAddressClusterResourceNewName | Set-ClusterParameter -Name ProbePort -Value 59999
    $currentTimestamp = Get-Date
    $outputText = "The IP Address probe port has been set to 59999 on $sqlIPAddressClusterResourceNewName at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the probe port to 59999 on $sqlIPAddressClusterResourceNewName at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

$currentTimestamp = Get-Date
$outputText = "Execution of configureSQLMSDTCIPAddressClusterResource.ps1 successfully completed on $env:computername at $currentTimestamp. A server reboot will be triggered immediately."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer