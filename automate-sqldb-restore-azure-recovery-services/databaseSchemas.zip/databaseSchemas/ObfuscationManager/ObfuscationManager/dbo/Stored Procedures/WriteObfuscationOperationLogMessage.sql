﻿CREATE PROCEDURE [dbo].[WriteObfuscationOperationLogMessage]
	@correlationId UNIQUEIDENTIFIER,
	@databaseName NVARCHAR(100),
	@operationType NVARCHAR(256),
	@operationMessage NVARCHAR(MAX),
	@operationOutcome NVARCHAR(10)
AS

INSERT INTO [dbo].[ObfuscationLog] ([Correlation_Id], [Database_Name], [Operation_Type], [Operation_Message], [Operation_Outcome])
VALUES (@correlationId, @databaseName, @operationType, @operationMessage, @operationOutcome)