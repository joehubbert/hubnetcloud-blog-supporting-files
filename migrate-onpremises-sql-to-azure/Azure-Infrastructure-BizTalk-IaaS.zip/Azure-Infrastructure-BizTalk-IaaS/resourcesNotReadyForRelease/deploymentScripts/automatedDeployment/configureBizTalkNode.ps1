param 
(
    [Parameter(Mandatory)][string]$deploymentSoftwarePackageStorageBlobPrefix,
    [Parameter(Mandatory)][string]$environmentDescription,
    [Parameter(Mandatory)][string]$primaryIPAddress,
    [Parameter(Mandatory)][string]$virtualNetworkDefaultGateway,
    [Parameter(Mandatory)][string]$virtualNetworkDNSServerAIPAddress,
    [Parameter(Mandatory)][string]$virtualNetworkDNSServerBIPAddress,
    [Parameter(Mandatory)][int]$virtualNetworkPrefixLength,
    [Parameter(Mandatory)][string]$virtualNetworkSubnetMask
)

$bizTalkInstallDirectory = 'C:\Program Files (x86)\Microsoft BizTalk Server'
$computerConfigurationInstallerDirectory = 'C:\ComputerConfiguration\Installer'
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$progressPreference = 'SilentlyContinue'
$scriptLogFileName = 'configureBizTalkNode-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptLogFileName"
$webAppPoolName = "BizTalkAppPool"
$windowsFeaturesToInstall = @(
'File-Services',
'FS-FileServer',
'NET-WCF-HTTP-Activation45',
'RDC',
'RSAT-AD-PowerShell',
'RSAT-SNMP',
'SNMP-Service',
'SNMP-WMI-Provider',
'Telnet-Client',
'WAS',
'WAS-Process-Model',
'WAS-Config-APIs',
'Web-Basic-Auth',
'Web-CGI',
'Web-Digest-Auth',
'Web-Dyn-Compression',
'Web-Http-Redirect',
'Web-Http-Tracing',
'Web-Includes',
'Web-Lgcy-Mgmt-Console',
'Web-Lgcy-Scripting',
'Web-Log-Libraries',
'Web-Metabase',
'Web-Mgmt-Compat',
'Web-Mgmt-Service',
'Web-Mgmt-Tools',
'Web-ODBC-Logging',
'Web-Request-Monitor',
'Web-Scripting-Tools',
'Web-Server',
'Web-WebSockets',
'Web-Windows-Auth',
'Web-WMI')

#Create Script Log File
try
{
    $currentTimestamp = Get-Date
    New-Item -Path $computerConfigurationLogDirectory -Name $scriptLogFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force
}
catch
{
    Write-Host "Unable to create log file $scriptLogPath."
}

#Install Windows Features
try
{
    Import-Module ServerManager
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to import the PowerShell module 'ServerManager' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

foreach($feature in $windowsFeaturesToInstall)
{
    try
    {
        Install-WindowsFeature $feature
        $currentTimestamp = Get-Date
        $outputText = "The Windows Feature $feature has been successfully installed on $env:computername at $currentTimestamp."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"        
    }
    catch
    {
        $currentTimestamp = Get-Date
        $outputText = "An error occured when installing the Windows Feature $feature on $env:computername at $currentTimestamp with the following error '$errorMessage'."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
}

#Set static IP Address
try
{
    netsh interface ip set address name='Ethernet' static $primaryIPAddress $virtualNetworkSubnetMask $virtualNetworkDefaultGateway
    Set-DnsClientServerAddress -InterfaceAlias 'Ethernet' -ServerAddresses $virtualNetworkDNSServerAIPAddress, $virtualNetworkDNSServerBIPAddress
    $currentTimestamp = Get-Date
    $outputText = "The primary IP address has been statically set to $primaryIPAddress on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the static IP Address on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Enable Network DTC Access
try
{
    Import-Module -Name MsDtc    
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to import the PowerShell module 'MsDtc' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Set-DtcNetworkSetting `
    -DtcName 'Local' `
    -AuthenticationLevel 'NoAuth' `
    -InboundTransactionsEnabled $true `
    -OutboundTransactionsEnabled $true `
    -RemoteClientAccessEnabled $true `
    -RemoteAdministrationAccessEnabled $true `
    -XATransactionsEnabled $true `
    -LUTransactionsEnabled $true `
    -Confirm:$false
    Get-Service -Name MsDtc | Restart-Service
    $currentTimestamp = Get-Date
    $outputText = "Network DTC Access has been enabled on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to enable Network DTC Access on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create BizTalk App Pool
try
{
    Import-Module -Name WebAdministration
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to import the PowerShell module 'WebAdministration' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    New-WebAppPool -Name $webAppPoolName -Force
    $currentTimestamp = Get-Date
    $outputText = "The web app pool $webAppPoolName has been created on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to create the web app pool $webAppPoolName on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Remove DefaultAppPool
try
{
    Remove-WebAppPool -Name 'DefaultAppPool'
    $currentTimestamp = Get-Date
    $outputText = "The web app pool 'DefaultAppPool' has been removed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when removing the web app pool 'DefaultAppPool' on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure IIS App Pool to run in 32-bit mode
try
{
    Set-Location 'C:\Windows\System32\inetsrv'
    .\appcmd set apppool /apppool.name:$webAppPoolName /enable32BitAppOnWin64:true
    $currentTimestamp = Get-Date
    $outputText = "The web app pool $webAppPoolName has been set to run in 32 bit mode on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when configuring $webAppPoolName to run in 32-bit mode on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Download Software Packages
try
{
    if($environmentDescription -eq 'NonProd')
    {
        $bizTalkInstallPath = "$computerConfigurationInstallerDirectory\en_biztalk_server_2020_developer_edition_x64.iso"

        Invoke-WebRequest `
        -Uri "$deploymentSoftwarePackageStorageBlobPrefix/biztalk-2020/en_biztalk_server_2020_developer_edition_x64.iso" `
        -OutFile $bizTalkInstallPath
        $currentTimestamp = Get-Date
        $outputText = "The BizTalk Developer Edition ISO file has been successfully downloaded to $env:computername at $currentTimestamp."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
    elseif($environmentDescription -eq 'Prod')
    {
        $bizTalkInstallPath = "$computerConfigurationInstallerDirectory\en_biztalk_server_2020_enterprise_edition_x64.iso"

        Invoke-WebRequest `
        -Uri "$deploymentSoftwarePackageStorageBlobPrefix/biztalk-2020/en_biztalk_server_2020_enterprise_edition_x64.iso" `
        -OutFile $bizTalkInstallPath
        $currentTimestamp = Get-Date
        $outputText = "The BizTalk Enterprise Edition ISO file has been successfully downloaded to $env:computername at $currentTimestamp."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
    else 
    {
        $currentTimestamp = Get-Date
        $outputText = "Invalid environmentDescription parsed. $environmentDescription was parsed. Only 'NonProd' and 'Prod' is accepted."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the BizTalk ISO file to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest `
    -Uri "$deploymentSoftwarePackageStorageBlobPrefix/PowerShell-7.2.10-win-x64.msi" `
    -OutFile "C:\ComputerConfiguration\Installer\PowerShell-7.2.10-win-x64.msi"
    $currentTimestamp = Get-Date
    $outputText = "The PowerShell installer has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the PowerShell installer to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest `
    -Uri "$deploymentSoftwarePackageStorageBlobPrefix/msoledbsql.msi" `
    -OutFile "$computerConfigurationInstallerDirectory\msoledbsql.msi"
    $currentTimestamp = Get-Date
    $outputText = "The MSSQL OLEDB Driver (x64) has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the MSSQL OLEDB Driver (x64) installer to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest -Uri `
    "$deploymentSoftwarePackageStorageBlobPrefix/SysInternalsSuite.zip" `
    -OutFile "C:\ComputerConfiguration\Installer\SysInternalsSuite.zip"
    $currentTimestamp = Get-Date
    $outputText = "The SysInternalsSuite has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the SysInternals Suite Archive to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest `
    -Uri "$deploymentSoftwarePackageStorageBlobPrefix/VC_redist.x86.exe" `
    -OutFile "$computerConfigurationInstallerDirectory\VC_redist.x86.exe"
    $currentTimestamp = Get-Date
    $outputText = "The Visual C++ 2015-2019 redistributable package (x86) has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the Visual C++ 2015-2019 redistributable package (x86) installer to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    Invoke-WebRequest `
    -Uri "$deploymentSoftwarePackageStorageBlobPrefix/VC_redist.x64.exe" `
    -OutFile "$computerConfigurationInstallerDirectory\VC_redist.x64.exe"
    $currentTimestamp = Get-Date
    $outputText = "The Visual C++ 2015-2019 redistributable package (x64) has been successfully downloaded to $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when downloading the Visual C++ 2015-2019 redistributable package (x64) installer to $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Install Software Packages
try
{
    Expand-Archive -LiteralPath "$computerConfigurationInstallerDirectory\SysInternalsSuite.zip" -DestinationPath 'C:\SysInternalsSuite'
    $currentTimestamp = Get-Date
    $outputText = "The SysInternalsSuite has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when expanding the SysInternals Suite Archive on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

Set-Location $computerConfigurationInstallerDirectory
try
{
    msiexec.exe /package PowerShell-7.2.10-win-x64.msi /quiet ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=1 ADD_FILE_CONTEXT_MENU_RUNPOWERSHELL=1 ENABLE_PSREMOTING=0 REGISTER_MANIFEST=1 USE_MU=1 ENABLE_MU=1 ADD_PATH=1
    Wait-Process 'msiexec'
    $currentTimestamp = Get-Date
    $outputText = "PowerShell has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing PowerShell on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    .\VC_redist.x86.exe /Install /quiet /norestart
    Wait-Process 'VC_redist.x86'
    $currentTimestamp = Get-Date
    $outputText = "The Visual C++ 2015-2019 redistributable package (x86) has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing the Visual C++ 2015-2019 redistributable package (x86) on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    .\VC_redist.x64.exe /Install /quiet /norestart
    Wait-Process 'VC_redist.x64'
    $currentTimestamp = Get-Date
    $outputText = "The Visual C++ 2015-2019 redistributable package (x64) has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
    }
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing the Visual C++ 2015-2019 redistributable package (x64) on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    msiexec.exe /package msoledbsql.msi /quiet IACCEPTMSOLEDBSQLLICENSETERMS=YES
    Wait-Process 'msiexec'
    $currentTimestamp = Get-Date
    $outputText = "The MSSQL OLEDB Driver (x64) has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing the MSSQL OLEDB Driver (x64) driver on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    New-Item -Path $bizTalkInstallDirectory -ItemType Directory
    $currentTimestamp = Get-Date
    $outputText = "The BizTalk installation directory $bizTalkInstallDirectory has been successfully created on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"    
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when creating the BizTalk installation directory $bizTalkInstallDirectory on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    $diskMount = (Mount-DiskImage -ImagePath $bizTalkInstallPath)
    Set-Location ((Get-DiskImage -DevicePath $diskMount.DevicePath | Get-Volume).DriveLetter + ':\BizTalk Server')
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when trying to mount the BizTalk Server ISO file on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

try
{
    .\Setup.exe `
    /QUIET `
    /ADDLOCAL AdditionalApps,AdminAndMonitoring,AdminTools,BAMEVENTAPI,BAMPortal,BAMTools,BizTalk,BizTalkAdminSnapIn,Engine,FBAMCLIENT,HealthActivityClient,InfoWorkerApps,MonitoringAndTracking,MOT,MsEDIAS2,MsEDIAS2StatusReporting,MSMQ,OLAPNS,PAM,Runtime,SSOAdmin,SSOServer,WCFAdapter,WcfAdapterAdminTools,WMI `
    /NORESTART `
    /INSTALLDIR "C:\PROGRA~2\MICROS~3\" `
    /COMPANYNAME "Allpay" `
    /USERNAME "BizTalkAutomatedDeployment" `
    /NOCEIP `
    /InstallUpdates
    Wait-Process 'Setup'
    $currentTimestamp = Get-Date
    $outputText = "Microsoft BizTalk Server has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing Microsoft BizTalk server on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure PowerShell
#Install Nuget Package Provider
try
{
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
    $currentTimestamp = Get-Date
    $outputText = "The Nuget package provider has been installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing the Nuget package provider on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Configure PowerShell Gallery Trust Status
try
{
    Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
    $currentTimestamp = Get-Date
    $outputText = "PSGallery has been set to be a trusted package repository on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when installing the Nuget package provider on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Set Locale of Computer to en-GB
try
{
    & $env:SystemRoot\System32\control.exe "intl.cpl,,/f:`"UKRegion.xml`""
    Set-WinSystemLocale en-GB
    Set-WinHomeLocation -GeoId 242
    Set-WinUserLanguageList en-GB -Force
    $currentTimestamp = Get-Date
    $outputText = "The localisation has been to set to en-GB on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "An error occured when setting the localisation to en-GB on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Create BAM IIS Site
try
{
    $site = 'BAM'
    $siteFolder = "C:\inetpub\wwwroot\$site"
    New-Item -Path $siteFolder -ItemType Directory

    New-Website -Name $site -PhysicalPath $siteFolder -ApplicationPool $webAppPoolName -Force
    New-WebBinding -Name $site -Port 443 -Protocol https -IPAddress $primaryIPAddress
    Remove-WebBinding -Name $site -Port 80 -Protocol http -IPAddress *
    Start-Website -Name $site

    $currentTimestamp = Get-Date
    $outputText = "The IIS site $site has been installed and is listening on $primaryIPAddress on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}
catch
{
    $errorMessage = $_.Exception.Message
    $currentTimestamp = Get-Date
    $outputText = "There was an error installing the IIS site $site on $env:computername at $currentTimestamp with the following error '$errorMessage'."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"    
}

$currentTimestamp = Get-Date
$outputText = "configureBizTalkNode.ps1 has completed execution on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer