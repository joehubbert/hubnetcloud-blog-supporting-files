param
(
    [Parameter(Mandatory)][string]$activeDirectoryDomainFullyQualifiedName,
    [Parameter(Mandatory)][string]$activeDirectoryDomainNETBIOSName,
    [Parameter(Mandatory)][string]$sqlInstallAdminUsername,
    [Parameter(Mandatory)][string]$sqlServerAdministratorGroupName,
    [Parameter(Mandatory)][string]$sqlServerBreakGlassAdminPassword,
    [Parameter(Mandatory)][string]$sqlServerBreakGlassAdminUsername,
    [Parameter(Mandatory)][string]$sqlServerDevOpsDeployUserPassword,
    [Parameter(Mandatory)][string]$sqlServerDevOpsDeployUserUsername,
    [Parameter(Mandatory)][string]$sqlServerProductKey,
    [Parameter(Mandatory)][string]$sqlServerSAAccountPassword
)

#Set Common Variables
$computerConfigurationInstallerDirectory = 'C:\ComputerConfiguration\Installer'
$computerConfigurationLogDirectory = 'C:\ComputerConfiguration\Logs'
$errorActionPreference = 'Stop'
$firewallRuleDisplayGroup = 'Allpay Custom Windows Firewall Rules'
$globallyManagedServiceAccountsToInstall = @('svcMSSQLIS') #Left as an array in case more are required later
$scriptFileName = 'sqlAOAGNodeCommonVMSetup-Log.txt'
$scriptLogPath = "$computerConfigurationLogDirectory\$scriptFileName"
$serverMemoryCapacityBytes = (Get-WmiObject -class 'cim_physicalmemory' | Measure-Object -Property Capacity -Sum).Sum
$serverMemoryCapacityMegabytes = $serverMemoryCapacityBytes /1024 /1024
$sqlServerAgentServiceAccount = "$activeDirectoryDomainNETBIOSName\svcMSSQLA$"
$sqlServerBackupDirectory = 'H:\MSSQL15.MSSQLSERVER\BACKUP'
$sqlServerBreakGlassAdminPasswordForCredential = ConvertTo-SecureString $sqlServerBreakGlassAdminPassword -AsPlainText -Force
$sqlServerBreakGlassAdminCredential = New-Object System.Management.Automation.PSCredential($sqlServerBreakGlassAdminUsername, $sqlServerBreakGlassAdminPasswordForCredential)
$sqlServerDatabaseEngineServiceAccount = "$activeDirectoryDomainNETBIOSName\svcMSSQLDB$"
$sqlServerDatabaseMailAccountDisplayName = "MSSQLDB Mail - $env:computername"
$sqlServerDatabaseMailAccountEmailAddress = "$env:computername@$activeDirectoryDomainFullyQualifiedName"
$sqlServerDatabaseMailAccountSMTPServer = "smtp.$activeDirectoryDomainFullyQualifiedName"
$sqlServerDataDirectory = 'F:\MSSQL15.MSSQLSERVER\DATA'
$sqlServerInstanceName = 'MSSQLSERVER'
$sqlServerIntegrationServicesServiceAccount = "$activeDirectoryDomainNETBIOSName\svcMSSQLIS$"
$sqlServerMemoryCapacity = [math]::Round($serverMemoryCapacityMegabytes / 100 * 80)
$sqlServerSAAccountPasswordForCredential = ConvertTo-SecureString $sqlServerSAAccountPassword -AsPlainText -Force
$sqlServerSAAccountCredential = New-Object System.Management.Automation.PSCredential('sa', $sqlServerSAAccountPasswordForCredential)
$windowsFeaturesToInstall = @('RSAT-Clustering', 'RSAT-Clustering-Mgmt', 'RSAT-Clustering-PowerShell', 'Failover-Clustering')

#Create Script Log File
$currentTimestamp = Get-Date
New-Item -Path $computerConfigurationLogDirectory -Name $scriptFileName -ItemType File -Value "Script log file created at $currentTimestamp." -Force

#Install Windows Features
Import-Module ServerManager

foreach($feature in $windowsFeaturesToInstall)
{
    Install-WindowsFeature $feature
    $currentTimestamp = Get-Date
    $outputText = "The Windows Feature $feature has been successfully installed on $env:computername at $currentTimestamp."
    Write-Host $outputText
    Add-Content -Path $scriptLogPath "`n$outputText"
}

#Install Active Directory Globally Managed Service Accounts
Import-Module ActiveDirectory

foreach($gMSA in $globallyManagedServiceAccountsToInstall)
{
    Install-ADServiceAccount -Identity $gMSA
    $gMSATest = Test-AdServiceAccount $gMSA
    if ($gMSATest -eq $true)
    {
        $currentTimestamp = Get-Date
        $outputText = "The Active Directory Globally Managed Service Account $gMSA was successfully installed on $env:computername at $currentTimestamp."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
    elseif ($gMSATest -eq $false)
    {
        $currentTimestamp = Get-Date
        $outputText = "The Active Directory Globally Managed Service Account $gMSA was not installed on $env:computername. Please investigate. Error logged at $currentTimestamp."
        Write-Host $outputText
        Add-Content -Path $scriptLogPath "`n$outputText"
    }
}

#Configure Windows Firewall
New-NetFirewallRule `
-Action Allow `
-Description 'Allows inbound connectivity for SQL Server Always-On Availability Group Listener for the MSSQLSERVER instance.' `
-Direction Inbound `
-DisplayName 'SQL Server - Allow Inbound MSSQLAOAG Listener' `
-Group $firewallRuleDisplayGroup `
-LocalPort 59999 `
-Name 'SQL Server - Allow Inbound MSSQLAOAG Listener' `
-Profile "Domain, Private" `
-Protocol TCP
$currentTimestamp = Get-Date
$outputText = "The MSSQL Always-On Availability Group Listener Windows Firewall Rule has been successfully installed on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

New-NetFirewallRule `
-Action Allow `
-Description 'Allows inbound connectivity for the SQL Server Database Mirroring Endpoint for the MSSQLSERVER instance.' `
-Direction Inbound `
-DisplayName 'SQL Server - Allow Inbound MSSQLDB Database Mirroring Endpoint' `
-Group $firewallRuleDisplayGroup `
-LocalPort 5839 `
-Name 'SQL Server - Allow Inbound MSSQLDB Database Mirroring Endpoint' `
-Profile "Domain, Private" `
-Protocol TCP
$currentTimestamp = Get-Date
$outputText = "The MSSQL Database Mirroring Endpoint Windows Firewall Rule has been successfully installed on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

New-NetFirewallRule `
-Action Allow `
-Description 'Allows inbound connectivity for Windows Server Failover Cluster Listener.' `
-Direction Inbound `
-DisplayName 'Windows Server - Allow Inbound WSFC Listener' `
-Group $firewallRuleDisplayGroup `
-LocalPort 58888 `
-Name 'Windows Server - Allow Inbound WSFC Listener' `
-Profile "Domain, Private" `
-Protocol TCP
$currentTimestamp = Get-Date
$outputText = "The Windows Server Failover Cluster Listener Windows Firewall Rule has been successfully installed on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

netsh int ipv4 add excludedportrange tcp startport=5839 numberofports=1 store=persistent
$currentTimestamp = Get-Date
$outputText = "The port 5839 has been successfully excluded from the Windows Dynamic Port Range on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

netsh int ipv4 add excludedportrange tcp startport=58888 numberofports=1 store=persistent
$currentTimestamp = Get-Date
$outputText = "The port 58888 has been successfully excluded from the Windows Dynamic Port Range on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

netsh int ipv4 add excludedportrange tcp startport=59999 numberofports=1 store=persistent
$currentTimestamp = Get-Date
$outputText = "The port 59999 has been successfully excluded from the Windows Dynamic Port Range on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Install Software Packages
$diskMount = (Mount-DiskImage -ImagePath "$computerConfigurationInstallerDirectory\en_sql_server_2019_x64_dvd.iso")
Set-Location ((Get-DiskImage -DevicePath $diskMount.DevicePath | Get-Volume).DriveLetter + ':\')

.\setup.exe `
/Action='Install' `
/AgtSvcAccount=$sqlServerAgentServiceAccount `
/AgtSvcStartupType='Automatic' `
/BrowserSvcStartupType='Disabled' `
/Features='SQLENGINE,REPLICATION,IS' `
/FilestreamLevel=3 `
/FilestreamShareName='Filestream' `
/ENU `
/IAcceptSQLServerLicenseTerms `
/IndicateProgress `
/InstanceName='MSSQLSERVER' `
/InstallSQLDataDir=$sqlServerDataDirectory `
/ISSvcAccount=$sqlServerIntegrationServicesServiceAccount `
/IsSvcStartupType='Automatic' `
/PID=$sqlServerProductKey `
/Quiet `
/SAPWD=$sqlServerSAAccountPassword `
/SecurityMode='SQL' `
/SQLBackupDir=$sqlServerBackupDirectory `
/SQLMaxDOP=16 `
/SQLMaxMemory=$sqlServerMemoryCapacity `
/SQLSvcAccount=$sqlServerDatabaseEngineServiceAccount `
/SQLSvcStartupType='Automatic' `
/SQLSysAdminAccounts=$sqlInstallAdminUsername `
/SQLTempDBDir='I:\MSSQL15.MSSQLSERVER\TEMPDB' `
/SQLTempDBFileCount=8 `
/SQLTempDBFileGrowth=1024 `
/SQLTempDBFileSize=8 `
/SQLTempDBLogDir='I:\MSSQL15.MSSQLSERVER\TEMPDBLOG' `
/SQLTempDBLogFileSize=8 `
/SQLTempDBLogFileGrowth=1024 `
/SQLUserDBDir=$sqlServerDataDirectory `
/SQLUserDBLogDir='G:\MSSQL15.MSSQLSERVER\LOG' `
/SuppressPrivacyStatementNotice `
/TCPEnabled=1 `
/UpdateEnabled `
/UpdateSource='MU'
$currentTimestamp = Get-Date
$outputText = "SQL Server has been successfully installed on $env:computername at $currentTimestamp using the Always-On Availability Group Configuration."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Configure SQL Server into desired state
#Create Breakglass Login
Invoke-SqlCmd `
-Credential $sqlServerSAAccountCredential `
-Database 'master' `
-Query "CREATE LOGIN [$sqlServerBreakGlassAdminUsername] WITH PASSWORD = '$sqlServerBreakGlassAdminPassword' `
GO `
ALTER SERVER ROLE sysadmin ADD MEMBER[$sqlServerBreakGlassAdminUsername]" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "The breakglass login has been successfully created on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Disable sa Login
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'master' `
-Query "ALTER LOGIN [sa] DISABLE" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "The sa login has been sucessfully disabled on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Create SQL Server Administrators Group Login
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'master' `
-Query "CREATE LOGIN [$sqlServerAdministratorGroupName] FROM WINDOWS `
GO `
ALTER SERVER ROLE sysadmin ADD MEMBER [$sqlServerAdministratorGroupName]" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "The SQL Server Administrators Group Login has been successfully created on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Create DevOps Deploy User Login
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'master' `
-Query "CREATE LOGIN [$sqlServerDevOpsDeployUserUsername] WITH PASSWORD = '$sqlServerDevOpsDeployUserPassword' `
GO `
ALTER SERVER ROLE sysadmin ADD MEMBER[$sqlServerDevOpsDeployUserUsername]" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "The DevOpsDeployUser login has been successfully created on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Enable Database Mail XPs
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'master' `
-Query "sp_configure 'Show Advanced Options', 1; RECONFIGURE; `
GO `
sp_configure 'Database Mail XPs', 1; RECONFIGURE" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "Database Mail XPs has been successfully enabled on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Add Database Mail Profile
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'msdb' `
-Query "EXEC [dbo].[sysmail_add_profile_sp] `
@profile_name = 'MSSQLDBMailProfile', `
@description = 'Profile for sending MSSQL Database Mail.'" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "The Database Mail Profile 'MSSQLDBMailProfile' has been successfully created on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Add Database Mail Account
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'msdb' `
-Query "EXEC [dbo].[sysmail_add_account_sp] `
@account_Name = 'MSSQLDBMailAccount', `
@description = 'Account for sending MSSQL Database Mail.', `
@email_address = '$sqlServerDatabaseMailAccountEmailAddress', `
@display_name = '$sqlServerDatabaseMailAccountDisplayName', `
@mailserver_name = '$sqlServerDatabaseMailAccountSMTPServer', `
@replyto_address = 'IT@allpay.net', `
@port = 25 " `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "The Database Mail Account 'MSSQLDBMailAccount' has been successfully created on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Add Database Mail Account to Database Mail Profile
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'msdb' `
-Query "EXEC [dbo].[sysmail_add_profileaccount_sp] `
@profile_name = 'MSSQLDBMailProfile', `
@account_name = 'MSSQLDBMailAccount', `
@sequence_number = 1" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "The Database Mail Account 'MSSQLDBMailAccount' has been successfully added to the Database Mail Profile 'MSSQLDBMailProfile' on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Configure SQL Server Agent To Use Database Mail
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'master' `
-Query "EXEC [dbo].[xp_instance_regwrite] N'HKEY_LOCAL_MACHINE', `
N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', `
N'UseDatabaseMail', `
N'REG_DWORD', 1`
EXEC [dbo].[xp_instance_regwrite] N'HKEY_LOCAL_MACHINE', `
N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', `
N'DatabaseMailProfile', `
N'REG_SZ', `
N'MSSQLDBMailProfile'" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "SQL Server Agent has been enabled to use the Database Mail Profile 'MSSQLDBMailProfile' on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Create Operator for SQL Server Agent
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'msdb' `
-Query "EXEC [dbo].[sp_add_operator] `
@name = 'DBASupport', `
@enabled = 1, `
@email_address = 'InfrastructureTeam@allpay.net; IT@allpay.net'" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "The operator 'DBASupport' has been added to the SQL Server Agent on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Create SQL Database Mirroring HADR Endpoint
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'master' `
-Query "CREATE ENDPOINT [sql_always_on_mirroring_endpoint] `
STATE=STARTED `
AS TCP `
(LISTENER_PORT = 5839) `
FOR DATABASE_MIRRORING
( `
ENCRYPTION = REQUIRED, `
ROLE = PARTNER `
)" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "The Database Mirroring Endpoint 'sql_always_on_database_mirroring_endpoint' has been configured to listen on 5839 on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Set Cost Threshold for Parallelism
Invoke-SqlCmd `
-Credential $sqlServerBreakGlassAdminCredential `
-Database 'master' `
-Query "EXEC sp_configure 'Show Advanced Options', 1; RECONFIGURE; `
GO `
EXEC sp_configure 'Cost Threshold for Parallelism', 50; RECONFIGURE; `
GO `
" `
-ServerInstance $env:computername
$currentTimestamp = Get-Date
$outputText = "The Cost Threshold for Parallelism has been set to 50 on the SQL instance $sqlServerInstanceName on $env:computername at $currentTimestamp."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Create Directory for SQL Restores
New-Item -Path 'H:\MSSQL15.MSSQLSERVER\RESTORE' -ItemType Directory
$currentTimestamp = Get-Date
$outputText = "The database restore directory 'H:\MSSQL15.MSSQLSERVER\RESTORE' has been successfully created on $env:computername at $currentTimestamp"
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

#Configure Windows SMB Fileshare for SQL Backups
New-SmbShare `
-Description 'SMB Share for hosting SQL Backups.' `
-FolderEnumerationMode 'Unrestricted' `
-FullAccess ($sqlServerAdministratorGroupName, $sqlInstallAdminUsername) `
-Name 'SQLBackups' `
-Path $sqlServerBackupDirectory
$currentTimestamp = Get-Date
$outputText = "The Windows SMB Share called 'SQLBackups' has been successfully created on $env:computername at $currentTimestamp"
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

$currentTimestamp = Get-Date
$outputText = "Execution of sqlAOAGNodeCommonVMSetup.ps1 successfully completed on $env:computername at $currentTimestamp. A server reboot will be triggered immediately."
Write-Host $outputText
Add-Content -Path $scriptLogPath "`n$outputText"

Restart-Computer