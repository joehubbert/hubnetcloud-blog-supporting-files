# Introduction 
This repository stores the templates and configuration scripts for deploying a SQL Server AlwaysOn Availability Group (AOAG) to Windows Server and deploying SQL Server Reporting Services (SSRS) to Windows Server.
- The current configuration:
   - Windows Server 2022
   - SQL Server 2019

# Getting Started
- You will need to clone this repository to your local machine.

**Tools**:
- Visual Studio Code
- PowerShell 7+
- Bicep extension for Visual Studio Code
- ARM Template extentsion for Visual Studio Code

**Active Directory Provisions**
- Service Accounts deployed as per .\Deployment Scripts\PowerShell\provisionADGMSA.ps1, ran on the domain controllers directly

- Domain account with permissions to join machines to domain, dns admin, NOT DOMAIN ADMIN
  - Local administrator permissions to be set through group policy where appropriate
- Domain account with no domain-level permissions to be used as Active Directory breakglass account e.g. 'CONTOSO\sqlbreakglass'
- Security group that has all domain users that need sysadmin access to the database engine, these should be local domain users and not federated

**SSRS**
-Export the encryption keys from the existing instance of SSRS

# Deployment
## Virtual Machine Common
1. Infrastructure is deployed using YAML release pipeline.
2. Preparation PowerShell scripts are ran in the pipeline against each SQL AOAG node and SSRS node.
3. Manual intervention required beyond this point
4. Join each machine to domain
5. Log on to each machine as the local administrator created as part of the deployment
6. Open **Windows PowerShell** as administrator
7. The credential used for $windowsInstallCredential in the below script must have rights to join the machine to the domain in the correct OU and also be local administrator on the machine via group policy
    ```
    $windowsInstallCredential = Get-Credential
    $activeDirectoryDomain = '<FQDN of Active Directory Domain>'

    Set-Location C:\ComputerConfiguration\Scripts
    .\1_domainJoin.ps1 -activeDirectoryDomain $activeDirectoryDomain -windowsInstallCredential $windowsInstallCredential
    ```
8. After each machine has been joined to the domain, login to the machine as the same used specified for $windowsInstallCredential
9. Open **Windows PowerShell** as administrator
    ```
    Set-Location C:\ComputerConfiguration\Scripts
    .\2_commonVMSetup.ps1
    ```

## SQL AOAG Specifc 
1. After reboot, After each machine has been joined to the domain, login to the machine as the same domain user used previously
2. Run **PowerShell 7** as administrator
    ```
    Set-Location C:\ComputerConfiguration\Scripts
    $activeDirectoryDomainFullyQualifiedName = '<FQDN of Active Directory Domain>'
    $activeDirectoryDomainNETBIOSName = '<NETBIOS name of Active Directory Domain>'
    $environment = '<environment>' #Allowed values 'NonProd' and 'Production'
    $sqlInstallAdminUserName = '<BreakGlassDomainUser>'
    $sqlServerAdministratorGroupName = '<DomainGroupSQLAdmins>'
    $sqlServerBreakGlassAdminCredential = Get-Credential
    $sqlServerBreakGlassAdminUserName = '<SQLAuthBreakGlassUser>' #Should be environment specific
    $sqlServerBreakGlassAdminPassword = '<SQLAuthBreakGlassPassword>' 
    $sqlServerProductKey = '<SQLServerProductKey>' #Use 22222-00000-00000-00000-00000 for SQL Server Developer Edition
    $sqlServerSAAccountCredential = Get-Credential
    $sqlServerSAAccountPassword = '<sa account password>'
    .\3_sqlAOAGNodeCommonVMSetup.ps1 `
    -activeDirectoryDomainFullyQualifiedName $activeDirectoryDomainFullyQualifiedName `
    -activeDirectoryDomainNETBIOSName $activeDirectoryDomainNETBIOSName `
    -environment $environment `
    -sqlInstallAdminUserName $sqlInstallAdminUserName `
    -sqlServerAdministratorGroupName $sqlServerAdministratorGroupName `
    -sqlServerBreakGlassAdminCredential $sqlServerBreakGlassAdminCredential `
    -sqlServerBreakGlassAdminPassword $sqlServerBreakGlassAdminPassword `
    -sqlServerBreakGlassAdminUserName $sqlServerBreakGlassAdminUserName `
    -sqlServerProductKey $sqlServerProductKey `
    -sqlServerSAAccountCredential $sqlServerSAAccountCredential `
    -sqlServerSAAccountPassword $sqlServerSAAccountPassword 
    ```
3. After reboot, login to the primary node as the same domain user used previously
4. Open SQL Server Management Studio (SSMS) and connect to the database engine on this node only using the break glass credentials, either Windows/SQL Auth, it doesn't matter
5. Open the following script file C:\ComputerConfiguration\Scripts\4_sqlIntegrationServicesCatalog.sql
6. Set the catalog master key value on line 197 of the script and execute the script
   - It is advisable to have the SQL Script open locally on your machine on another screen for line number referencing as SSMS does not have these enabled by default
   - There may need to be some manual intervention required i.e. re-run certain code blocks
7. On your local machine, open https://learn.microsoft.com/en-us/windows-server/failover-clustering/prestage-cluster-adds#grant-the-cno-permissions-to-the-ou, this will be needed for the next step
8. Run **Windows PowerShell** as administrator
    ```
    Set-Location C:\ComputerConfiguration\Scripts
    $windowsServerFailoverClusterCloudWitnessAccount = '<DBA Storage Account Name>'
    $windowsServerFailoverClusterCloudWitnessKey = '<DBA Storage Account Key>' #This key should not be updated!
    $windowsServerFailoverClusterSQLListenerName = '<SQL Cluster DNS Listener Name>'
    $windowsServerFailoverClusterWSFCName = '<WSFC DNS Name>'
    $windowsServerFailoverClusterLoadBalancerIPAddressSQL = '<SQL Cluster Listener IP Address>'
    $windowsServerFailoverClusterLoadBalancerIPAddressWSFC = '<WSFC Cluster Listener IP Address>'
    $windowsServerFailoverClusterLoadBalancerSubnetMask = '<WSFC Cluster Listener Subnet Mask>' 
    $windowsServerFailoverClusterLoadBalancerTripleOctet = '<Subnet Triple Octet>'
    $windowsServerFailoverClusterNodeA = '<Primary AOAG Node>'
    $windowsServerFailoverClusterNodeB = '<Secondary AOAG Node>'
    $windowsServerFailoverClusterNodeC = '<Secondary AOAG Node>'
    .\5_sqlAOAGPrimaryNodeSetup.ps1 `
    -sqlServerBreakGlassAdminCredential $sqlServerBreakGlassAdminCredential `
    -sqlServerIntegrationServicesCatalogMasterKey $sqlServerIntegrationServicesCatalogMasterKey `
    -windowsServerFailoverClusterCloudWitnessAccount $windowsServerFailoverClusterCloudWitnessAccount `
    -windowsServerFailoverClusterCloudWitnessKey $windowsServerFailoverClusterCloudWitnessKey `
    -windowsServerFailoverClusterSQLListenerName $windowsServerFailoverClusterSQLListenerName `
    -windowsServerFailoverClusterWSFCName $windowsServerFailoverClusterWSFCName `
    -windowsServerFailoverClusterLoadBalancerIPAddressSQL $windowsServerFailoverClusterLoadBalancerIPAddressSQL `
    -windowsServerFailoverClusterLoadBalancerIPAddressWSFC $windowsServerFailoverClusterLoadBalancerIPAddressWSFC `
    -$windowsServerFailoverClusterLoadBalancerSubnetMask $windowsServerFailoverClusterLoadBalancerSubnetMask `
    -windowsServerFailoverClusterLoadBalancerTripleOctet $windowsServerFailoverClusterLoadBalancerTripleOctet `
    -windowsServerFailoverClusterNodeA $windowsServerFailoverClusterNodeA `
    -windowsServerFailoverClusterNodeB $windowsServerFailoverClusterNodeB `
    -windowsServerFailoverClusterNodeC $windowsServerFailoverClusterNodeC 
    ```
9. After reboot, login to **each AOAG node** as the same domain user used previously
10. Open SQL Server Configuration Manager
11. Go to SQL Server Services
12. Right-Click on 'SQL Server (MSSQLSERVER)' and select Properties
13. Go to the Always On Availability Groups tab
14. Enable Always On Availability Groups
15. Restart the server

## SSRS Specific Notes
1. After reboot, After each machine has been joined to the domain, login to the machine as the same domain user used previously
2. Run **PowerShell 7** as administrator
    ```
    Set-Location C:\ComputerConfiguration\Scripts
    $activeDirectoryDomainFullyQualifiedName = '<FQDN of Active Directory Domain>'
    $activeDirectoryDomainNETBIOSName = '<NETBIOS name of Active Directory Domain>'
    $environment = '<environment>' #Allowed values 'NonProd' and 'Production'
    $sqlInstallAdminUserName = '<BreakGlassDomainUser>'
    $sqlServerAdministratorGroupName = '<DomainGroupSQLAdmins>'
    $sqlServerBreakGlassAdminCredential = Get-Credential
    $sqlServerBreakGlassAdminUserName = '<SQLAuthBreakGlassUser>' #Should be environment specific
    $sqlServerBreakGlassAdminPassword = '<SQLAuthBreakGlassPassword>' 
    $sqlServerProductKey = '<SQLServerProductKey>' #Use 22222-00000-00000-00000-00000 for SQL Server Developer Edition
    $sqlServerSAAccountCredential = Get-Credential
    $sqlServerSAAccountPassword = '<sa account password>'
    .\3_sqlRSNodeVMSetup.ps1 `
    -activeDirectoryDomainFullyQualifiedName $activeDirectoryDomainFullyQualifiedName `
    -activeDirectoryDomainNETBIOSName $activeDirectoryDomainNETBIOSName `
    -environment $environment `
    -sqlInstallAdminUserName $sqlInstallAdminUserName `
    -sqlServerAdministratorGroupName $sqlServerAdministratorGroupName `
    -sqlServerBreakGlassAdminCredential $sqlServerBreakGlassAdminCredential `
    -sqlServerBreakGlassAdminPassword $sqlServerBreakGlassAdminPassword `
    -sqlServerBreakGlassAdminUserName $sqlServerBreakGlassAdminUserName `
    -sqlServerProductKey $sqlServerProductKey `
    -sqlServerSAAccountCredential $sqlServerSAAccountCredential `
    -sqlServerSAAccountPassword $sqlServerSAAccountPassword 
    ```
3. Connect to the database engine as one of the sql breakglass logins, can be Windows/SQL Auth, it doesn't matter
4. Create a login to the server for the DOMAIN\svcMSSQLRS$ acccount
5. Restore the ReportServer and ReportServerTempDB databases to the server
6. Upgrade the compatibility level to be the same as the instance e.g. SQL Server 2014 > SQL Server 2019
7. Add the DOMAIN\svcMSSQLRS$ as a user to **both** databases, ensure that the default schema is dbo and the database roles have been set
   - db_owner
   - RS_Exec
8. Copy the backed up SSRS encryption key to the new host
9. Open the SSRS Configuration Manager
10. Configure the Service account to be DOMAIN\svcMSSQLRS$
11. Set the databases to be the one you just restored and use DOMAIN\svcMSSQLRS$ as the credential in service account mode
12. Restore the encryption key that you copied over from the previous host
13. Generate a new encryption key and ensure that it is backed up securely to a location such as key vault
12. Configure the Web Service URL, you may need to install TLS certificates if HTTPS will be used
13. Configure the Report Manager URL
14. Configure E-mail settings, sender address should be the same as what is deployed as clients will likely have that e-mail address whitelisted

# Post-Deployment Activities
1. On your local machine, authenticate to Azure into the correct tenancy/subscription using Connect-AzAccount with the -Tenant and -Subscription Parameters
2. Run Set-Location to the path of where the PowerShell scripts are stored e.g. 'C:\DevOps\Azure Infrastructure\Azure-Infrastructure-Legacy-Data-IaaS\Deployment Scripts\PowerShell'
3. Execute the following code for each SQL AOAG VM node and SSRS VM. 
    ```
    #License Type can be either 'PAYG' for Pay As You Go', 'AHUB' for Azure Hybrid Usage Benefit or 'DR' for High-Availability/Disaster Recovery
    #You should PAYG for NonProd and AHUB or DR for production
    $resourceGroup = '<VMResourceGroupName>'
    .\enrolSQLVMToSQLVMIaaSExtension.ps1 -licenseType '<LicenseType>' -rgName $resourceGroup -vmName '<VMName>'
    ```

# Adding Databases Into Availability Group
- Install all databases on primary node
- A full local backup must be taken of each database before it can be added into the availability group as a prerequisite
  - As there is limited disk space on the local backup drive on the server databases should be batched when being added to the availability group
- SSISDB can and should be added into the availability group
  - Once added, Always-On support should be enabled as per https://learn.microsoft.com/en-us/sql/integration-services/catalog/ssis-catalog?view=sql-server-ver15#Firsttime