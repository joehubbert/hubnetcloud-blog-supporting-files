﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure DirectDebitsCleanBankAccountHolderDetails @seedA int, @seedB int
as
	set nocount on;
	--[BankAccountHolderDetails];
	-- the work table
	select 
	 [BankAccountHolderDetailsId]
	,[ObfuscationManager].[dbo].[ObfuscateEmail] (@seedA, @seedB, [EmailAddress]) [EmailAddress]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FirstName]) [FirstName]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [OtherNames]) [OtherNames]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Surname]) [Surname]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [County]) [County]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Line1]) [Line1]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Line2]) [Line2]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [PostCode]) [PostCode]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [TelephoneNumber]) [TelephoneNumber]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Title]) [Title]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Town]) [Town]
	into [DirectDebits].[dbo].[BankAccountHolderDetails_WORK] 
	from [DirectDebits].[dbo].[BankAccountHolderDetails];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [DirectDebits]; create clustered index [CIX_BankAccountHolderDetails_WORK(BankAccountHolderDetailsId)] on BankAccountHolderDetails_WORK(BankAccountHolderDetailsId);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @BankAccountHolderDetails table(BankAccountHolderDetailsId int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [DirectDebits].[dbo].[BankAccountHolderDetails] 
		SET 
		 [EmailAddress] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[EmailAddress]
		,[FirstName] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[FirstName]
		,[OtherNames] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[OtherNames]
		,[Surname] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[Surname]
		,[County] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[County]
		,[Line1] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[Line1]
		,[Line2] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[Line2]
		,[PostCode] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[PostCode]
		,[TelephoneNumber] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[TelephoneNumber]
		,[Title] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[Title]
		,[Town] = [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[Town]
		output INSERTED.BankAccountHolderDetailsId into @BankAccountHolderDetails
		from [DirectDebits].[dbo].[BankAccountHolderDetails_WORK]
		where [DirectDebits].[dbo].[BankAccountHolderDetails_WORK].[BankAccountHolderDetailsId] = [DirectDebits].[dbo].[BankAccountHolderDetails].[BankAccountHolderDetailsId];
		--remove the records already updated
		delete from [DirectDebits].[dbo].[BankAccountHolderDetails_WORK] where BankAccountHolderDetailsId in (select BankAccountHolderDetailsId from @BankAccountHolderDetails);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @BankAccountHolderDetails;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [DirectDebits].[dbo].[BankAccountHolderDetails_WORK];
return 0