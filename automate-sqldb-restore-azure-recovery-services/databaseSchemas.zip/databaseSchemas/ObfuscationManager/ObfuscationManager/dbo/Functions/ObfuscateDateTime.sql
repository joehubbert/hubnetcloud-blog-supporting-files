﻿CREATE FUNCTION [dbo].[ObfuscateDateTime]
(@datetime DATETIME)
RETURNS DATETIME
AS
 EXTERNAL NAME [ObfuscationManager].[UserDefinedFunctions].[ObfuscateDateTime]

