﻿/*
Clean the names by replacing originals with fictional names
*/
create procedure TextpayCleanDbNames @seedA int, @seedB int
as
	set nocount on;
	UPDATE [Textpay].[dbo].[ITSupportObfuscatedPANAffectedCustomers] SET [FamilyName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FamilyName]);
	UPDATE [Textpay].[dbo].[ITSupportObfuscatedPANAffectedCustomers] SET [FirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FirstName]);
	UPDATE [Textpay].[dbo].[PaymentCards] SET [Name] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Name]);
	UPDATE [Textpay].[dbo].[Users] SET [FirstName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [FirstName]);
	UPDATE [Textpay].[dbo].[Users] SET [LastName] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [LastName]);
	UPDATE [Textpay].[dbo].[Users] SET [Nickname] = [ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [Nickname]);
return 0