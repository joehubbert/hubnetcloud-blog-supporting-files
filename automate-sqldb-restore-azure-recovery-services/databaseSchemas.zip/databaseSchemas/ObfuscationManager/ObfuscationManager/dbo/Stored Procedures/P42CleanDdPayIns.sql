﻿/*
Clean email addresses, names, addresses and contact numbers
*/
create procedure P42CleanDdPayIns @seedA int, @seedB int
as
	set nocount on;
	--[AP_DDPAYINS];
	-- the work table
	select 
	 [AP_RECNO]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACCOUNTNO]) [AP_ACCOUNTNO]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_SORTCODE]) [AP_SORTCODE]
	,[ObfuscationManager].[dbo].[ObfuscateText] (@seedA, @seedB, [AP_ACC_NAME]) [AP_ACC_NAME]
	into [P42].[dbo].[AP_DDPAYINS_WORK] 
	from [P42].[dbo].[AP_DDPAYINS];
	--need an index on this 
	declare @sql nvarchar(4000) = 'use [P42]; create clustered index [CIX_AP_DDPAYINS_WORK(AP_RECNO)] on AP_DDPAYINS_WORK(AP_RECNO);';
	exec (@sql);
	-- update the parent table with obfuscations
	-- in batches of 100,000
	declare @AP_DDPAYINS table(AP_RECNO int);
	declare @rowcount int = 0;
	declare @run bit = 1;
	while @run = 1
	begin
		-- 100,000 rows at a time
		set rowcount 100000;
		-- update the parent table with obfuscations
		UPDATE [P42].[dbo].[AP_DDPAYINS] 
		SET 
		 [AP_ACCOUNTNO] = [P42].[dbo].[AP_DDPAYINS_WORK].[AP_ACCOUNTNO]
		,[AP_SORTCODE] = [P42].[dbo].[AP_DDPAYINS_WORK].[AP_SORTCODE]
		,[AP_ACC_NAME] = [P42].[dbo].[AP_DDPAYINS_WORK].[AP_ACC_NAME]
		output INSERTED.AP_RECNO into @AP_DDPAYINS
		from [P42].[dbo].[AP_DDPAYINS_WORK]
		where [P42].[dbo].[AP_DDPAYINS_WORK].[AP_RECNO] = [P42].[dbo].[AP_DDPAYINS].[AP_RECNO];
		--remove the records already updated
		delete from [P42].[dbo].[AP_DDPAYINS_WORK] where AP_RECNO in (select AP_RECNO from @AP_DDPAYINS);
		--record the count of records processed
		set @rowcount = @@rowcount;
		--clear the local variable for the next batch
		delete from @AP_DDPAYINS;
		--decide if we are going to do another round
		if (@rowcount > 0) set @run = 1 else set @run = 0;
	end;
	-- drop the work table
	drop table [P42].[dbo].[AP_DDPAYINS_WORK];
return 0